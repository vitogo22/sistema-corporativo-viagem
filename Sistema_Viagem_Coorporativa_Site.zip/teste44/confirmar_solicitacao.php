<?php
require 'includes/protecao.php';
require 'includes/conexao.php';

if (!isset($_SESSION['dados_viagem'])) {
    header('Location: nova_solicitacao.php');
    exit;
}

$dados = $_SESSION['dados_viagem'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Confirmar Solicitação</title>
  <link rel="stylesheet" href="css/painel.css">
  <link rel="stylesheet" href="css/confirmar_solicitacao.css">
</head>
<body>
  <?php include 'includes/header.php'; ?>
  
  <div class="dashboard-container">
    <?php include 'includes/sidebar.php'; ?>
    
    <main class="main-content">
      <div class="confirmation-container">
        <h1 class="section-title">Confirmar Solicitação de Viagem</h1>
        
        <?php if (isset($_GET['erro'])): ?>
          <div class="mensagem erro" style="margin-bottom: 30px;">
            <?= htmlspecialchars($_GET['erro']) ?>
          </div>
        <?php endif; ?>
        
        <div class="confirmation-card">
          <h2 class="confirmation-header">Detalhes da Viagem</h2>
          
          <div class="detail-row">
            <div class="detail-label">Motivo:</div>
            <div class="detail-value"><?= nl2br(htmlspecialchars($dados['detalhes']['motivo'])) ?></div>
          </div>
        </div>
        
        <div class="confirmation-card">
          <h2 class="confirmation-header">Transporte</h2>
          
          <div class="detail-row">
            <div class="detail-label">Tipo:</div>
            <div class="detail-value">
              <?= match($dados['transporte']['tipo']) {
                'aviao' => 'Avião',
                'onibus' => 'Ônibus',
                'carro' => 'Carro',
                default => 'Outro'
              } ?>
            </div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Trajeto:</div>
            <div class="detail-value">
              <?= htmlspecialchars($dados['transporte']['origem']) ?> → 
              <?= htmlspecialchars($dados['transporte']['destino']) ?>
            </div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Datas:</div>
            <div class="detail-value">
              <?= date('d/m/Y H:i', strtotime($dados['transporte']['data_saida'])) ?> - 
              <?= date('d/m/Y H:i', strtotime($dados['transporte']['data_chegada'])) ?>
            </div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Valor Estimado:</div>
            <div class="detail-value">
              R$ <?= number_format($dados['transporte']['preco_total'], 2, ',', '.') ?>
            </div>
          </div>
        </div>
        
        <div class="confirmation-card">
          <h2 class="confirmation-header">Hospedagem</h2>
          
          <div class="detail-row">
            <div class="detail-label">Local:</div>
            <div class="detail-value">
              <?= htmlspecialchars($dados['hospedagem']['nome']) ?>
              <?php if ($dados['hospedagem']['cidade']): ?>
                (<?= htmlspecialchars($dados['hospedagem']['cidade']) ?>)
              <?php endif; ?>
            </div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Endereço:</div>
            <div class="detail-value">
              <?= htmlspecialchars($dados['hospedagem']['endereco'] ?? 'Não informado') ?>
            </div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Período:</div>
            <div class="detail-value">
              <?= date('d/m/Y', strtotime($dados['hospedagem']['data_checkin'])) ?> - 
              <?= date('d/m/Y', strtotime($dados['hospedagem']['data_checkout'])) ?>
              (<?= (new DateTime($dados['hospedagem']['data_checkin']))->diff(new DateTime($dados['hospedagem']['data_checkout']))->days ?> dias)
            </div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Valor:</div>
            <div class="detail-value">
              R$ <?= number_format($dados['hospedagem']['preco_total'], 2, ',', '.') ?>
            </div>
          </div>
        </div>
        
        <div class="action-buttons">
          <a href="nova_solicitacao.php" class="btn btn-back">Voltar e Editar</a>
          <form action="processar_solicitacao.php" method="POST" id="form-confirmacao" style="display: inline;">
            <input type="hidden" name="confirmar" value="1">
            <button type="submit" class="btn btn-confirm">Confirmar Solicitação</button>
          </form>
        </div>
      </div>
    </main>
  </div>

  <script>
    // Evitar duplo clique no formulário
    document.getElementById('form-confirmacao').addEventListener('submit', function(e) {
      const btn = this.querySelector('button[type="submit"]');
      btn.disabled = true;
      btn.innerHTML = '<span class="loading-icon">⏳</span> Processando...';
    });
  </script>
</body>
</html>