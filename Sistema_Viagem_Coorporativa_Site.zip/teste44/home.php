<?php
require 'includes/protecao.php';
require 'includes/conexao.php';

// Verifica se é admin/chefe
$isChefe = ($_SESSION['usuario_tipo'] === 'chefe' || $_SESSION['usuario_tipo'] === 'admin');

$stmt = $conexao->prepare("SELECT nome, tipo FROM Usuario WHERE id_usuario = ?");
$stmt->bind_param("i", $_SESSION['usuario_id']);
$stmt->execute();
$resultado = $stmt->get_result();
$usuario = $resultado->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<?php
header('Content-Type: text/css; charset=UTF-8'); // Para o CSS
header('Content-Type: text/html; charset=UTF-8'); // Para a página
$base_url = '/teste44/'; // Ajuste conforme sua estrutura
?>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home - Sistema de Viagens</title>
  <link rel="stylesheet" href="<?php echo $base_url; ?>css/home.css" type="text/css" charset="UTF-8">
</head>
<body>

<header>
  <nav>
    <a href="painel.php">Portal</a>
    <a href="nova_solicitacao.php">Nova Solicitação</a>
    <a href="solicitacoes.php">Minhas Solicitações</a>
    <a href="historico.php">Histórico</a>
    <a href="reembolso.php">Reembolso</a>
    <?php if ($isChefe): ?>
      <a href="admin_usuarios.php">Administração</a>
    <?php endif; ?>
        <?php if ($isChefe): ?>
      <a href="relatorio_geral.php">Relatório Geral</a>
    <?php endif; ?>
    <a href="logout.php">Sair</a>
  </nav>
</header>

<!-- Seção de boas-vindas ampliada -->
<div class="welcome-section">
  <div class="welcome-content">
    <h2>Bem-vindo, <?php echo htmlspecialchars($usuario['nome']); ?>!</h2>
    <p class="access-level">Nível de acesso: <?php echo htmlspecialchars($usuario['tipo']); ?></p>
  </div>
</div>

<main>
  <div class="container" onclick="window.location.href='painel.php'">Portal do Usuário</div>
  <div class="container" onclick="window.location.href='solicitacoes.php'">Minhas Solicitações</div>
  <div class="container" onclick="window.location.href='nova_solicitacao.php'">Nova Solicitação</div>
  <div class="container" onclick="window.location.href='reembolso.php'">Reembolso</div>
  <div class="container" onclick="window.location.href='historico.php'">Histórico</div>
  <?php if ($isChefe): ?>
    <div class="container" onclick="window.location.href='relatorio_geral.php'">Relatório Geral</div>
  <?php endif; ?>
  <?php if ($isChefe): ?>
    <div class="container" onclick="window.location.href='admin_usuarios.php'">Administração de Usuário</div>
  <?php endif; ?>
</main>

</body>
</html>