<?php
require 'includes/protecao.php';
require 'includes/conexao.php';

// Verifica se é admin/chefe
$isChefe = ($_SESSION['usuario_tipo'] === 'chefe' || $_SESSION['usuario_tipo'] === 'admin');

// Filtros
$data_inicio = $_GET['data_inicio'] ?? date('Y-m-01');
$data_fim = $_GET['data_fim'] ?? date('Y-m-t');
$departamento = $_GET['departamento'] ?? '';

// Consulta para relatório geral
function getRelatorioGeral($conexao, $data_inicio, $data_fim, $departamento) {
    // Consulta principal simplificada usando subquery para ordenação
    $sql = "
        SELECT subquery.* FROM (
            SELECT 
                u.departamento,
                COUNT(DISTINCT v.id_viagem) as total_viagens,
                SUM(IFNULL(h.preco_total, 0)) + SUM(IFNULL(t.preco_total, 0)) as custo_base,
                (
                    SELECT COALESCE(SUM(r.valor), 0)
                    FROM reembolso r
                    JOIN viagem v2 ON r.id_viagem = v2.id_viagem
                    JOIN usuario u2 ON v2.id_usuario = u2.id_usuario
                    WHERE u2.departamento = u.departamento
                    AND v2.data_inicio BETWEEN ? AND ?
                    AND r.status = 'aprovado'
                ) as reembolso_total,
                AVG(DATEDIFF(v.data_fim, v.data_inicio)) as media_dias,
                MAX(v.data_inicio) as ultima_viagem
            FROM viagem v
            JOIN usuario u ON v.id_usuario = u.id_usuario
            LEFT JOIN hospedagem h ON v.id_hospedagem = h.id_hospedagem
            LEFT JOIN transporte t ON v.id_transporte = t.id_transporte
            WHERE v.status = 'aprovada'
            AND v.data_inicio BETWEEN ? AND ?
    ";
    
    $params = [$data_inicio, $data_fim, $data_inicio, $data_fim];
    $types = "ssss";
    
    if (!empty($departamento)) {
        $sql .= " AND u.departamento = ?";
        $params[] = $departamento;
        $types .= "s";
    }
    
    $sql .= " GROUP BY u.departamento) as subquery
              ORDER BY (subquery.custo_base + subquery.reembolso_total) DESC";
    
    $stmt = $conexao->prepare($sql);
    if ($stmt === false) {
        error_log("Erro SQL: " . $conexao->error);
        die("Erro na preparação da consulta principal. Verifique os logs para detalhes.");
    }
    
    if (!empty($params)) {
        if (!$stmt->bind_param($types, ...$params)) {
            error_log("Erro bind_param: " . $stmt->error);
            die("Erro ao vincular parâmetros na consulta principal. Verifique os logs para detalhes.");
        }
    }
    
    if (!$stmt->execute()) {
        error_log("Erro execute: " . $stmt->error);
        die("Erro na execução da consulta principal. Verifique os logs para detalhes.");
    }
    
    $dadosAgregados = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // Calcular custo total para cada departamento
    foreach ($dadosAgregados as &$depto) {
        $depto['custo_total'] = $depto['custo_base'] + $depto['reembolso_total'];
    }

    // Consulta para detalhes das viagens
    $sql_detalhes = "
        SELECT 
            v.id_viagem,
            v.destino,
            v.data_inicio,
            v.data_fim,
            u.nome as funcionario,
            u.departamento,
            DATEDIFF(v.data_fim, v.data_inicio) as dias,
            IFNULL(h.preco_total, 0) as hospedagem_preco,
            IFNULL(t.preco_total, 0) as transporte_preco,
            (
                SELECT COALESCE(SUM(r.valor), 0)
                FROM reembolso r
                WHERE r.id_viagem = v.id_viagem
                AND r.status = 'aprovado'
            ) as reembolso_aprovado,
            sv.motivo
        FROM viagem v
        JOIN usuario u ON v.id_usuario = u.id_usuario
        LEFT JOIN solicitacaoviagem sv ON v.id_viagem = sv.id_viagem
        LEFT JOIN hospedagem h ON v.id_hospedagem = h.id_hospedagem
        LEFT JOIN transporte t ON v.id_transporte = t.id_transporte
        WHERE v.status = 'aprovada'
        AND v.data_inicio BETWEEN ? AND ?
    ";
    
    $params_detalhes = [$data_inicio, $data_fim];
    $types_detalhes = "ss";
    
    if (!empty($departamento)) {
        $sql_detalhes .= " AND u.departamento = ?";
        $params_detalhes[] = $departamento;
        $types_detalhes .= "s";
    }
    
    $sql_detalhes .= " ORDER BY v.data_inicio DESC";
    
    $stmt_detalhes = $conexao->prepare($sql_detalhes);
    if ($stmt_detalhes === false) {
        error_log("Erro SQL detalhes: " . $conexao->error);
        $detalhesViagens = [];
    } else {
        if (!empty($params_detalhes)) {
            if (!$stmt_detalhes->bind_param($types_detalhes, ...$params_detalhes)) {
                error_log("Erro bind_param detalhes: " . $stmt_detalhes->error);
                $detalhesViagens = [];
            } else {
                if (!$stmt_detalhes->execute()) {
                    error_log("Erro execute detalhes: " . $stmt_detalhes->error);
                    $detalhesViagens = [];
                } else {
                    $detalhesViagens = $stmt_detalhes->get_result()->fetch_all(MYSQLI_ASSOC);
                }
            }
        }
    }
    
    // Calcular custo total para cada viagem
    foreach ($detalhesViagens as &$viagem) {
        $viagem['custo'] = $viagem['hospedagem_preco'] + $viagem['transporte_preco'] + $viagem['reembolso_aprovado'];
    }

    // Consulta para estatísticas de reembolso - CORREÇÃO PRINCIPAL PARA O ERRO
    $sql_reembolsos = "
        SELECT 
            COUNT(*) as total_reembolsos,
            SUM(CASE WHEN r.status = 'aprovado' THEN 1 ELSE 0 END) as reembolsos_aprovados,
            SUM(CASE WHEN r.status = 'pendente' THEN 1 ELSE 0 END) as reembolsos_pendentes,
            SUM(CASE WHEN r.status = 'recusado' THEN 1 ELSE 0 END) as reembolsos_recusados,
            SUM(CASE WHEN r.status = 'aprovado' THEN r.valor ELSE 0 END) as valor_aprovado,
            SUM(CASE WHEN r.status = 'pendente' THEN r.valor ELSE 0 END) as valor_pendente,
            SUM(CASE WHEN r.status = 'recusado' THEN r.valor ELSE 0 END) as valor_recusado,
            AVG(CASE WHEN r.status = 'aprovado' THEN r.valor END) as media_reembolso
        FROM reembolso r
        JOIN viagem v ON r.id_viagem = v.id_viagem
        JOIN usuario u ON v.id_usuario = u.id_usuario
        WHERE v.data_inicio BETWEEN ? AND ?
    ";
    
    $params_reembolsos = [$data_inicio, $data_fim];
    $types_reembolsos = "ss";
    
    if (!empty($departamento)) {
        $sql_reembolsos .= " AND u.departamento = ?";
        $params_reembolsos[] = $departamento;
        $types_reembolsos .= "s";
    }
    
    $stmt_reembolsos = $conexao->prepare($sql_reembolsos);
    if ($stmt_reembolsos === false) {
        error_log("Erro SQL reembolsos: " . $conexao->error);
        $reembolsoStats = [];
    } else {
        if (!empty($params_reembolsos)) {
            if (!$stmt_reembolsos->bind_param($types_reembolsos, ...$params_reembolsos)) {
                error_log("Erro bind_param reembolsos: " . $stmt_reembolsos->error);
                $reembolsoStats = [];
            } else {
                if (!$stmt_reembolsos->execute()) {
                    error_log("Erro execute reembolsos: " . $stmt_reembolsos->error);
                    $reembolsoStats = [];
                } else {
                    $reembolsoStats = $stmt_reembolsos->get_result()->fetch_assoc();
                }
            }
        }
    }
    
    return [
        'agregados' => $dadosAgregados,
        'detalhes' => $detalhesViagens,
        'reembolso_stats' => $reembolsoStats
    ];
}

// Obter dados para o relatório geral
$relatorio = getRelatorioGeral($conexao, $data_inicio, $data_fim, $departamento);
$total_viagens = array_sum(array_column($relatorio['agregados'], 'total_viagens'));
$custo_total = array_sum(array_column($relatorio['agregados'], 'custo_total'));
$media_dias = $total_viagens > 0 ? array_sum(array_column($relatorio['agregados'], 'media_dias')) / count($relatorio['agregados']) : 0;
$total_reembolsos = $relatorio['reembolso_stats']['reembolsos_aprovados'] ?? 0;
$valor_reembolsos = $relatorio['reembolso_stats']['valor_aprovado'] ?? 0;

// Departamentos para filtro
$departamentos = $conexao->query("SELECT DISTINCT departamento FROM Usuario WHERE departamento IS NOT NULL")->fetch_all(MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdn.sheetjs.com/xlsx-0.19.3/package/dist/xlsx.full.min.js"></script>
    <meta charset="UTF-8">
    <title>Relatório Financeiro Geral</title>
    <link rel="stylesheet" href="css/painel.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/relatorio.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="dashboard-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <div class="relatorio-container">
                <h1 class="section-title">
                    <i class="fas fa-chart-line"></i> Relatório Financeiro Geral
                </h1>
                
                <form method="get" class="filtros-container">
                    <div class="filtro-group">
                        <label for="data_inicio"><i class="fas fa-calendar-alt"></i> Data Início</label>
                        <input type="date" id="data_inicio" name="data_inicio" value="<?= htmlspecialchars($data_inicio) ?>">
                    </div>
                    
                    <div class="filtro-group">
                        <label for="data_fim"><i class="fas fa-calendar-alt"></i> Data Fim</label>
                        <input type="date" id="data_fim" name="data_fim" value="<?= htmlspecialchars($data_fim) ?>">
                    </div>
                    
                    <div class="filtro-group">
                        <label for="departamento"><i class="fas fa-users"></i> Departamento</label>
                        <select id="departamento" name="departamento">
                            <option value="">Todos Departamentos</option>
                            <?php foreach ($departamentos as $depto): ?>
                                <option value="<?= htmlspecialchars($depto['departamento']) ?>" 
                                    <?= ($depto['departamento'] === $departamento) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($depto['departamento']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn-filtrar">
                        <i class="fas fa-filter"></i> Filtrar
                    </button>
                </form>
                
                <div class="resumo-estatistico">
                    <div class="estatistica-card">
                        <div class="estatistica-label">Total de Viagens</div>
                        <div class="estatistica-valor"><?= $total_viagens ?></div>
                    </div>
                    
                    <div class="estatistica-card">
                        <div class="estatistica-label">Custo Total</div>
                        <div class="estatistica-valor">R$ <?= number_format($custo_total, 2, ',', '.') ?></div>
                    </div>
                    
                    <div class="estatistica-card">
                        <div class="estatistica-label">Duração Média</div>
                        <div class="estatistica-valor"><?= round($media_dias, 1) ?> dias</div>
                    </div>
                    
                    <div class="estatistica-card">
                        <div class="estatistica-label">Custo Médio</div>
                        <div class="estatistica-valor">R$ <?= $total_viagens > 0 ? number_format($custo_total/$total_viagens, 2, ',', '.') : '0,00' ?></div>
                    </div>
                    
                    <div class="estatistica-card">
                        <div class="estatistica-label">Total de Reembolsos</div>
                        <div class="estatistica-valor"><?= $total_reembolsos ?></div>
                    </div>
                    
                    <div class="estatistica-card">
                        <div class="estatistica-label">Valor Reembolsado</div>
                        <div class="estatistica-valor">R$ <?= number_format($valor_reembolsos, 2, ',', '.') ?></div>
                    </div>
                </div>
                
                <div class="graficos-container">
                    <div class="grafico-card">
                        <h3><i class="fas fa-chart-pie"></i> Distribuição de Custos por Departamento</h3>
                        <canvas id="graficoCustos" height="250"></canvas>
                    </div>
                    
                    <div class="grafico-card">
                        <h3><i class="fas fa-chart-bar"></i> Viagens por Departamento</h3>
                        <canvas id="graficoViagens" height="250"></canvas>
                    </div>
                    
                    <div class="grafico-card">
                        <h3><i class="fas fa-receipt"></i> Reembolsos por Status</h3>
                        <canvas id="graficoReembolsos" height="250"></canvas>
                    </div>
                </div>
                
                <div class="tabela-container">
                    <h4>Resumo por Departamento</h4>
                    <?php if (empty($relatorio['agregados'])): ?>
                        <p>Nenhum dado encontrado para o período selecionado.</p>
                    <?php else: ?>
                        <table class="tabela-relatorio">
                            <thead>
                                <tr>
                                    <th>Departamento</th>
                                    <th>Viagens</th>
                                    <th>Duração Média</th>
                                    <th>Custo Base</th>
                                    <th>Reembolsos</th>
                                    <th>Custo Total</th>
                                    <th>Última Viagem</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($relatorio['agregados'] as $depto): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($depto['departamento']) ?></td>
                                        <td><?= $depto['total_viagens'] ?></td>
                                        <td><?= round($depto['media_dias'], 1) ?> dias</td>
                                        <td>R$ <?= number_format($depto['custo_base'], 2, ',', '.') ?></td>
                                        <td>R$ <?= number_format($depto['reembolso_total'], 2, ',', '.') ?></td>
                                        <td>R$ <?= number_format($depto['custo_total'], 2, ',', '.') ?></td>
                                        <td><?= date('d/m/Y', strtotime($depto['ultima_viagem'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                    
                    <h4 style="margin-top: 40px;">Detalhes de Todas as Viagens</h4>
                    <?php if (empty($relatorio['detalhes'])): ?>
                        <p>Nenhum detalhe de viagem encontrado para o período selecionado.</p>
                    <?php else: ?>
                        <table class="tabela-relatorio">
                            <thead>
                                <tr>
                                    <th>Funcionário</th>
                                    <th>Departamento</th>
                                    <th>Destino</th>
                                    <th>Período</th>
                                    <th>Duração</th>
                                    <th>Hospedagem</th>
                                    <th>Transporte</th>
                                    <th>Reembolsos</th>
                                    <th>Custo Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($relatorio['detalhes'] as $viagem): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($viagem['funcionario']) ?></td>
                                        <td><?= htmlspecialchars($viagem['departamento']) ?></td>
                                        <td><?= htmlspecialchars($viagem['destino']) ?></td>
                                        <td>
                                            <?= date('d/m/Y', strtotime($viagem['data_inicio'])) ?> - 
                                            <?= date('d/m/Y', strtotime($viagem['data_fim'])) ?>
                                        </td>
                                        <td><?= $viagem['dias'] ?> dias</td>
                                        <td>R$ <?= number_format($viagem['hospedagem_preco'], 2, ',', '.') ?></td>
                                        <td>R$ <?= number_format($viagem['transporte_preco'], 2, ',', '.') ?></td>
                                        <td>R$ <?= number_format($viagem['reembolso_aprovado'], 2, ',', '.') ?></td>
                                        <td>R$ <?= number_format($viagem['custo'], 2, ',', '.') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                    
                    <h4 style="margin-top: 40px;">Estatísticas de Reembolso</h4>
                    <?php if (empty($relatorio['reembolso_stats'])): ?>
                        <p>Nenhuma estatística de reembolso encontrada para o período selecionado.</p>
                    <?php else: ?>
                        <div class="resumo-estatistico">
                            <div class="estatistica-card">
                                <div class="estatistica-label">Total de Reembolsos</div>
                                <div class="estatistica-valor"><?= $relatorio['reembolso_stats']['total_reembolsos'] ?? 0 ?></div>
                            </div>
                            
                            <div class="estatistica-card">
                                <div class="estatistica-label">Reembolsos Aprovados</div>
                                <div class="estatistica-valor"><?= $relatorio['reembolso_stats']['reembolsos_aprovados'] ?? 0 ?></div>
                            </div>
                            
                            <div class="estatistica-card">
                                <div class="estatistica-label">Reembolsos Pendentes</div>
                                <div class="estatistica-valor"><?= $relatorio['reembolso_stats']['reembolsos_pendentes'] ?? 0 ?></div>
                            </div>
                            
                            <div class="estatistica-card">
                                <div class="estatistica-label">Reembolsos Recusados</div>
                                <div class="estatistica-valor"><?= $relatorio['reembolso_stats']['reembolsos_recusados'] ?? 0 ?></div>
                            </div>
                            
                            <div class="estatistica-card">
                                <div class="estatistica-label">Valor Aprovado</div>
                                <div class="estatistica-valor">R$ <?= number_format($relatorio['reembolso_stats']['valor_aprovado'] ?? 0, 2, ',', '.') ?></div>
                            </div>
                            
                            <div class="estatistica-card">
                                <div class="estatistica-label">Valor Pendente</div>
                                <div class="estatistica-valor">R$ <?= number_format($relatorio['reembolso_stats']['valor_pendente'] ?? 0, 2, ',', '.') ?></div>
                            </div>
                            
                            <div class="estatistica-card">
                                <div class="estatistica-label">Valor Recusado</div>
                                <div class="estatistica-valor">R$ <?= number_format($relatorio['reembolso_stats']['valor_recusado'] ?? 0, 2, ',', '.') ?></div>
                            </div>
                            
                            <div class="estatistica-card">
                                <div class="estatistica-label">Média por Reembolso</div>
                                <div class="estatistica-valor">R$ <?= number_format($relatorio['reembolso_stats']['media_reembolso'] ?? 0, 2, ',', '.') ?></div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="acoes-relatorio">
                    <button class="btn-acao" onclick="exportarPDF()">
                        <i class="fas fa-file-pdf"></i> Exportar PDF
                    </button>
                    <button class="btn-acao" onclick="exportarExcel()">
                        <i class="fas fa-file-excel"></i> Exportar Excel
                    </button>
                </div>
            </div>
        </main>
    </div>

<script>
    // Função para formatar moeda
    function formatCurrency(value) {
        return parseFloat(value).toLocaleString('pt-BR', {minimumFractionDigits: 2});
    }

    // Configuração dos gráficos
    document.addEventListener('DOMContentLoaded', function() {
        // Gráfico de pizza para relatório geral
        const departamentos = <?= json_encode(array_column($relatorio['agregados'], 'departamento')) ?>;
        const custos = <?= json_encode(array_column($relatorio['agregados'], 'custo_total')) ?>;
        
        if (departamentos.length > 0) {
            const ctxPie = document.getElementById('graficoCustos').getContext('2d');
            new Chart(ctxPie, {
                type: 'pie',
                data: {
                    labels: departamentos,
                    datasets: [{
                        data: custos,
                        backgroundColor: ['#ff6384', '#36a2eb', '#ffce56', '#4bc0c0', '#9966ff', '#ff9f40'],
                        borderColor: '#ffffff',
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            labels: {
                                color: '#ffffff',
                                font: {
                                    size: 14
                                }
                            }
                        },
                        tooltip: {
                            bodyColor: '#ffffff',
                            titleColor: '#ffffff',
                            backgroundColor: 'rgba(0,0,0,0.7)',
                            borderColor: '#ffffff',
                            borderWidth: 1,
                            callbacks: {
                                label: function(context) {
                                    const label = context.label || '';
                                    const value = context.raw || 0;
                                    const total = custos.reduce((a, b) => a + b, 0);
                                    const percentage = Math.round((value / total) * 100);
                                    return `${label}: R$ ${formatCurrency(value)} (${percentage}%)`;
                                }
                            }
                        }
                    }
                }
            });
        } else {
            document.getElementById('graficoCustos').innerHTML = '<p class="no-data">Não há dados de distribuição de custos</p>';
        }

        // Gráfico de barras para viagens por departamento
        const viagensPorDepto = <?= json_encode(array_column($relatorio['agregados'], 'total_viagens')) ?>;
        
        if (departamentos.length > 0 && viagensPorDepto.length > 0) {
            const ctxBar = document.getElementById('graficoViagens').getContext('2d');
            new Chart(ctxBar, {
                type: 'bar',
                data: {
                    labels: departamentos,
                    datasets: [{
                        label: 'Viagens por Departamento',
                        data: viagensPorDepto,
                        backgroundColor: '#36a2eb',
                        borderColor: '#ffffff',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            labels: {
                                color: '#ffffff',
                                font: {
                                    size: 14
                                }
                            }
                        },
                        tooltip: {
                            bodyColor: '#ffffff',
                            titleColor: '#ffffff',
                            backgroundColor: 'rgba(0,0,0,0.7)',
                            borderColor: '#ffffff',
                            borderWidth: 1
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                color: '#ffffff',
                                precision: 0
                            },
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            }
                        },
                        x: {
                            ticks: {
                                color: '#ffffff'
                            },
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            }
                        }
                    }
                }
            });
        } else {
            document.getElementById('graficoViagens').innerHTML = '<p class="no-data">Não há dados de viagens por departamento</p>';
        }
        
        // Gráfico de reembolsos por status
        const reembolsoStats = <?= json_encode($relatorio['reembolso_stats'] ?? []) ?>;
        
        if (reembolsoStats && reembolsoStats.total_reembolsos > 0) {
            const ctxReembolso = document.getElementById('graficoReembolsos').getContext('2d');
            new Chart(ctxReembolso, {
                type: 'doughnut',
                data: {
                    labels: ['Aprovados', 'Pendentes', 'Recusados'],
                    datasets: [{
                        data: [
                            reembolsoStats.valor_aprovado || 0,
                            reembolsoStats.valor_pendente || 0,
                            reembolsoStats.valor_recusado || 0
                        ],
                        backgroundColor: ['#4bc0c0', '#ffcd56', '#ff6384'],
                        borderColor: '#ffffff',
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            labels: {
                                color: '#ffffff',
                                font: {
                                    size: 14
                                }
                            }
                        },
                        tooltip: {
                            bodyColor: '#ffffff',
                            titleColor: '#ffffff',
                            backgroundColor: 'rgba(0,0,0,0.7)',
                            borderColor: '#ffffff',
                            borderWidth: 1,
                            callbacks: {
                                label: function(context) {
                                    const label = context.label || '';
                                    const value = context.raw || 0;
                                    const total = (reembolsoStats.valor_aprovado || 0) + 
                                                 (reembolsoStats.valor_pendente || 0) + 
                                                 (reembolsoStats.valor_recusado || 0);
                                    const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                                    return `${label}: R$ ${formatCurrency(value)} (${percentage}%)`;
                                }
                            }
                        }
                    }
                }
            });
        } else {
            document.getElementById('graficoReembolsos').innerHTML = '<p class="no-data">Não há dados de reembolsos para exibir</p>';
        }
    });

    function exportarPDF() {
    // Verifica se as bibliotecas estão disponíveis
    if (typeof jsPDF === 'undefined' || typeof autoTable === 'undefined') {
        // Tenta carregar as bibliotecas dinamicamente se não estiverem disponíveis
        const scriptPDF = document.createElement('script');
        scriptPDF.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
        scriptPDF.onload = function() {
            const scriptAutoTable = document.createElement('script');
            scriptAutoTable.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js';
            scriptAutoTable.onload = gerarPDF;
            document.head.appendChild(scriptAutoTable);
        };
        document.head.appendChild(scriptPDF);
    } else {
        gerarPDF();
    }


    function gerarPDF() {
        try {
            // Usa a versão UMD do jsPDF
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            
            // Configurações iniciais
            doc.setFont('helvetica');
            doc.setFontSize(18);
            doc.setTextColor(40, 53, 147);
            doc.text('Relatório Financeiro Geral de Viagens', 105, 20, { align: 'center' });
            
            // Informações do relatório
            doc.setFontSize(12);
            doc.setTextColor(0, 0, 0);
            doc.text(`Período: ${document.getElementById('data_inicio').value} a ${document.getElementById('data_fim').value}`, 14, 30);
            
            const departamentoFiltro = document.getElementById('departamento');
            if (departamentoFiltro && departamentoFiltro.value) {
                doc.text(`Departamento: ${departamentoFiltro.value}`, 14, 38);
            }
            
            doc.text(`Emitido em: ${new Date().toLocaleDateString('pt-BR')}`, 14, departamentoFiltro && departamentoFiltro.value ? 46 : 38);
            
            // Resumo estatístico
            doc.setFontSize(14);
            doc.setTextColor(40, 53, 147);
            doc.text('Resumo Estatístico', 14, departamentoFiltro && departamentoFiltro.value ? 58 : 50);

            const resumoData = [
                ['Métrica', 'Valor'],
                ['Total de Viagens', '<?= $total_viagens ?>'],
                ['Custo Total', 'R$ <?= number_format($custo_total, 2, ',', '.') ?>'],
                ['Duração Média', '<?= round($media_dias, 1) ?> dias'],
                ['Custo Médio', 'R$ <?= $total_viagens > 0 ? number_format($custo_total/$total_viagens, 2, ',', '.') : '0,00' ?>'],
                ['Total de Reembolsos', '<?= $total_reembolsos ?>'],
                ['Valor Reembolsado', 'R$ <?= number_format($valor_reembolsos, 2, ',', '.') ?>']
            ];

            doc.autoTable({
                startY: (departamentoFiltro && departamentoFiltro.value ? 64 : 56),
                head: [['Métrica', 'Valor']],
                body: resumoData,
                theme: 'grid',
                styles: {
                    font: 'helvetica',
                    fontSize: 10,
                    cellPadding: 2,
                    textColor: [0, 0, 0],
                    lineColor: [180, 180, 180],
                    lineWidth: 0.1
                },
                headStyles: {
                    fillColor: [40, 53, 147],
                    textColor: [255, 255, 255],
                    fontStyle: 'bold'
                },
                alternateRowStyles: {
                    fillColor: [240, 240, 240]
                }
            });

            // Resumo por Departamento
            doc.addPage();
            doc.setFontSize(14);
            doc.setTextColor(40, 53, 147);
            doc.text('Resumo por Departamento', 14, 20);

            const agregadosData = [
                ['Departamento', 'Viagens', 'Duração Média', 'Custo Base', 'Reembolsos', 'Custo Total', 'Última Viagem']
            ];
            <?php foreach ($relatorio['agregados'] as $depto): ?>
                agregadosData.push([
                    '<?= htmlspecialchars($depto['departamento']) ?>',
                    '<?= $depto['total_viagens'] ?>',
                    '<?= round($depto['media_dias'], 1) ?> dias',
                    'R$ <?= number_format($depto['custo_base'], 2, ',', '.') ?>',
                    'R$ <?= number_format($depto['reembolso_total'], 2, ',', '.') ?>',
                    'R$ <?= number_format($depto['custo_total'], 2, ',', '.') ?>',
                    '<?= date('d/m/Y', strtotime($depto['ultima_viagem'])) ?>'
                ]);
            <?php endforeach; ?>

            if (agregadosData.length > 1) {
                doc.autoTable({
                    startY: 26,
                    head: [agregadosData[0]],
                    body: agregadosData.slice(1),
                    theme: 'grid',
                    styles: {
                        font: 'helvetica',
                        fontSize: 8,
                        cellPadding: 1.5,
                        textColor: [0, 0, 0],
                        lineColor: [180, 180, 180],
                        lineWidth: 0.1
                    },
                    headStyles: {
                        fillColor: [40, 53, 147],
                        textColor: [255, 255, 255],
                        fontStyle: 'bold'
                    },
                    alternateRowStyles: {
                        fillColor: [240, 240, 240]
                    }
                });
            } else {
                doc.text('Nenhum dado de resumo por departamento encontrado.', 14, 36);
            }

            // Detalhes de Todas as Viagens
            doc.addPage();
            doc.setFontSize(14);
            doc.setTextColor(40, 53, 147);
            doc.text('Detalhes de Todas as Viagens', 14, 20);

            const detalhesViagensData = [
                ['Funcionário', 'Departamento', 'Destino', 'Período', 'Duração', 'Hospedagem', 'Transporte', 'Reembolsos', 'Custo Total']
            ];
            <?php foreach ($relatorio['detalhes'] as $viagem): ?>
                detalhesViagensData.push([
                    '<?= htmlspecialchars($viagem['funcionario']) ?>',
                    '<?= htmlspecialchars($viagem['departamento']) ?>',
                    '<?= htmlspecialchars($viagem['destino']) ?>',
                    '<?= date('d/m/Y', strtotime($viagem['data_inicio'])) ?> - <?= date('d/m/Y', strtotime($viagem['data_fim'])) ?>',
                    '<?= $viagem['dias'] ?> dias',
                    'R$ <?= number_format($viagem['hospedagem_preco'], 2, ',', '.') ?>',
                    'R$ <?= number_format($viagem['transporte_preco'], 2, ',', '.') ?>',
                    'R$ <?= number_format($viagem['reembolso_aprovado'], 2, ',', '.') ?>',
                    'R$ <?= number_format($viagem['custo'], 2, ',', '.') ?>'
                ]);
            <?php endforeach; ?>

            if (detalhesViagensData.length > 1) {
                doc.autoTable({
                    startY: 26,
                    head: [detalhesViagensData[0]],
                    body: detalhesViagensData.slice(1),
                    theme: 'grid',
                    styles: {
                        font: 'helvetica',
                        fontSize: 8,
                        cellPadding: 1.5,
                        textColor: [0, 0, 0],
                        lineColor: [180, 180, 180],
                        lineWidth: 0.1
                    },
                    headStyles: {
                        fillColor: [40, 53, 147],
                        textColor: [255, 255, 255],
                        fontStyle: 'bold'
                    },
                    alternateRowStyles: {
                        fillColor: [240, 240, 240]
                    }
                });
            } else {
                doc.text('Nenhum detalhe de viagem encontrado.', 14, 36);
            }

            // Estatísticas de Reembolso
            doc.addPage();
            doc.setFontSize(14);
            doc.setTextColor(40, 53, 147);
            doc.text('Estatísticas de Reembolso', 14, 20);

            const reembolsoStatsData = [
                ['Métrica', 'Valor'],
                ['Total de Reembolsos', '<?= $relatorio['reembolso_stats']['total_reembolsos'] ?? 0 ?>'],
                ['Reembolsos Aprovados', '<?= $relatorio['reembolso_stats']['reembolsos_aprovados'] ?? 0 ?>'],
                ['Reembolsos Pendentes', '<?= $relatorio['reembolso_stats']['reembolsos_pendentes'] ?? 0 ?>'],
                ['Reembolsos Recusados', '<?= $relatorio['reembolso_stats']['reembolsos_recusados'] ?? 0 ?>'],
                ['Valor Aprovado', 'R$ <?= number_format($relatorio['reembolso_stats']['valor_aprovado'] ?? 0, 2, ',', '.') ?>'],
                ['Valor Pendente', 'R$ <?= number_format($relatorio['reembolso_stats']['valor_pendente'] ?? 0, 2, ',', '.') ?>'],
                ['Valor Recusado', 'R$ <?= number_format($relatorio['reembolso_stats']['valor_recusado'] ?? 0, 2, ',', '.') ?>'],
                ['Média por Reembolso', 'R$ <?= number_format($relatorio['reembolso_stats']['media_reembolso'] ?? 0, 2, ',', '.') ?>']
            ];

            if (reembolsoStatsData.length > 1) {
                doc.autoTable({
                    startY: 26,
                    head: [['Métrica', 'Valor']],
                    body: reembolsoStatsData.slice(1),
                    theme: 'grid',
                    styles: {
                        font: 'helvetica',
                        fontSize: 10,
                        cellPadding: 2,
                        textColor: [0, 0, 0],
                        lineColor: [180, 180, 180],
                        lineWidth: 0.1
                    },
                    headStyles: {
                        fillColor: [40, 53, 147],
                        textColor: [255, 255, 255],
                        fontStyle: 'bold'
                    },
                    alternateRowStyles: {
                        fillColor: [240, 240, 240]
                    }
                });
            } else {
                doc.text('Nenhuma estatística de reembolso encontrada.', 14, 36);
            }

            doc.save('relatorio_geral.pdf');
        } catch (error) {
            console.error("Erro ao gerar PDF:", error);
            alert("Ocorreu um erro ao gerar o PDF. Verifique o console para mais detalhes.");
        }
    }
}

function exportarExcel() {
    // Verifica se a biblioteca XLSX está disponível
    if (typeof XLSX === 'undefined') {
        const scriptXLSX = document.createElement('script');
        scriptXLSX.src = 'https://cdn.sheetjs.com/xlsx-0.19.3/package/dist/xlsx.full.min.js';
        scriptXLSX.onload = gerarExcel;
        document.head.appendChild(scriptXLSX);
    } else {
        gerarExcel();
    }

    function gerarExcel() {
        try {
            const wb = XLSX.utils.book_new();
            
            // 1. Cria a aba "Resumo por Departamento"
            const agregadosData = [
                ["RESUMO POR DEPARTAMENTO"],
                ["Período: " + document.getElementById('data_inicio').value + " a " + document.getElementById('data_fim').value],
                ["Departamento", "Total de Viagens", "Duração Média (dias)", "Custo Base (R$)", "Reembolsos (R$)", "Custo Total (R$)", "Última Viagem"]
            ];
            
            <?php foreach ($relatorio['agregados'] as $depto): ?>
                agregadosData.push([
                    '<?= htmlspecialchars($depto['departamento']) ?>',
                    <?= $depto['total_viagens'] ?>,
                    <?= round($depto['media_dias'], 1) ?>,
                    <?= $depto['custo_base'] ?>,
                    <?= $depto['reembolso_total'] ?>,
                    <?= $depto['custo_total'] ?>,
                    '<?= date('d/m/Y', strtotime($depto['ultima_viagem'])) ?>'
                ]);
            <?php endforeach; ?>
            
            const ws_agregados = XLSX.utils.aoa_to_sheet(agregadosData);
            
            // Formatação da aba "Resumo por Departamento"
            const lastRowAgregados = agregadosData.length;
            
            // Mescla células do título e período
            ws_agregados["!merges"] = [
                {s: {r: 0, c: 0}, e: {r: 0, c: 6}}, // Título
                {s: {r: 1, c: 0}, e: {r: 1, c: 6}}  // Período
            ];
            
            // Formata números
            for (let i = 3; i <= lastRowAgregados; i++) {
                // Viagens (inteiro)
                ws_agregados[`B${i}`].z = '0';
                
                // Duração Média (decimal)
                ws_agregados[`C${i}`].z = '0.0';
                
                // Valores financeiros (moeda)
                ws_agregados[`D${i}`].z = '"R$"#,##0.00';
                ws_agregados[`E${i}`].z = '"R$"#,##0.00';
                ws_agregados[`F${i}`].z = '"R$"#,##0.00';
            }
            
            XLSX.utils.book_append_sheet(wb, ws_agregados, "Resumo Departamentos");

            // 2. Cria a aba "Detalhes das Viagens"
            const detalhesViagensData = [
                ["DETALHES DE TODAS AS VIAGENS"],
                ["Período: " + document.getElementById('data_inicio').value + " a " + document.getElementById('data_fim').value],
                ["Funcionário", "Departamento", "Destino", "Data Início", "Data Fim", "Duração (dias)", "Hospedagem (R$)", "Transporte (R$)", "Reembolsos (R$)", "Custo Total (R$)"]
            ];
            
            <?php foreach ($relatorio['detalhes'] as $viagem): ?>
                detalhesViagensData.push([
                    '<?= htmlspecialchars($viagem['funcionario']) ?>',
                    '<?= htmlspecialchars($viagem['departamento']) ?>',
                    '<?= htmlspecialchars($viagem['destino']) ?>',
                    '<?= date('d/m/Y', strtotime($viagem['data_inicio'])) ?>',
                    '<?= date('d/m/Y', strtotime($viagem['data_fim'])) ?>',
                    <?= $viagem['dias'] ?>,
                    <?= $viagem['hospedagem_preco'] ?>,
                    <?= $viagem['transporte_preco'] ?>,
                    <?= $viagem['reembolso_aprovado'] ?>,
                    <?= $viagem['custo'] ?>
                ]);
            <?php endforeach; ?>
            
            const ws_detalhes = XLSX.utils.aoa_to_sheet(detalhesViagensData);
            
            // Formatação da aba "Detalhes das Viagens"
            const lastRowDetalhes = detalhesViagensData.length;
            
            // Mescla células do título e período
            ws_detalhes["!merges"] = [
                {s: {r: 0, c: 0}, e: {r: 0, c: 9}}, // Título
                {s: {r: 1, c: 0}, e: {r: 1, c: 9}}  // Período
            ];
            
            // Formata números
            for (let i = 3; i <= lastRowDetalhes; i++) {
                // Duração (inteiro)
                ws_detalhes[`F${i}`].z = '0';
                
                // Valores financeiros (moeda)
                ws_detalhes[`G${i}`].z = '"R$"#,##0.00';
                ws_detalhes[`H${i}`].z = '"R$"#,##0.00';
                ws_detalhes[`I${i}`].z = '"R$"#,##0.00';
                ws_detalhes[`J${i}`].z = '"R$"#,##0.00';
            }
            
            XLSX.utils.book_append_sheet(wb, ws_detalhes, "Detalhes Viagens");

            // Ajusta o tamanho das colunas automaticamente
            const sheets = wb.SheetNames;
            sheets.forEach(sheetName => {
                if (!wb.Sheets[sheetName]['!cols']) {
                    wb.Sheets[sheetName]['!cols'] = [];
                    for (let i = 0; i < 10; i++) {
                        wb.Sheets[sheetName]['!cols'].push({wch: sheetName === "Detalhes Viagens" ? (i === 2 ? 25 : 15) : 18});
                    }
                }
            });

            // Gera o arquivo Excel com nome personalizado
            const fileName = `Relatorio_Viagens_${document.getElementById('data_inicio').value}_a_${document.getElementById('data_fim').value}.xlsx`;
            XLSX.writeFile(wb, fileName);
            
        } catch (error) {
            console.error("Erro ao gerar Excel:", error);
            alert("Ocorreu um erro ao gerar o Excel. Verifique o console para mais detalhes.");
        }
    }
}
</script>
</body>
</html>

