<?php
require 'includes/protecao.php';
require 'includes/conexao.php';

if (!isset($_GET['id'])) {
    header('Location: solicitacoes.php');
    exit;
}

$viagem_id = intval($_GET['id']);
$isChefe = ($_SESSION['usuario_tipo'] === 'chefe' || $_SESSION['usuario_tipo'] === 'admin');

// Busca os dados principais da viagem
$stmt = $conexao->prepare("
    SELECT v.*, 
           sv.id_solicitacao, sv.status_aprovacao, sv.data_solicitacao,
           sv.data_aprovacao, sv.motivo_recusa,
           u_aprovador.nome as aprovador_nome,
           u_solicitante.nome as solicitante_nome, u_solicitante.email as solicitante_email
    FROM Viagem v
    JOIN SolicitacaoViagem sv ON v.id_viagem = sv.id_viagem
    JOIN Usuario u_solicitante ON sv.id_usuario_solicitante = u_solicitante.id_usuario
    LEFT JOIN Usuario u_aprovador ON sv.id_usuario_aprovador = u_aprovador.id_usuario
    WHERE v.id_viagem = ?
");

$stmt->bind_param("i", $viagem_id);
$stmt->execute();
$viagem = $stmt->get_result()->fetch_assoc();

// Verifica se o usuário tem permissão para ver esta viagem
if (!$isChefe && $viagem['id_usuario'] != $_SESSION['usuario_id']) {
    header('Location: solicitacoes.php?erro=Acesso não autorizado');
    exit;
}

// Busca dados de hospedagem (se existir)
$hospedagem = null;
if ($viagem['id_hospedagem']) {
    $stmt = $conexao->prepare("SELECT * FROM Hospedagem WHERE id_hospedagem = ?");
    $stmt->bind_param("i", $viagem['id_hospedagem']);
    $stmt->execute();
    $hospedagem = $stmt->get_result()->fetch_assoc();
}

// Busca dados de transporte (se existir)
$transporte = null;
if ($viagem['id_transporte']) {
    $stmt = $conexao->prepare("SELECT * FROM Transporte WHERE id_transporte = ?");
    $stmt->bind_param("i", $viagem['id_transporte']);
    $stmt->execute();
    $transporte = $stmt->get_result()->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Detalhes da Viagem - Sistema de Viagens</title>
  <link rel="stylesheet" href="css/painel.css">
  <link rel="stylesheet" href="css/detalhes.css">
</head>
<body>

<?php include 'includes/header.php'; ?>

<div class="dashboard-container">
  <?php include 'includes/sidebar.php'; ?>

  <main class="main-content">
    <div class="detail-card">
      <div class="detail-header">
        <h1 class="detail-title">Viagem para <?php echo htmlspecialchars($viagem['destino']); ?></h1>
        <span class="status-badge status-<?php echo strtolower($viagem['status_aprovacao']); ?>">
          <?php echo htmlspecialchars($viagem['status_aprovacao']); ?>
        </span>
      </div>

      <h2 style="color: #56A0D3; margin-top: 0;">Informações Básicas</h2>
      <div class="detail-row">
        <div class="detail-label">Solicitante:</div>
        <div class="detail-value">
          <?php echo htmlspecialchars($viagem['solicitante_nome']); ?>
          (<?php echo htmlspecialchars($viagem['solicitante_email']); ?>)
        </div>
      </div>
      <div class="detail-row">
        <div class="detail-label">Período:</div>
        <div class="detail-value">
          <?php echo date('d/m/Y', strtotime($viagem['data_inicio'])); ?> - 
          <?php echo date('d/m/Y', strtotime($viagem['data_fim'])); ?>
          (<?php echo (new DateTime($viagem['data_inicio']))->diff(new DateTime($viagem['data_fim']))->days; ?> dias)
        </div>
      </div>
      <div class="detail-row">
        <div class="detail-label">Data Solicitação:</div>
        <div class="detail-value">
          <?php echo date('d/m/Y H:i', strtotime($viagem['data_solicitacao'])); ?>
        </div>
      </div>
      
      <?php if ($viagem['data_aprovacao']): ?>
      <div class="detail-row">
        <div class="detail-label">Data Aprovação:</div>
        <div class="detail-value">
          <?php echo date('d/m/Y H:i', strtotime($viagem['data_aprovacao'])); ?>
          <?php if ($viagem['aprovador_nome']): ?>
            (por <?php echo htmlspecialchars($viagem['aprovador_nome']); ?>)
          <?php endif; ?>
        </div>
      </div>
      <?php endif; ?>
      
      <?php if ($viagem['motivo_recusa']): ?>
      <div class="detail-row">
        <div class="detail-label">Motivo Recusa:</div>
        <div class="detail-value" style="color: #ff6b6b;">
          <?php echo htmlspecialchars($viagem['motivo_recusa']); ?>
        </div>
      </div>
      <?php endif; ?>
    </div>

    <?php if ($hospedagem): ?>
    <div class="detail-card">
      <h2 style="color: #56A0D3; margin-top: 0;">Hospedagem</h2>
      <div class="detail-row">
        <div class="detail-label">Local:</div>
        <div class="detail-value">
          <?php echo htmlspecialchars($hospedagem['nome']); ?>
          <?php if ($hospedagem['cidade']): ?>
            (<?php echo htmlspecialchars($hospedagem['cidade']); ?>)
          <?php endif; ?>
        </div>
      </div>
      <div class="detail-row">
        <div class="detail-label">Endereço:</div>
        <div class="detail-value"><?php echo htmlspecialchars($hospedagem['endereco'] ?? 'Não informado'); ?></div>
      </div>
      <div class="detail-row">
        <div class="detail-label">Check-in/Check-out:</div>
        <div class="detail-value">
          <?php echo date('d/m/Y', strtotime($hospedagem['data_checkin'])); ?> - 
          <?php echo date('d/m/Y', strtotime($hospedagem['data_checkout'])); ?>
        </div>
      </div>
      <div class="detail-row">
        <div class="detail-label">Valor Total:</div>
        <div class="detail-value">
          R$ <?php echo number_format($hospedagem['preco_total'], 2, ',', '.'); ?>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <?php if ($transporte): ?>
    <div class="detail-card">
      <h2 style="color: #56A0D3; margin-top: 0;">Transporte</h2>
      <div class="detail-row">
        <div class="detail-label">Tipo:</div>
        <div class="detail-value">
          <?php 
          $tipos = [
              'aviao' => 'Avião',
              'onibus' => 'Ônibus',
              'carro' => 'Carro',
              'outro' => 'Outro'
          ];
          echo $tipos[$transporte['tipo']] ?? 'Outro';
          ?>
        </div>
      </div>
      <div class="detail-row">
        <div class="detail-label">Trajeto:</div>
        <div class="detail-value">
          <?php echo htmlspecialchars($transporte['origem']); ?> → 
          <?php echo htmlspecialchars($transporte['destino']); ?>
        </div>
      </div>
      <div class="detail-row">
        <div class="detail-label">Datas/Horários:</div>
        <div class="detail-value">
          Saída: <?php echo date('d/m/Y H:i', strtotime($transporte['data_saida'])); ?><br>
          Chegada: <?php echo date('d/m/Y H:i', strtotime($transporte['data_chegada'])); ?>
        </div>
      </div>
      <div class="detail-row">
        <div class="detail-label">Valor:</div>
        <div class="detail-value">
          R$ <?php echo number_format($transporte['preco_total'], 2, ',', '.'); ?>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <div class="action-buttons">
      <a href="solicitacoes.php" class="action-btn">Voltar</a>
      
      <?php if ($isChefe && $viagem['status_aprovacao'] === 'pendente'): ?>
        <button class="action-btn approve-btn" data-id="<?php echo $viagem['id_solicitacao']; ?>">Aprovar</button>
        <button class="action-btn reject-btn" data-id="<?php echo $viagem['id_solicitacao']; ?>">Recusar</button>
      <?php elseif (!$isChefe && $viagem['status_aprovacao'] === 'pendente'): ?>
        <button class="action-btn cancel-btn" data-id="<?php echo $viagem['id_solicitacao']; ?>">Cancelar</button>
      <?php endif; ?>
    </div>
  </main>
</div>

<script>
// Reutiliza o mesmo JS da página de solicitações
document.addEventListener('DOMContentLoaded', function() {
    const enviarAcao = (id, acao, motivo = null) => {
        return fetch('api/aprovar_solicitacao.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id: id,
                acao: acao,
                motivo: motivo
            })
        })
        .then(response => response.json());
    };

    document.querySelectorAll('.approve-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            if (confirm('Deseja aprovar esta solicitação?')) {
                enviarAcao(this.dataset.id, 'aprovar')
                    .then(data => {
                        if (data.success) {
                            window.location.href = 'solicitacoes.php?sucesso=Solicitação aprovada com sucesso';
                        } else {
                            alert('Erro: ' + data.message);
                        }
                    });
            }
        });
    });

    document.querySelectorAll('.reject-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const motivo = prompt('Digite o motivo da recusa:');
            if (motivo !== null && motivo.trim() !== '') {
                enviarAcao(this.dataset.id, 'recusar', motivo.trim())
                    .then(data => {
                        if (data.success) {
                            window.location.href = 'solicitacoes.php?sucesso=Solicitação recusada com sucesso';
                        } else {
                            alert('Erro: ' + data.message);
                        }
                    });
            }
        });
    });

    document.querySelectorAll('.cancel-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            if (confirm('Deseja cancelar esta solicitação?')) {
                enviarAcao(this.dataset.id, 'cancelar')
                    .then(data => {
                        if (data.success) {
                            window.location.href = 'solicitacoes.php?sucesso=Solicitação cancelada com sucesso';
                        } else {
                            alert('Erro: ' + data.message);
                        }
                    });
            }
        });
    });
});
</script>

</body>
</html>