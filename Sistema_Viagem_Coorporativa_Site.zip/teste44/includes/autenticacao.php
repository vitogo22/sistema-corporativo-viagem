<?php
function estaLogado() {
    return isset($_SESSION['usuario_id']);
}

function autenticarUsuario($email, $senha) {
    global $conexao;
    
    $stmt = $conexao->prepare("SELECT id_usuario, senha, tipo FROM Usuario WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result();
    
    if ($resultado->num_rows === 1) {
        $usuario = $resultado->fetch_assoc();
        if (password_verify($senha, $usuario['senha'])) {
            $_SESSION['usuario_id'] = $usuario['id_usuario'];
            $_SESSION['usuario_tipo'] = $usuario['tipo']; // Adicionado esta linha
            return true;
        }
    }
    return false;
}

function verificarTipoUsuario($tipoRequerido) {
    return ($_SESSION['usuario_tipo'] ?? null) === $tipoRequerido;
}
?>