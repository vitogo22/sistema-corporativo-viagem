<?php
require 'conexao.php';
$usuario_id = $_SESSION['usuario_id'] ?? null;

if ($usuario_id) {
    $stmt = $conexao->prepare("SELECT nome, email, tipo, departamento FROM Usuario WHERE id_usuario = ?");
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $usuario = $stmt->get_result()->fetch_assoc();
}
?>

<aside class="sidebar">
  <div class="user-profile">
    <h2><?php echo htmlspecialchars($usuario['nome'] ?? 'Usuário'); ?></h2>
    <p>Departamento: <?php echo htmlspecialchars($usuario['departamento'] ?? 'N/A'); ?></p>
    <p>Tipo: <?php echo htmlspecialchars($usuario['tipo'] ?? 'N/A'); ?></p>
  </div>

  <ul class="sidebar-menu">
    <li><a href="solicitacoes.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'solicitacoes.php' ? 'active' : ''; ?>">Minhas Solicitações</a></li>
    <li><a href="nova_solicitacao.php">Nova Solicitação</a></li>
    <li><a href="reembolso.php">Reembolso</a></li>
  </ul>
</aside>