<?php
$host = "localhost";
$usuario = "root";
$senha = "";
$banco = "sistemaviagemcorporativa";

$conexao = new mysqli($host, $usuario, $senha, $banco);

if ($conexao->connect_error) {
    die("Erro de conexão: " . $conexao->connect_error);
}

// Definir o charset para utf8
$conexao->set_charset("utf8mb4");
?> 