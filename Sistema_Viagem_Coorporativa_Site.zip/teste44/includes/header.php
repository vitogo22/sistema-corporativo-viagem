<?php if (!isset($_SESSION)) session_start(); ?>
<?php
// Verifica se é admin/chefe
$isChefe = ($_SESSION['usuario_tipo'] === 'chefe' || $_SESSION['usuario_tipo'] === 'admin');
?>

<header>
  <nav class="main-nav">
    <a href="home.php" class="nav-link">Home</a>
    <a href="painel.php" class="nav-link">Painel</a>
    <a href="solicitacoes.php" class="nav-link">Solicitações</a>
    <a href="historico.php" class="nav-link">Histórico</a>
    <?php if($isChefe): ?>
      <a href="admin_usuarios.php" class="nav-link">Administração</a>
    <?php endif; ?>
        <?php if($isChefe): ?>
      <a href="relatorio_geral.php" class="nav-link">Relatório Geral</a>
    <?php endif; ?>
    <a href="nova_solicitacao.php" class="nav-link">Nova Solicitação</a>
    <a href="logout.php" class="nav-link logout" style="margin-left: auto;">Sair</a>
  </nav>
</header>

<style>
/* Estilo da navegação principal */
.main-nav {
  background-color: #2E5C8E;
  display: flex;
  padding: 0;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
  position: relative;
  z-index: 100;
  flex-wrap: wrap;
}

.nav-link {
  color: #E1E1E1;
  text-decoration: none;
  font-weight: 600;
  padding: 1.2rem 1.5rem;
  transition: all 0.3s ease;
  text-align: center;
  position: relative;
  flex-grow: 1;
  min-width: max-content;
  border-right: 1px solid rgba(255, 255, 255, 0.1);
}

.nav-link:last-child {
  border-right: none;
}

.nav-link:hover {
  background-color: #56A0D3;
  color: #1D3C6A;
}

.nav-link.logout {
  background-color: rgba(255, 107, 107, 0.3);
}

.nav-link.logout:hover {
  background-color: #ff6b6b;
}

/* Efeito de sublinhado animado */
.nav-link::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  width: 0;
  height: 3px;
  background: #56A0D3;
  transition: all 0.3s ease;
  transform: translateX(-50%);
}

.nav-link:hover::after {
  width: 70%;
}

/* Responsividade */
@media (max-width: 768px) {
  .main-nav {
    flex-direction: column;
  }
  
  .nav-link {
    border-right: none;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    text-align: left;
    padding: 1rem 1.5rem;
  }
  
  .nav-link.logout {
    margin-left: 0 !important;
    border-top: 2px solid rgba(255, 107, 107, 0.3);
  }
  
  .nav-link::after {
    display: none;
  }
}
</style>