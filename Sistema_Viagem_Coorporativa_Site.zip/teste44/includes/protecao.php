<?php
session_start();

if (!file_exists(__DIR__.'/autenticacao.php')) {
    die("Erro crítico: Arquivo de autenticação não encontrado");
}

require __DIR__.'/autenticacao.php';

// Verifica se o usuário está logado
if (!estaLogado()) {
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    header('Location: login.php');
    exit;
}

// Verificação de admin será feita nas próprias páginas de admin
// Removemos a verificação de conexão daqui
?>