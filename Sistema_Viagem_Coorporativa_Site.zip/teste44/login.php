<?php
session_start();
require 'includes/conexao.php';
require 'includes/autenticacao.php';

if (estaLogado()) {
    header('Location: home.php');
    exit;
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Verifica se os campos existem no POST
    if (empty($_POST['email']) || empty($_POST['password'])) {
        $erro = 'Por favor, preencha todos os campos!';
    } else {
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $senha = $_POST['password']; // Agora usando o nome correto do campo

        if (autenticarUsuario($email, $senha)) {
            header('Location: home.php');
            exit;
        } else {
            $erro = 'E-mail ou senha incorretos!';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8"> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<div class="login-container">
  <h2>Bem-vindo de volta!</h2>

  <?php if (!empty($erro)): ?>
    <div class="mensagem erro"><?php echo $erro; ?></div>
  <?php endif; ?>

  <form action="login.php" method="POST">
    <input type="email" name="email" class="input-field" placeholder="Digite seu e-mail" required>
    <input type="password" name="password" class="input-field" placeholder="Digite sua senha" required>
    <button type="submit" class="login-btn">Login</button>
  </form>

  <a href="registrar.php" class="register-link">Não tem uma conta? Cadastre-se aqui!</a>
</div>

</body>
</html>