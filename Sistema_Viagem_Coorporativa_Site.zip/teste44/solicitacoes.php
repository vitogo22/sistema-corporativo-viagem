<?php
require 'includes/protecao.php';
require 'includes/conexao.php';

// Verifica tipo de usuário com fallback seguro
$isChefe = (($_SESSION['usuario_tipo'] ?? null) === 'chefe' || ($_SESSION['usuario_tipo'] ?? null) === 'admin');
$usuarioId = $_SESSION['usuario_id'] ?? null;

// Variáveis para controle
$erro = null;
$solicitacoes = [];
$minhasSolicitacoes = [];
$sucesso = $_GET['sucesso'] ?? null;
$abaAtiva = $_GET['aba'] ?? 'aprovar'; // Padrão: aba de aprovação

try {
    if ($isChefe) {
        // Consulta para chefes (mostra solicitações pendentes da equipe)
        $stmtEquipe = $conexao->prepare("
            SELECT v.id_viagem, v.destino, v.data_inicio, v.data_fim, v.status, 
                   u.nome as solicitante, u.departamento, sv.id_solicitacao, sv.status_aprovacao
            FROM Viagem v
            JOIN SolicitacaoViagem sv ON v.id_viagem = sv.id_viagem
            JOIN Usuario u ON sv.id_usuario_solicitante = u.id_usuario
            WHERE sv.status_aprovacao = 'pendente'
            ORDER BY sv.data_solicitacao DESC
        ");
        $stmtEquipe->execute();
        $solicitacoes = $stmtEquipe->get_result()->fetch_all(MYSQLI_ASSOC);

        // Consulta para as próprias solicitações do chefe
        $stmtMinhas = $conexao->prepare("
            SELECT v.id_viagem, v.destino, v.data_inicio, v.data_fim, v.status, 
                   sv.id_solicitacao, sv.status_aprovacao
            FROM Viagem v
            JOIN SolicitacaoViagem sv ON v.id_viagem = sv.id_viagem
            WHERE sv.id_usuario_solicitante = ?
            ORDER BY sv.data_solicitacao DESC
        ");
        $stmtMinhas->bind_param("i", $usuarioId);
        $stmtMinhas->execute();
        $minhasSolicitacoes = $stmtMinhas->get_result()->fetch_all(MYSQLI_ASSOC);
    } else {
        // Consulta para funcionários (mostra apenas suas solicitações)
        $stmt = $conexao->prepare("
            SELECT v.id_viagem, v.destino, v.data_inicio, v.data_fim, v.status, 
                   sv.id_solicitacao, sv.status_aprovacao
            FROM Viagem v
            JOIN SolicitacaoViagem sv ON v.id_viagem = sv.id_viagem
            WHERE sv.id_usuario_solicitante = ?
            ORDER BY sv.data_solicitacao DESC
        ");
        $stmt->bind_param("i", $usuarioId);
        $stmt->execute();
        $solicitacoes = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
} catch (Exception $e) {
    $erro = "Erro ao carregar solicitações: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Solicitações - Sistema de Viagens</title>
  <link rel="stylesheet" href="css/painel.css">
  <style>
    /* Estilo do container principal */
    .solicitacoes-container {
        background: #1D3C6A;
        color: white;
        border-radius: 10px;
        padding: 25px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        margin-bottom: 30px;
    }
    
    /* Título da seção */
    .section-title {
        color: #56A0D3;
        margin-top: 0;
        padding-bottom: 15px;
        border-bottom: 2px solid #3a6a9e;
        font-size: 1.5em;
    }
    
    /* Navegação por abas */
    .abas-navegacao {
        display: flex;
        margin-bottom: 20px;
        border-bottom: 2px solid #3a6a9e;
    }
    
    .aba-btn {
        padding: 12px 25px;
        cursor: pointer;
        background: #2E5C8E;
        margin-right: 5px;
        border-radius: 8px 8px 0 0;
        color: #b3d4fc;
        font-weight: bold;
        transition: all 0.3s;
        border: none;
        font-size: 1em;
    }
    
    .aba-btn:hover {
        background: #3a6a9e;
        color: white;
    }
    
    .aba-btn.ativo {
        background: #56A0D3;
        color: white;
    }
    
    /* Conteúdo das abas */
    .aba-conteudo {
        display: none;
        padding: 20px 0;
    }
    
    .aba-conteudo.ativo {
        display: block;
    }
    
    /* Mensagens */
    .mensagem {
        padding: 15px;
        border-radius: 4px;
        margin: 20px 0;
        text-align: center;
    }
    
    .mensagem.sucesso {
        background-color: #4CAF50;
        color: white;
    }
    
    .mensagem.erro {
        background-color: #f44336;
        color: white;
    }
    
    .mensagem.info {
        background-color: #2196F3;
        color: white;
    }
    
    /* Cards de solicitação */
    .request-card {
        background: #2E5C8E;
        border-radius: 8px;
        padding: 20px;
        margin-bottom: 15px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }
    
    .request-info h3 {
        color: #56A0D3;
        margin-top: 0;
    }
    
    .request-status {
        display: inline-block;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 0.9em;
        font-weight: bold;
        margin-top: 10px;
    }
    
    .status-pendente {
        background-color: #FFC107;
        color: #000;
    }
    
    .status-aprovado {
        background-color: #4CAF50;
        color: white;
    }
    
    .status-recusado {
        background-color: #f44336;
        color: white;
    }
    
    .status-cancelado {
        background-color: #9E9E9E;
        color: white;
    }
    
    /* Botões de ação */
    .request-actions {
        display: flex;
        gap: 10px;
        margin-top: 15px;
        flex-wrap: wrap;
    }
    
    .action-btn {
        padding: 8px 16px;
        border-radius: 4px;
        border: none;
        cursor: pointer;
        font-weight: bold;
        transition: all 0.3s;
        text-decoration: none;
        display: inline-block;
        text-align: center;
    }
    
    .action-btn {
        background: #56A0D3;
        color: white;
    }
    
    .action-btn:hover {
        background: #4a90c3;
    }
    
    .approve-btn {
        background: #4CAF50 !important;
    }
    
    .reject-btn {
        background: #f44336 !important;
    }
    
    .cancel-btn {
        background: #9E9E9E !important;
    }
    
    /* Responsividade */
    @media (max-width: 768px) {
        .abas-navegacao {
            flex-direction: column;
            border-bottom: none;
        }
        
        .aba-btn {
            border-radius: 8px;
            margin-bottom: 5px;
            margin-right: 0;
            text-align: left;
        }
        
        .solicitacoes-container {
            padding: 15px;
        }
        
        .request-actions {
            flex-direction: column;
        }
        
        .action-btn {
            width: 100%;
        }
    }
  </style>
</head>
<body>

<?php include 'includes/header.php'; ?>

<div class="dashboard-container">
  <?php include 'includes/sidebar.php'; ?>

  <main class="main-content">
    <div class="solicitacoes-container">
      <h1 class="section-title">
        <?php echo $isChefe ? 'Solicitações' : 'Minhas Solicitações'; ?>
      </h1>
      
      <?php if ($sucesso): ?>
        <div class="mensagem sucesso"><?php echo htmlspecialchars($sucesso); ?></div>
      <?php endif; ?>
      
      <?php if ($erro): ?>
        <div class="mensagem erro"><?php echo htmlspecialchars($erro); ?></div>
      <?php else: ?>
        <?php if ($isChefe): ?>
          <!-- Sistema de abas para chefes -->
          <div class="abas-navegacao">
            <button class="aba-btn <?php echo $abaAtiva === 'aprovar' ? 'ativo' : ''; ?>" 
                    onclick="abrirAba('aprovar')">
              Solicitações para Aprovar
            </button>
            <button class="aba-btn <?php echo $abaAtiva === 'minhas' ? 'ativo' : ''; ?>" 
                    onclick="abrirAba('minhas')">
              Minhas Solicitações
            </button>
          </div>
        <?php endif; ?>

        <!-- Conteúdo das abas -->
        <div id="aprovar" class="aba-conteudo <?php echo (!$isChefe || $abaAtiva === 'aprovar') ? 'ativo' : ''; ?>">
          <?php if (empty($solicitacoes)): ?>
            <div class="mensagem info">
              <?php echo $isChefe ? 'Nenhuma solicitação pendente encontrada.' : 'Você ainda não fez nenhuma solicitação.'; ?>
              <?php if (!$isChefe): ?>
                <br><a href="nova_solicitacao.php" style="color: #b3d4fc;">Criar primeira solicitação</a>
              <?php endif; ?>
            </div>
          <?php else: ?>
            <div class="requests-container">
              <?php foreach ($solicitacoes as $solicitacao): ?>
                <div class="request-card" data-id="<?php echo $solicitacao['id_viagem']; ?>">
                  <div class="request-info">
                    <h3><?php echo htmlspecialchars($solicitacao['destino']); ?></h3>
                    <p>
                      <strong>Período:</strong> 
                      <?php echo date('d/m/Y', strtotime($solicitacao['data_inicio'])); ?> - 
                      <?php echo date('d/m/Y', strtotime($solicitacao['data_fim'])); ?>
                    </p>
                    
                    <?php if ($isChefe): ?>
                      <p><strong>Solicitante:</strong> <?php echo htmlspecialchars($solicitacao['solicitante']); ?></p>
                      <p><strong>Departamento:</strong> <?php echo htmlspecialchars($solicitacao['departamento']); ?></p>
                    <?php endif; ?>
                    
                    <span class="request-status status-<?php echo strtolower($solicitacao['status_aprovacao']); ?>">
                      Status: <?php echo htmlspecialchars($solicitacao['status_aprovacao']); ?>
                    </span>
                  </div>
                  
                  <div class="request-actions">
                    <a href="detalhes.php?id=<?php echo $solicitacao['id_viagem']; ?>" class="action-btn">
                      Ver Detalhes
                    </a>
                    
                    <?php if ($isChefe && $solicitacao['status_aprovacao'] === 'pendente'): ?>
                      <button class="action-btn approve-btn" data-id="<?php echo $solicitacao['id_solicitacao']; ?>">
                        Aprovar
                      </button>
                      <button class="action-btn reject-btn" data-id="<?php echo $solicitacao['id_solicitacao']; ?>">
                        Recusar
                      </button>
                    <?php elseif (!$isChefe && $solicitacao['status_aprovacao'] === 'pendente'): ?>
                      <button class="action-btn cancel-btn" data-id="<?php echo $solicitacao['id_solicitacao']; ?>">
                        Cancelar
                      </button>
                    <?php endif; ?>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>

        <?php if ($isChefe): ?>
          <div id="minhas" class="aba-conteudo <?php echo $abaAtiva === 'minhas' ? 'ativo' : ''; ?>">
            <?php if (empty($minhasSolicitacoes)): ?>
              <div class="mensagem info">
                Você ainda não fez nenhuma solicitação.
                <br><a href="nova_solicitacao.php" style="color: #b3d4fc;">Criar nova solicitação</a>
              </div>
            <?php else: ?>
              <div class="requests-container">
                <?php foreach ($minhasSolicitacoes as $solicitacao): ?>
                  <div class="request-card" data-id="<?php echo $solicitacao['id_viagem']; ?>">
                    <div class="request-info">
                      <h3><?php echo htmlspecialchars($solicitacao['destino']); ?></h3>
                      <p>
                        <strong>Período:</strong> 
                        <?php echo date('d/m/Y', strtotime($solicitacao['data_inicio'])); ?> - 
                        <?php echo date('d/m/Y', strtotime($solicitacao['data_fim'])); ?>
                      </p>
                      
                      <span class="request-status status-<?php echo strtolower($solicitacao['status_aprovacao']); ?>">
                        Status: <?php echo htmlspecialchars($solicitacao['status_aprovacao']); ?>
                      </span>
                    </div>
                    
                    <div class="request-actions">
                      <a href="detalhes.php?id=<?php echo $solicitacao['id_viagem']; ?>" class="action-btn">
                        Ver Detalhes
                      </a>
                      
                      <?php if ($solicitacao['status_aprovacao'] === 'pendente'): ?>
                        <button class="action-btn cancel-btn" data-id="<?php echo $solicitacao['id_solicitacao']; ?>">
                          Cancelar
                        </button>
                      <?php endif; ?>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  </main>
</div>

<script>
  // Função para alternar entre abas
  function abrirAba(abaNome) {
    // Atualiza a URL sem recarregar a página
    const url = new URL(window.location.href);
    url.searchParams.set('aba', abaNome);
    window.history.pushState({}, '', url);
    
    // Esconde todos os conteúdos
    document.querySelectorAll('.aba-conteudo').forEach(conteudo => {
      conteudo.classList.remove('ativo');
    });
    
    // Remove a classe "ativo" de todos os botões
    document.querySelectorAll('.aba-btn').forEach(btn => {
      btn.classList.remove('ativo');
    });
    
    // Mostra a aba selecionada
    document.getElementById(abaNome).classList.add('ativo');
    
    // Ativa o botão da aba selecionada
    document.querySelector(`.aba-btn[onclick*="${abaNome}"]`).classList.add('ativo');
  }

  // Mantém o resto do seu JavaScript existente
  document.addEventListener('DOMContentLoaded', function() {
      // Função para enviar ações
      const enviarAcao = (id, acao, motivo = null) => {
          return fetch('api/aprovar_solicitacao.php', {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                  id: id,
                  acao: acao,
                  motivo: motivo
              })
          })
          .then(response => response.json());
      };

      // Aprovar solicitação (chefes)
      document.querySelectorAll('.approve-btn').forEach(btn => {
          btn.addEventListener('click', function() {
              if (confirm('Deseja aprovar esta solicitação?')) {
                  enviarAcao(this.dataset.id, 'aprovar')
                      .then(data => {
                          if (data.success) {
                              window.location.href = 'solicitacoes.php?sucesso=Solicitação aprovada com sucesso&aba=aprovar';
                          } else {
                              alert('Erro: ' + data.message);
                          }
                      });
              }
          });
      });

      // Recusar solicitação (chefes)
      document.querySelectorAll('.reject-btn').forEach(btn => {
          btn.addEventListener('click', function() {
              const motivo = prompt('Digite o motivo da recusa:');
              if (motivo !== null && motivo.trim() !== '') {
                  enviarAcao(this.dataset.id, 'recusar', motivo.trim())
                      .then(data => {
                          if (data.success) {
                              window.location.href = 'solicitacoes.php?sucesso=Solicitação recusada com sucesso&aba=aprovar';
                          } else {
                              alert('Erro: ' + data.message);
                          }
                      });
              }
          });
      });

      // Cancelar solicitação (funcionários e próprias do chefe)
      document.querySelectorAll('.cancel-btn').forEach(btn => {
          btn.addEventListener('click', function() {
              if (confirm('Deseja cancelar esta solicitação?')) {
                  enviarAcao(this.dataset.id, 'cancelar')
                      .then(data => {
                          if (data.success) {
                              const abaAtual = new URLSearchParams(window.location.search).get('aba') || 'aprovar';
                              window.location.href = `solicitacoes.php?sucesso=Solicitação cancelada com sucesso&aba=${abaAtual}`;
                          } else {
                              alert('Erro: ' + data.message);
                          }
                      });
              }
          });
      });
  });
</script>

</body>
</html>