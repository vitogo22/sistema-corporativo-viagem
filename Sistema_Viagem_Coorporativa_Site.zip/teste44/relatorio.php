<?php
require 'includes/protecao.php';
require 'includes/conexao.php';

// Verifica se é admin/chefe
$isChefe = ($_SESSION['usuario_tipo'] === 'chefe' || $_SESSION['usuario_tipo'] === 'admin');

// Filtros
$data_inicio = $_GET['data_inicio'] ?? date('Y-m-01');
$data_fim = $_GET['data_fim'] ?? date('Y-m-t');
$departamento = $_GET['departamento'] ?? '';
$aba = $_GET['aba'] ?? ($isChefe ? 'geral' : 'pessoal');

// Consulta para relatório pessoal
function getRelatorioPessoal($conexao, $usuario_id, $data_inicio, $data_fim) {
    // Primeiro, obter as viagens com seus custos básicos
    $sql = "
        SELECT 
            v.id_viagem,
            v.destino,
            v.data_inicio,
            v.data_fim,
            DATEDIFF(v.data_fim, v.data_inicio) as dias,
            IFNULL(h.preco_total, 0) as hospedagem_preco,
            IFNULL(t.preco_total, 0) as transporte_preco,
            sv.motivo
        FROM Viagem v
        JOIN SolicitacaoViagem sv ON v.id_viagem = sv.id_viagem
        LEFT JOIN Hospedagem h ON v.id_hospedagem = h.id_hospedagem
        LEFT JOIN Transporte t ON v.id_transporte = t.id_transporte
        WHERE v.id_usuario = ?
        AND v.status = 'aprovada'
        AND v.data_inicio BETWEEN ? AND ?
        ORDER BY v.data_inicio DESC
    ";
    
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("iss", $usuario_id, $data_inicio, $data_fim);
    $stmt->execute();
    $viagens = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // Para cada viagem, obter os reembolsos aprovados
    foreach ($viagens as &$viagem) {
        $sql_reembolso = "
            SELECT 
                SUM(CASE WHEN status = 'aprovado' THEN valor ELSE 0 END) as reembolso_aprovado,
                SUM(CASE WHEN status = 'pendente' THEN valor ELSE 0 END) as reembolso_pendente,
                SUM(CASE WHEN status = 'recusado' THEN valor ELSE 0 END) as reembolso_recusado,
                COUNT(CASE WHEN status = 'aprovado' THEN 1 END) as total_reembolsos_aprovados,
                COUNT(CASE WHEN status = 'pendente' THEN 1 END) as total_reembolsos_pendentes,
                COUNT(CASE WHEN status = 'recusado' THEN 1 END) as total_reembolsos_recusados
            FROM Reembolso
            WHERE id_viagem = ?
        ";
        
        $stmt_reembolso = $conexao->prepare($sql_reembolso);
        $stmt_reembolso->bind_param("i", $viagem['id_viagem']);
        $stmt_reembolso->execute();
        $reembolsos = $stmt_reembolso->get_result()->fetch_assoc();
        
        // Adicionar informações de reembolso à viagem
        $viagem['reembolso_aprovado'] = $reembolsos['reembolso_aprovado'] ?? 0;
        $viagem['reembolso_pendente'] = $reembolsos['reembolso_pendente'] ?? 0;
        $viagem['reembolso_recusado'] = $reembolsos['reembolso_recusado'] ?? 0;
        $viagem['total_reembolsos_aprovados'] = $reembolsos['total_reembolsos_aprovados'] ?? 0;
        $viagem['total_reembolsos_pendentes'] = $reembolsos['total_reembolsos_pendentes'] ?? 0;
        $viagem['total_reembolsos_recusados'] = $reembolsos['total_reembolsos_recusados'] ?? 0;
        
        // Calcular custo total (hospedagem + transporte + reembolsos aprovados)
        $viagem['custo'] = $viagem['hospedagem_preco'] + $viagem['transporte_preco'] + $viagem['reembolso_aprovado'];
        
        // Obter detalhes dos reembolsos para esta viagem
        $sql_detalhes_reembolso = "
            SELECT 
                id_reembolso,
                descricao_despesa,
                valor,
                tipo_despesa,
                status,
                data_requisicao
            FROM Reembolso
            WHERE id_viagem = ?
            ORDER BY data_requisicao DESC
        ";
        
        $stmt_detalhes = $conexao->prepare($sql_detalhes_reembolso);
        $stmt_detalhes->bind_param("i", $viagem['id_viagem']);
        $stmt_detalhes->execute();
        $viagem['detalhes_reembolsos'] = $stmt_detalhes->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    return $viagens;
}

// Consulta para relatório geral
function getRelatorioGeral($conexao, $data_inicio, $data_fim, $departamento) {
    // Consulta principal simplificada usando subquery para ordenação
    $sql = "
        SELECT subquery.* FROM (
            SELECT 
                u.departamento,
                COUNT(DISTINCT v.id_viagem) as total_viagens,
                SUM(IFNULL(h.preco_total, 0)) + SUM(IFNULL(t.preco_total, 0)) as custo_base,
                (
                    SELECT COALESCE(SUM(r.valor), 0)
                    FROM reembolso r
                    JOIN viagem v2 ON r.id_viagem = v2.id_viagem
                    JOIN usuario u2 ON v2.id_usuario = u2.id_usuario
                    WHERE u2.departamento = u.departamento
                    AND v2.data_inicio BETWEEN ? AND ?
                    AND r.status = 'aprovado'
                ) as reembolso_total,
                AVG(DATEDIFF(v.data_fim, v.data_inicio)) as media_dias,
                MAX(v.data_inicio) as ultima_viagem
            FROM viagem v
            JOIN usuario u ON v.id_usuario = u.id_usuario
            LEFT JOIN hospedagem h ON v.id_hospedagem = h.id_hospedagem
            LEFT JOIN transporte t ON v.id_transporte = t.id_transporte
            WHERE v.status = 'aprovada'
            AND v.data_inicio BETWEEN ? AND ?
    ";
    
    $params = [$data_inicio, $data_fim, $data_inicio, $data_fim];
    $types = "ssss";
    
    if (!empty($departamento)) {
        $sql .= " AND u.departamento = ?";
        $params[] = $departamento;
        $types .= "s";
    }
    
    $sql .= " GROUP BY u.departamento) as subquery
              ORDER BY (subquery.custo_base + subquery.reembolso_total) DESC";
    
    $stmt = $conexao->prepare($sql);
    if ($stmt === false) {
        error_log("Erro SQL: " . $conexao->error);
        die("Erro na preparação da consulta principal. Verifique os logs para detalhes.");
    }
    
    if (!empty($params)) {
        if (!$stmt->bind_param($types, ...$params)) {
            error_log("Erro bind_param: " . $stmt->error);
            die("Erro ao vincular parâmetros na consulta principal. Verifique os logs para detalhes.");
        }
    }
    
    if (!$stmt->execute()) {
        error_log("Erro execute: " . $stmt->error);
        die("Erro na execução da consulta principal. Verifique os logs para detalhes.");
    }
    
    $dadosAgregados = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // Calcular custo total para cada departamento
    foreach ($dadosAgregados as &$depto) {
        $depto['custo_total'] = $depto['custo_base'] + $depto['reembolso_total'];
    }

    // Consulta para detalhes das viagens
    $sql_detalhes = "
        SELECT 
            v.id_viagem,
            v.destino,
            v.data_inicio,
            v.data_fim,
            u.nome as funcionario,
            u.departamento,
            DATEDIFF(v.data_fim, v.data_inicio) as dias,
            IFNULL(h.preco_total, 0) as hospedagem_preco,
            IFNULL(t.preco_total, 0) as transporte_preco,
            (
                SELECT COALESCE(SUM(r.valor), 0)
                FROM reembolso r
                WHERE r.id_viagem = v.id_viagem
                AND r.status = 'aprovado'
            ) as reembolso_aprovado,
            sv.motivo
        FROM viagem v
        JOIN usuario u ON v.id_usuario = u.id_usuario
        LEFT JOIN solicitacaoviagem sv ON v.id_viagem = sv.id_viagem
        LEFT JOIN hospedagem h ON v.id_hospedagem = h.id_hospedagem
        LEFT JOIN transporte t ON v.id_transporte = t.id_transporte
        WHERE v.status = 'aprovada'
        AND v.data_inicio BETWEEN ? AND ?
    ";
    
    $params_detalhes = [$data_inicio, $data_fim];
    $types_detalhes = "ss";
    
    if (!empty($departamento)) {
        $sql_detalhes .= " AND u.departamento = ?";
        $params_detalhes[] = $departamento;
        $types_detalhes .= "s";
    }
    
    $sql_detalhes .= " ORDER BY v.data_inicio DESC";
    
    $stmt_detalhes = $conexao->prepare($sql_detalhes);
    if ($stmt_detalhes === false) {
        error_log("Erro SQL detalhes: " . $conexao->error);
        $detalhesViagens = [];
    } else {
        if (!empty($params_detalhes)) {
            if (!$stmt_detalhes->bind_param($types_detalhes, ...$params_detalhes)) {
                error_log("Erro bind_param detalhes: " . $stmt_detalhes->error);
                $detalhesViagens = [];
            } else {
                if (!$stmt_detalhes->execute()) {
                    error_log("Erro execute detalhes: " . $stmt_detalhes->error);
                    $detalhesViagens = [];
                } else {
                    $detalhesViagens = $stmt_detalhes->get_result()->fetch_all(MYSQLI_ASSOC);
                }
            }
        }
    }
    
    // Calcular custo total para cada viagem
    foreach ($detalhesViagens as &$viagem) {
        $viagem['custo'] = $viagem['hospedagem_preco'] + $viagem['transporte_preco'] + $viagem['reembolso_aprovado'];
    }

    // Consulta para estatísticas de reembolso - CORREÇÃO PRINCIPAL PARA O ERRO
    $sql_reembolsos = "
        SELECT 
            COUNT(*) as total_reembolsos,
            SUM(CASE WHEN r.status = 'aprovado' THEN 1 ELSE 0 END) as reembolsos_aprovados,
            SUM(CASE WHEN r.status = 'pendente' THEN 1 ELSE 0 END) as reembolsos_pendentes,
            SUM(CASE WHEN r.status = 'recusado' THEN 1 ELSE 0 END) as reembolsos_recusados,
            SUM(CASE WHEN r.status = 'aprovado' THEN r.valor ELSE 0 END) as valor_aprovado,
            SUM(CASE WHEN r.status = 'pendente' THEN r.valor ELSE 0 END) as valor_pendente,
            SUM(CASE WHEN r.status = 'recusado' THEN r.valor ELSE 0 END) as valor_recusado,
            AVG(CASE WHEN r.status = 'aprovado' THEN r.valor END) as media_reembolso
        FROM reembolso r
        JOIN viagem v ON r.id_viagem = v.id_viagem
        JOIN usuario u ON v.id_usuario = u.id_usuario
        WHERE v.data_inicio BETWEEN ? AND ?
    ";
    
    $params_reembolsos = [$data_inicio, $data_fim];
    $types_reembolsos = "ss";
    
    if (!empty($departamento)) {
        $sql_reembolsos .= " AND u.departamento = ?";
        $params_reembolsos[] = $departamento;
        $types_reembolsos .= "s";
    }
    
    $stmt_reembolsos = $conexao->prepare($sql_reembolsos);
    if ($stmt_reembolsos === false) {
        error_log("Erro SQL reembolsos: " . $conexao->error);
        $reembolsoStats = [];
    } else {
        if (!empty($params_reembolsos)) {
            if (!$stmt_reembolsos->bind_param($types_reembolsos, ...$params_reembolsos)) {
                error_log("Erro bind_param reembolsos: " . $stmt_reembolsos->error);
                $reembolsoStats = [];
            } else {
                if (!$stmt_reembolsos->execute()) {
                    error_log("Erro execute reembolsos: " . $stmt_reembolsos->error);
                    $reembolsoStats = [];
                } else {
                    $reembolsoStats = $stmt_reembolsos->get_result()->fetch_assoc();
                }
            }
        }
    }
    
    return [
        'agregados' => $dadosAgregados,
        'detalhes' => $detalhesViagens,
        'reembolso_stats' => $reembolsoStats
    ];
}

// Obter dados conforme a aba selecionada
if ($aba === 'pessoal') {
    $relatorio = getRelatorioPessoal($conexao, $_SESSION['usuario_id'], $data_inicio, $data_fim);
    $total_viagens = count($relatorio);
    $custo_total = array_sum(array_column($relatorio, 'custo'));
    $media_dias = $total_viagens > 0 ? array_sum(array_column($relatorio, 'dias')) / $total_viagens : 0;
    $total_reembolsos = array_sum(array_column($relatorio, 'total_reembolsos_aprovados'));
    $valor_reembolsos = array_sum(array_column($relatorio, 'reembolso_aprovado'));
} else {
    $relatorio = getRelatorioGeral($conexao, $data_inicio, $data_fim, $departamento);
    $total_viagens = array_sum(array_column($relatorio['agregados'], 'total_viagens'));
    $custo_total = array_sum(array_column($relatorio['agregados'], 'custo_total'));
    $media_dias = $total_viagens > 0 ? array_sum(array_column($relatorio['agregados'], 'media_dias')) / count($relatorio['agregados']) : 0;
    $total_reembolsos = $relatorio['reembolso_stats']['reembolsos_aprovados'] ?? 0;
    $valor_reembolsos = $relatorio['reembolso_stats']['valor_aprovado'] ?? 0;
}

// Departamentos para filtro
$departamentos = $conexao->query("SELECT DISTINCT departamento FROM Usuario WHERE departamento IS NOT NULL")->fetch_all(MYSQLI_ASSOC);


?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdn.sheetjs.com/xlsx-0.19.3/package/dist/xlsx.full.min.js"></script>
    <meta charset="UTF-8">
    <title>Relatório Financeiro</title>
    <link rel="stylesheet" href="css/painel.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/relatorio.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="dashboard-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <div class="relatorio-container">
                <h1 class="section-title">
                    <i class="fas fa-chart-line"></i> Relatório Financeiro
                </h1>
                
                <?php if ($isChefe): ?>
                <div class="abas-navegacao">
                    <div class="aba <?= $aba === 'geral' ? 'ativa' : '' ?>" 
                         onclick="location.href='?aba=geral&data_inicio=<?= $data_inicio ?>&data_fim=<?= $data_fim ?>&departamento=<?= $departamento ?>'">
                        <i class="fas fa-building"></i> Relatório Geral
                    </div>
                    <div class="aba <?= $aba === 'pessoal' ? 'ativa' : '' ?>" 
                         onclick="location.href='?aba=pessoal&data_inicio=<?= $data_inicio ?>&data_fim=<?= $data_fim ?>'">
                        <i class="fas fa-user"></i> Meu Relatório
                    </div>
                </div>
                <?php endif; ?>
                
                <form method="get" class="filtros-container">
                    <input type="hidden" name="aba" value="<?= $aba ?>">
                    
                    <div class="filtro-group">
                        <label for="data_inicio"><i class="fas fa-calendar-alt"></i> Data Início</label>
                        <input type="date" id="data_inicio" name="data_inicio" value="<?= htmlspecialchars($data_inicio) ?>">
                    </div>
                    
                    <div class="filtro-group">
                        <label for="data_fim"><i class="fas fa-calendar-alt"></i> Data Fim</label>
                        <input type="date" id="data_fim" name="data_fim" value="<?= htmlspecialchars($data_fim) ?>">
                    </div>
                    
                    <?php if ($isChefe && $aba === 'geral'): ?>
                    <div class="filtro-group">
                        <label for="departamento"><i class="fas fa-users"></i> Departamento</label>
                        <select id="departamento" name="departamento">
                            <option value="">Todos Departamentos</option>
                            <?php foreach ($departamentos as $depto): ?>
                                <option value="<?= htmlspecialchars($depto['departamento']) ?>" 
                                    <?= ($depto['departamento'] === $departamento) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($depto['departamento']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    
                    <button type="submit" class="btn-filtrar">
                        <i class="fas fa-filter"></i> Filtrar
                    </button>
                </form>
                
                <div class="resumo-estatistico">
                    <div class="estatistica-card">
                        <div class="estatistica-label">Total de Viagens</div>
                        <div class="estatistica-valor"><?= $total_viagens ?></div>
                    </div>
                    
                    <div class="estatistica-card">
                        <div class="estatistica-label">Custo Total</div>
                        <div class="estatistica-valor">R$ <?= number_format($custo_total, 2, ',', '.') ?></div>
                    </div>
                    
                    <div class="estatistica-card">
                        <div class="estatistica-label">Duração Média</div>
                        <div class="estatistica-valor"><?= round($media_dias, 1) ?> dias</div>
                    </div>
                    
                    <div class="estatistica-card">
                        <div class="estatistica-label">Custo Médio</div>
                        <div class="estatistica-valor">R$ <?= $total_viagens > 0 ? number_format($custo_total/$total_viagens, 2, ',', '.') : '0,00' ?></div>
                    </div>
                    
                    <!-- Novos cards de estatísticas para reembolsos -->
                    <div class="estatistica-card">
                        <div class="estatistica-label">Total de Reembolsos</div>
                        <div class="estatistica-valor"><?= $total_reembolsos ?></div>
                    </div>
                    
                    <div class="estatistica-card">
                        <div class="estatistica-label">Valor Reembolsado</div>
                        <div class="estatistica-valor">R$ <?= number_format($valor_reembolsos, 2, ',', '.') ?></div>
                    </div>
                </div>
                
                <div class="graficos-container">

                    <div class="grafico-card">
                        <h3><i class="fas fa-chart-pie"></i> Distribuição de Custos</h3>
                        <canvas id="graficoCustos" height="250"></canvas>
                    </div>
                    
                    <div class="grafico-card">
                        <h3><i class="fas fa-chart-bar"></i> Viagens por Período</h3>
                        <canvas id="graficoViagens" height="250"></canvas>
                    </div>
                    
                    <div class="grafico-card">
                        <h3><i class="fas fa-receipt"></i> Reembolsos por Tipo</h3>
                        <canvas id="graficoReembolsos" height="250"></canvas>
                    </div>
                </div>
                
                <div class="tabela-container">
                    <h3><i class="fas fa-table"></i> Detalhes das Viagens</h3>
                    
                    <?php if ($aba === 'pessoal'): ?>
                        <?php if (empty($relatorio)): ?>
                            <p>Nenhuma viagem encontrada no período selecionado.</p>
                        <?php else: ?>
                            <table class="tabela-relatorio">
                                <thead>
                                    <tr>
                                        <th>Destino</th>
                                        <th>Período</th>
                                        <th>Duração</th>
                                        <th>Hospedagem</th>
                                        <th>Transporte</th>
                                        <th>Reembolsos</th>
                                        <th>Custo Total</th>
                                        <th>Motivo</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($relatorio as $viagem): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($viagem['destino']) ?></td>
                                            <td>
                                                <?= date('d/m/Y', strtotime($viagem['data_inicio'])) ?> - 
                                                <?= date('d/m/Y', strtotime($viagem['data_fim'])) ?>
                                            </td>
                                            <td><?= $viagem['dias'] ?> dias</td>
                                            <td>R$ <?= number_format($viagem['hospedagem_preco'], 2, ',', '.') ?></td>
                                            <td>R$ <?= number_format($viagem['transporte_preco'], 2, ',', '.') ?></td>
                                            <td>R$ <?= number_format($viagem['reembolso_aprovado'], 2, ',', '.') ?></td>
                                            <td>R$ <?= number_format($viagem['custo'], 2, ',', '.') ?></td>
                                            <td><?= htmlspecialchars(substr($viagem['motivo'], 0, 50)) . (strlen($viagem['motivo']) > 50 ? '...' : '') ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            
                            <!-- Seção de detalhes de reembolsos -->
                            <h3 style="margin-top: 40px;"><i class="fas fa-receipt"></i> Detalhes dos Reembolsos</h3>
                            <?php 
                            $temReembolsos = false;
                            foreach ($relatorio as $viagem) {
                                if (!empty($viagem['detalhes_reembolsos'])) {
                                    $temReembolsos = true;
                                    break;
                                }
                            }
                            
                            if (!$temReembolsos): ?>
                                <p>Nenhum reembolso encontrado no período selecionado.</p>
                            <?php else: ?>
                                <table class="tabela-relatorio">
                                    <thead>
                                        <tr>
                                            <th>Destino da Viagem</th>
                                            <th>Tipo de Despesa</th>
                                            <th>Descrição</th>
                                            <th>Valor</th>
                                            <th>Status</th>
                                            <th>Data da Requisição</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($relatorio as $viagem): ?>
                                            <?php foreach ($viagem['detalhes_reembolsos'] as $reembolso): ?>
                                                <tr>
                                                    <td><?= htmlspecialchars($viagem['destino']) ?></td>
                                                    <td><?= ucfirst(htmlspecialchars($reembolso['tipo_despesa'])) ?></td>
                                                    <td><?= htmlspecialchars($reembolso['descricao_despesa']) ?></td>
                                                    <td>R$ <?= number_format($reembolso['valor'], 2, ',', '.') ?></td>
                                                    <td>
                                                        <span class="badge-status badge-<?= $reembolso['status'] ?>">
                                                            <?= ucfirst($reembolso['status']) ?>
                                                        </span>
                                                    </td>
                                                    <td><?= date('d/m/Y', strtotime($reembolso['data_requisicao'])) ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if (empty($relatorio['agregados'])): ?>
                            <p>Nenhum dado encontrado para o período selecionado.</p>
                        <?php else: ?>
                            <h4>Resumo por Departamento</h4>
                            <table class="tabela-relatorio">
                                <thead>
                                    <tr>
                                        <th>Departamento</th>
                                        <th>Viagens</th>
                                        <th>Duração Média</th>
                                        <th>Custo Base</th>
                                        <th>Reembolsos</th>
                                        <th>Custo Total</th>
                                        <th>Última Viagem</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($relatorio['agregados'] as $depto): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($depto['departamento']) ?></td>
                                            <td><?= $depto['total_viagens'] ?></td>
                                            <td><?= round($depto['media_dias'], 1) ?> dias</td>
                                            <td>R$ <?= number_format($depto['custo_base'], 2, ',', '.') ?></td>
                                            <td>R$ <?= number_format($depto['reembolso_total'], 2, ',', '.') ?></td>
                                            <td>R$ <?= number_format($depto['custo_total'], 2, ',', '.') ?></td>
                                            <td><?= date('d/m/Y', strtotime($depto['ultima_viagem'])) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            
                            <h4 style="margin-top: 40px;">Detalhes de Todas as Viagens</h4>
                            <table class="tabela-relatorio">
                                <thead>
                                    <tr>
                                        <th>Funcionário</th>
                                        <th>Departamento</th>
                                        <th>Destino</th>
                                        <th>Período</th>
                                        <th>Duração</th>
                                        <th>Hospedagem</th>
                                        <th>Transporte</th>
                                        <th>Reembolsos</th>
                                        <th>Custo Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($relatorio['detalhes'] as $viagem): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($viagem['funcionario']) ?></td>
                                            <td><?= htmlspecialchars($viagem['departamento']) ?></td>
                                            <td><?= htmlspecialchars($viagem['destino']) ?></td>
                                            <td>
                                                <?= date('d/m/Y', strtotime($viagem['data_inicio'])) ?> - 
                                                <?= date('d/m/Y', strtotime($viagem['data_fim'])) ?>
                                            </td>
                                            <td><?= $viagem['dias'] ?> dias</td>
                                            <td>R$ <?= number_format($viagem['hospedagem_preco'], 2, ',', '.') ?></td>
                                            <td>R$ <?= number_format($viagem['transporte_preco'], 2, ',', '.') ?></td>
                                            <td>R$ <?= number_format($viagem['reembolso_aprovado'], 2, ',', '.') ?></td>
                                            <td>R$ <?= number_format($viagem['custo'], 2, ',', '.') ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            
                            <!-- Estatísticas de Reembolso -->
                            <h4 style="margin-top: 40px;">Estatísticas de Reembolso</h4>
                            <div class="resumo-estatistico">
                                <div class="estatistica-card">
                                    <div class="estatistica-label">Total de Reembolsos</div>
                                    <div class="estatistica-valor"><?= $relatorio['reembolso_stats']['total_reembolsos'] ?? 0 ?></div>
                                </div>
                                
                                <div class="estatistica-card">
                                    <div class="estatistica-label">Reembolsos Aprovados</div>
                                    <div class="estatistica-valor"><?= $relatorio['reembolso_stats']['reembolsos_aprovados'] ?? 0 ?></div>
                                </div>
                                
                                <div class="estatistica-card">
                                    <div class="estatistica-label">Reembolsos Pendentes</div>
                                    <div class="estatistica-valor"><?= $relatorio['reembolso_stats']['reembolsos_pendentes'] ?? 0 ?></div>
                                </div>
                                
                                <div class="estatistica-card">
                                    <div class="estatistica-label">Reembolsos Recusados</div>
                                    <div class="estatistica-valor"><?= $relatorio['reembolso_stats']['reembolsos_recusados'] ?? 0 ?></div>
                                </div>
                                
                                <div class="estatistica-card">
                                    <div class="estatistica-label">Valor Aprovado</div>
                                    <div class="estatistica-valor">R$ <?= number_format($relatorio['reembolso_stats']['valor_aprovado'] ?? 0, 2, ',', '.') ?></div>
                                </div>
                                
                                <div class="estatistica-card">
                                    <div class="estatistica-label">Valor Pendente</div>
                                    <div class="estatistica-valor">R$ <?= number_format($relatorio['reembolso_stats']['valor_pendente'] ?? 0, 2, ',', '.') ?></div>
                                </div>
                                
                                <div class="estatistica-card">
                                    <div class="estatistica-label">Valor Recusado</div>
                                    <div class="estatistica-valor">R$ <?= number_format($relatorio['reembolso_stats']['valor_recusado'] ?? 0, 2, ',', '.') ?></div>
                                </div>
                                
                                <div class="estatistica-card">
                                    <div class="estatistica-label">Média por Reembolso</div>
                                    <div class="estatistica-valor">R$ <?= number_format($relatorio['reembolso_stats']['media_reembolso'] ?? 0, 2, ',', '.') ?></div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                
                <div class="acoes-relatorio">
                    <button class="btn-acao" onclick="exportarPDF()">
                        <i class="fas fa-file-pdf"></i> Exportar PDF
                    </button>
                    <button class="btn-acao" onclick="exportarExcel()">
                        <i class="fas fa-file-excel"></i> Exportar Excel
                    </button>
                </div>
            </div>
        </main>
    </div>



<script>
    // Função para formatar moeda
    function formatCurrency(value) {
        return parseFloat(value).toLocaleString('pt-BR', {minimumFractionDigits: 2});
    }

    // Configuração dos gráficos
    document.addEventListener('DOMContentLoaded', function() {
        <?php if ($aba === 'pessoal' && !empty($relatorio)): ?>
            // Dados para gráfico de pizza (Distribuição de Custos)
            const transporteTotal = <?= array_sum(array_column($relatorio, 'transporte_preco')) ?: 0 ?>;
            const hospedagemTotal = <?= array_sum(array_column($relatorio, 'hospedagem_preco')) ?: 0 ?>;
            const reembolsoTotal = <?= array_sum(array_column($relatorio, 'reembolso_aprovado')) ?: 0 ?>;
            
            if (transporteTotal > 0 || hospedagemTotal > 0 || reembolsoTotal > 0) {
                const ctxPie = document.getElementById('graficoCustos').getContext('2d');
                new Chart(ctxPie, {
                    type: 'pie',
                    data: {
                        labels: ['Transporte', 'Hospedagem', 'Reembolsos'],
                        datasets: [{
                            data: [transporteTotal, hospedagemTotal, reembolsoTotal],
                            backgroundColor: ['#36a2eb', '#ff6384', '#4bc0c0'],
                            borderColor: '#ffffff',
                            borderWidth: 2
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                labels: {
                                    color: '#ffffff',
                                    font: {
                                        size: 14
                                    }
                                }
                            },
                            tooltip: {
                                bodyColor: '#ffffff',
                                titleColor: '#ffffff',
                                backgroundColor: 'rgba(0,0,0,0.7)',
                                borderColor: '#ffffff',
                                borderWidth: 1,
                                callbacks: {
                                    label: function(context) {
                                        const label = context.label || '';
                                        const value = context.raw || 0;
                                        const total = transporteTotal + hospedagemTotal + reembolsoTotal;
                                        const percentage = Math.round((value / total) * 100);
                                        return `${label}: R$ ${formatCurrency(value)} (${percentage}%)`;
                                    }
                                }
                            }
                        }
                    }
                });
            } else {
                document.getElementById('graficoCustos').innerHTML = '<p class="no-data">Não há dados de custos para exibir</p>';
            }

            // Gráfico de barras (Viagens por Período)
            const viagensPorMes = {};
            <?php foreach ($relatorio as $viagem): ?>
                const mes = '<?= date('m/Y', strtotime($viagem['data_inicio'])) ?>';
                if (!viagensPorMes[mes]) {
                    viagensPorMes[mes] = 0;
                }
                viagensPorMes[mes] += parseFloat(<?= $viagem['custo'] ?>);
            <?php endforeach; ?>

            if (Object.keys(viagensPorMes).length > 0) {
                const ctxBar = document.getElementById('graficoViagens').getContext('2d');
                new Chart(ctxBar, {
                    type: 'bar',
                    data: {
                        labels: Object.keys(viagensPorMes),
                        datasets: [{
                            label: 'Custo por Mês (R$)',
                            data: Object.values(viagensPorMes),
                            backgroundColor: '#4bc0c0',
                            borderColor: '#ffffff',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                labels: {
                                    color: '#ffffff',
                                    font: {
                                        size: 14
                                    }
                                }
                            },
                            tooltip: {
                                bodyColor: '#ffffff',
                                titleColor: '#ffffff',
                                backgroundColor: 'rgba(0,0,0,0.7)',
                                borderColor: '#ffffff',
                                borderWidth: 1,
                                callbacks: {
                                    label: function(context) {
                                        return 'Custo: R$ ' + formatCurrency(context.raw);
                                    }
                                }
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    color: '#ffffff',
                                    callback: function(value) {
                                        return 'R$ ' + formatCurrency(value);
                                    }
                                },
                                grid: {
                                    color: 'rgba(255, 255, 255, 0.1)'
                                }
                            },
                            x: {
                                ticks: {
                                    color: '#ffffff'
                                },
                                grid: {
                                    color: 'rgba(255, 255, 255, 0.1)'
                                }
                            }
                        }
                    }
                });
            } else {
                document.getElementById('graficoViagens').innerHTML = '<p class="no-data">Não há dados de viagens por período</p>';
            }
            
            // Novo gráfico de reembolsos por tipo
            const reembolsosPorTipo = {
                'alimentacao': 0,
                'transporte': 0,
                'hospedagem': 0,
                'material': 0,
                'outros': 0
            };
            
            <?php foreach ($relatorio as $viagem): ?>
                <?php foreach ($viagem['detalhes_reembolsos'] as $reembolso): ?>
                    <?php if ($reembolso['status'] === 'aprovado'): ?>
                        reembolsosPorTipo['<?= $reembolso['tipo_despesa'] ?>'] += parseFloat(<?= $reembolso['valor'] ?>);
                    <?php endif; ?>
                <?php endforeach; ?>
            <?php endforeach; ?>
            
            const temReembolsos = Object.values(reembolsosPorTipo).some(valor => valor > 0);
            
            if (temReembolsos) {
                const ctxReembolso = document.getElementById('graficoReembolsos').getContext('2d');
                new Chart(ctxReembolso, {
                    type: 'doughnut',
                    data: {
                        labels: ['Alimentação', 'Transporte', 'Hospedagem', 'Material', 'Outros'],
                        datasets: [{
                            data: [
                                reembolsosPorTipo.alimentacao,
                                reembolsosPorTipo.transporte,
                                reembolsosPorTipo.hospedagem,
                                reembolsosPorTipo.material,
                                reembolsosPorTipo.outros
                            ],
                            backgroundColor: ['#ff9f40', '#36a2eb', '#ff6384', '#ffcd56', '#9966ff'],
                            borderColor: '#ffffff',
                            borderWidth: 2
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                labels: {
                                    color: '#ffffff',
                                    font: {
                                        size: 14
                                    }
                                }
                            },
                            tooltip: {
                                bodyColor: '#ffffff',
                                titleColor: '#ffffff',
                                backgroundColor: 'rgba(0,0,0,0.7)',
                                borderColor: '#ffffff',
                                borderWidth: 1,
                                callbacks: {
                                    label: function(context) {
                                        const label = context.label || '';
                                        const value = context.raw || 0;
                                        const total = Object.values(reembolsosPorTipo).reduce((a, b) => a + b, 0);
                                        const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                                        return `${label}: R$ ${formatCurrency(value)} (${percentage}%)`;
                                    }
                                }
                            }
                        }
                    }
                });
            } else {
                document.getElementById('graficoReembolsos').innerHTML = '<p class="no-data">Não há dados de reembolsos para exibir</p>';
            }

        <?php elseif ($aba === 'geral' && !empty($relatorio['agregados'])): ?>
            // Gráfico de pizza para relatório geral
            const departamentos = <?= json_encode(array_column($relatorio['agregados'], 'departamento')) ?>;
            const custos = <?= json_encode(array_column($relatorio['agregados'], 'custo_total')) ?>;
            
            if (departamentos.length > 0) {
                const ctxPie = document.getElementById('graficoCustos').getContext('2d');
                new Chart(ctxPie, {
                    type: 'pie',
                    data: {
                        labels: departamentos,
                        datasets: [{
                            data: custos,
                            backgroundColor: ['#ff6384', '#36a2eb', '#ffce56', '#4bc0c0', '#9966ff', '#ff9f40'],
                            borderColor: '#ffffff',
                            borderWidth: 2
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                labels: {
                                    color: '#ffffff',
                                    font: {
                                        size: 14
                                    }
                                }
                            },
                            tooltip: {
                                bodyColor: '#ffffff',
                                titleColor: '#ffffff',
                                backgroundColor: 'rgba(0,0,0,0.7)',
                                borderColor: '#ffffff',
                                borderWidth: 1,
                                callbacks: {
                                    label: function(context) {
                                        const label = context.label || '';
                                        const value = context.raw || 0;
                                        const total = custos.reduce((a, b) => a + b, 0);
                                        const percentage = Math.round((value / total) * 100);
                                        return `${label}: R$ ${formatCurrency(value)} (${percentage}%)`;
                                    }
                                }
                            }
                        }
                    }
                });
            } else {
                document.getElementById('graficoCustos').innerHTML = '<p class="no-data">Não há dados de distribuição de custos</p>';
            }

            // Gráfico de barras para viagens por departamento
            const viagensPorDepto = <?= json_encode(array_column($relatorio['agregados'], 'total_viagens')) ?>;
            
            if (departamentos.length > 0 && viagensPorDepto.length > 0) {
                const ctxBar = document.getElementById('graficoViagens').getContext('2d');
                new Chart(ctxBar, {
                    type: 'bar',
                    data: {
                        labels: departamentos,
                        datasets: [{
                            label: 'Viagens por Departamento',
                            data: viagensPorDepto,
                            backgroundColor: '#36a2eb',
                            borderColor: '#ffffff',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                labels: {
                                    color: '#ffffff',
                                    font: {
                                        size: 14
                                    }
                                }
                            },
                            tooltip: {
                                bodyColor: '#ffffff',
                                titleColor: '#ffffff',
                                backgroundColor: 'rgba(0,0,0,0.7)',
                                borderColor: '#ffffff',
                                borderWidth: 1
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    color: '#ffffff',
                                    precision: 0
                                },
                                grid: {
                                    color: 'rgba(255, 255, 255, 0.1)'
                                }
                            },
                            x: {
                                ticks: {
                                    color: '#ffffff'
                                },
                                grid: {
                                    color: 'rgba(255, 255, 255, 0.1)'
                                }
                            }
                        }
                    }
                });
            } else {
                document.getElementById('graficoViagens').innerHTML = '<p class="no-data">Não há dados de viagens por departamento</p>';
            }
            
            // Gráfico de reembolsos por status
            const reembolsoStats = <?= json_encode($relatorio['reembolso_stats'] ?? []) ?>;
            
            if (reembolsoStats && reembolsoStats.total_reembolsos > 0) {
                const ctxReembolso = document.getElementById('graficoReembolsos').getContext('2d');
                new Chart(ctxReembolso, {
                    type: 'doughnut',
                    data: {
                        labels: ['Aprovados', 'Pendentes', 'Recusados'],
                        datasets: [{
                            data: [
                                reembolsoStats.valor_aprovado || 0,
                                reembolsoStats.valor_pendente || 0,
                                reembolsoStats.valor_recusado || 0
                            ],
                            backgroundColor: ['#4bc0c0', '#ffcd56', '#ff6384'],
                            borderColor: '#ffffff',
                            borderWidth: 2
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                labels: {
                                    color: '#ffffff',
                                    font: {
                                        size: 14
                                    }
                                }
                            },
                            tooltip: {
                                bodyColor: '#ffffff',
                                titleColor: '#ffffff',
                                backgroundColor: 'rgba(0,0,0,0.7)',
                                borderColor: '#ffffff',
                                borderWidth: 1,
                                callbacks: {
                                    label: function(context) {
                                        const label = context.label || '';
                                        const value = context.raw || 0;
                                        const total = (reembolsoStats.valor_aprovado || 0) + 
                                                     (reembolsoStats.valor_pendente || 0) + 
                                                     (reembolsoStats.valor_recusado || 0);
                                        const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                                        return `${label}: R$ ${formatCurrency(value)} (${percentage}%)`;
                                    }
                                }
                            }
                        }
                    }
                });
            } else {
                document.getElementById('graficoReembolsos').innerHTML = '<p class="no-data">Não há dados de reembolsos para exibir</p>';
            }
        <?php endif; ?>
    });

    function exportarPDF() {
    // Verifica se as bibliotecas estão disponíveis
    if (typeof jsPDF === 'undefined' || typeof autoTable === 'undefined') {
        // Tenta carregar as bibliotecas dinamicamente se não estiverem disponíveis
        const scriptPDF = document.createElement('script');
        scriptPDF.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
        scriptPDF.onload = function() {
            const scriptAutoTable = document.createElement('script');
            scriptAutoTable.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js';
            scriptAutoTable.onload = gerarPDF;
            document.head.appendChild(scriptAutoTable);
        };
        document.head.appendChild(scriptPDF);
    } else {
        gerarPDF();
    }


    function gerarPDF() {
        try {
            // Usa a versão UMD do jsPDF
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            
            // Configurações iniciais
            doc.setFont('helvetica');
            doc.setFontSize(18);
            doc.setTextColor(40, 53, 147);
            doc.text('Relatório Financeiro de Viagens', 105, 20, { align: 'center' });
            
            // Informações do relatório
            doc.setFontSize(12);
            doc.setTextColor(0, 0, 0);
            doc.text(`Período: ${document.getElementById('data_inicio').value} a ${document.getElementById('data_fim').value}`, 14, 30);
            
            <?php if ($aba === 'geral' && $departamento): ?>
                doc.text(`Departamento: ${document.getElementById('departamento').value}`, 14, 38);
            <?php endif; ?>
            
            doc.text(`Emitido em: ${new Date().toLocaleDateString('pt-BR')}`, 14, 46);
            
            // Resumo estatístico
            doc.setFontSize(14);
            doc.setTextColor(40, 53, 147);
            doc.text('Resumo Estatístico', 14, 60);
            
            doc.setFontSize(12);
            doc.setTextColor(0, 0, 0);
            doc.text(`Total de Viagens: <?= $total_viagens ?>`, 14, 70);
            doc.text(`Custo Total: R$ <?= number_format($custo_total, 2, ',', '.') ?>`, 14, 78);
            doc.text(`Duração Média: <?= round($media_dias, 1) ?> dias`, 14, 86);
            doc.text(`Total de Reembolsos: <?= $total_reembolsos ?>`, 14, 94);
            doc.text(`Valor Reembolsado: R$ <?= number_format($valor_reembolsos, 2, ',', '.') ?>`, 14, 102);
            
            // Preparar dados da tabela
            <?php if ($aba === 'pessoal'): ?>
                doc.setFontSize(14);
                doc.setTextColor(40, 53, 147);
                doc.text('Detalhes das Viagens', 14, 116);
                
                const headers = [['Destino', 'Período', 'Duração', 'Hospedagem', 'Transporte', 'Reembolsos', 'Total']];
                const data = [
                    <?php foreach ($relatorio as $viagem): ?>
                        [
                            '<?= addslashes($viagem['destino']) ?>',
                            '<?= date('d/m/Y', strtotime($viagem['data_inicio'])) ?> - <?= date('d/m/Y', strtotime($viagem['data_fim'])) ?>',
                            '<?= $viagem['dias'] ?> dias',
                            'R$ ' + formatCurrency(<?= $viagem['hospedagem_preco'] ?>),
                            'R$ ' + formatCurrency(<?= $viagem['transporte_preco'] ?>),
                            'R$ ' + formatCurrency(<?= $viagem['reembolso_aprovado'] ?>),
                            'R$ ' + formatCurrency(<?= $viagem['custo'] ?>)
                        ],
                    <?php endforeach; ?>
                ];
                
                // Gerar tabela no PDF
                doc.autoTable({
                    head: headers,
                    body: data,
                    startY: 120,
                    theme: 'grid',
                    headStyles: {
                        fillColor: [41, 60, 106],
                        textColor: [255, 255, 255],
                        fontStyle: 'bold'
                    },
                    bodyStyles: {
                        textColor: [0, 0, 0]
                    },
                    alternateRowStyles: {
                        fillColor: [245, 245, 245]
                    },
                    margin: { top: 120 }
                });
                
                // Adicionar detalhes de reembolsos se houver
                <?php 
                $temReembolsos = false;
                foreach ($relatorio as $viagem) {
                    if (!empty($viagem['detalhes_reembolsos'])) {
                        $temReembolsos = true;
                        break;
                    }
                }
                
                if ($temReembolsos): ?>
                    // Adicionar nova página para reembolsos
                    doc.addPage();
                    
                    doc.setFontSize(14);
                    doc.setTextColor(40, 53, 147);
                    doc.text('Detalhes dos Reembolsos', 14, 20);
                    
                    const headersReembolso = [['Destino', 'Tipo', 'Descrição', 'Valor', 'Status']];
                    const dataReembolso = [
                        <?php foreach ($relatorio as $viagem): ?>
                            <?php foreach ($viagem['detalhes_reembolsos'] as $reembolso): ?>
                                [
                                    '<?= addslashes($viagem['destino']) ?>',
                                    '<?= ucfirst(addslashes($reembolso['tipo_despesa'])) ?>',
                                    '<?= addslashes($reembolso['descricao_despesa']) ?>',
                                    'R$ ' + formatCurrency(<?= $reembolso['valor'] ?>),
                                    '<?= ucfirst($reembolso['status']) ?>'
                                ],
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    ];
                    
                    doc.autoTable({
                        head: headersReembolso,
                        body: dataReembolso,
                        startY: 24,
                        theme: 'grid',
                        headStyles: {
                            fillColor: [41, 60, 106],
                            textColor: [255, 255, 255],
                            fontStyle: 'bold'
                        },
                        bodyStyles: {
                            textColor: [0, 0, 0]
                        },
                        alternateRowStyles: {
                            fillColor: [245, 245, 245]
                        },
                        margin: { top: 24 }
                    });
                <?php endif; ?>
                
            <?php else: ?>
                doc.setFontSize(14);
                doc.setTextColor(40, 53, 147);
                doc.text('Resumo por Departamento', 14, 116);
                
                const headers = [['Departamento', 'Viagens', 'Duração Média', 'Custo Base', 'Reembolsos', 'Custo Total']];
                const data = [
                    <?php foreach ($relatorio['agregados'] as $depto): ?>
                        [
                            '<?= addslashes($depto['departamento']) ?>',
                            <?= $depto['total_viagens'] ?>,
                            '<?= round($depto['media_dias'], 1) ?> dias',
                            'R$ ' + formatCurrency(<?= $depto['custo_base'] ?>),
                            'R$ ' + formatCurrency(<?= $depto['reembolso_total'] ?>),
                            'R$ ' + formatCurrency(<?= $depto['custo_total'] ?>)
                        ],
                    <?php endforeach; ?>
                ];
                
                // Gerar tabela no PDF
                doc.autoTable({
                    head: headers,
                    body: data,
                    startY: 120,
                    theme: 'grid',
                    headStyles: {
                        fillColor: [41, 60, 106],
                        textColor: [255, 255, 255],
                        fontStyle: 'bold'
                    },
                    bodyStyles: {
                        textColor: [0, 0, 0]
                    },
                    alternateRowStyles: {
                        fillColor: [245, 245, 245]
                    },
                    margin: { top: 120 }
                });
                
                // Adicionar nova página para detalhes das viagens
                doc.addPage();
                
                doc.setFontSize(14);
                doc.setTextColor(40, 53, 147);
                doc.text('Detalhes de Todas as Viagens', 14, 20);
                
                const headersDetalhes = [['Funcionário', 'Departamento', 'Destino', 'Período', 'Hospedagem', 'Transporte', 'Reembolsos', 'Total']];
                const dataDetalhes = [
                    <?php foreach ($relatorio['detalhes'] as $viagem): ?>
                        [
                            '<?= addslashes($viagem['funcionario']) ?>',
                            '<?= addslashes($viagem['departamento']) ?>',
                            '<?= addslashes($viagem['destino']) ?>',
                            '<?= date('d/m/Y', strtotime($viagem['data_inicio'])) ?> - <?= date('d/m/Y', strtotime($viagem['data_fim'])) ?>',
                            'R$ ' + formatCurrency(<?= $viagem['hospedagem_preco'] ?>),
                            'R$ ' + formatCurrency(<?= $viagem['transporte_preco'] ?>),
                            'R$ ' + formatCurrency(<?= $viagem['reembolso_aprovado'] ?>),
                            'R$ ' + formatCurrency(<?= $viagem['custo'] ?>)
                        ],
                    <?php endforeach; ?>
                ];
                
                doc.autoTable({
                    head: headersDetalhes,
                    body: dataDetalhes,
                    startY: 24,
                    theme: 'grid',
                    headStyles: {
                        fillColor: [41, 60, 106],
                        textColor: [255, 255, 255],
                        fontStyle: 'bold'
                    },
                    bodyStyles: {
                        textColor: [0, 0, 0]
                    },
                    alternateRowStyles: {
                        fillColor: [245, 245, 245]
                    },
                    margin: { top: 24 }
                });
                
                // Adicionar estatísticas de reembolso
                doc.addPage();
                
                doc.setFontSize(14);
                doc.setTextColor(40, 53, 147);
                doc.text('Estatísticas de Reembolso', 14, 20);
                
                doc.setFontSize(12);
                doc.setTextColor(0, 0, 0);
                doc.text(`Total de Reembolsos: <?= $relatorio['reembolso_stats']['total_reembolsos'] ?? 0 ?>`, 14, 30);
                doc.text(`Reembolsos Aprovados: <?= $relatorio['reembolso_stats']['reembolsos_aprovados'] ?? 0 ?>`, 14, 38);
                doc.text(`Reembolsos Pendentes: <?= $relatorio['reembolso_stats']['reembolsos_pendentes'] ?? 0 ?>`, 14, 46);
                doc.text(`Reembolsos Recusados: <?= $relatorio['reembolso_stats']['reembolsos_recusados'] ?? 0 ?>`, 14, 54);
                doc.text(`Valor Aprovado: R$ <?= number_format($relatorio['reembolso_stats']['valor_aprovado'] ?? 0, 2, ',', '.') ?>`, 14, 62);
                doc.text(`Valor Pendente: R$ <?= number_format($relatorio['reembolso_stats']['valor_pendente'] ?? 0, 2, ',', '.') ?>`, 14, 70);
                doc.text(`Valor Recusado: R$ <?= number_format($relatorio['reembolso_stats']['valor_recusado'] ?? 0, 2, ',', '.') ?>`, 14, 78);
                doc.text(`Média por Reembolso: R$ <?= number_format($relatorio['reembolso_stats']['media_reembolso'] ?? 0, 2, ',', '.') ?>`, 14, 86);
            <?php endif; ?>
            
            // Salvar o PDF
            doc.save(`relatorio_viagens_<?= $aba ?>_${new Date().toISOString().slice(0,10)}.pdf`);
            
        } catch (error) {
            console.error('Erro ao gerar PDF:', error);
            alert('Ocorreu um erro ao gerar o PDF. Verifique o console para mais detalhes.');
        }
    }
}

function exportarExcel() {
    if (typeof XLSX === 'undefined') {
        alert('Erro: Biblioteca SheetJS não carregada. Tente recarregar a página.');
        return;
    }

    const wb = XLSX.utils.book_new();
    
    <?php if ($aba === 'pessoal'): ?>
        // Planilha de viagens
        const dados = [
            ['Destino', 'Data Início', 'Data Fim', 'Duração (dias)', 'Hospedagem (R$)', 'Transporte (R$)', 'Reembolsos (R$)', 'Custo Total (R$)', 'Motivo'],
            <?php foreach ($relatorio as $viagem): ?>
                [
                    '<?= addslashes($viagem['destino']) ?>',
                    '<?= date('d/m/Y', strtotime($viagem['data_inicio'])) ?>',
                    '<?= date('d/m/Y', strtotime($viagem['data_fim'])) ?>',
                    <?= $viagem['dias'] ?>,
                    <?= $viagem['hospedagem_preco'] ?>,
                    <?= $viagem['transporte_preco'] ?>,
                    <?= $viagem['reembolso_aprovado'] ?>,
                    <?= $viagem['custo'] ?>,
                    '<?= addslashes($viagem['motivo']) ?>'
                ],
            <?php endforeach; ?>
        ];
        
        const ws = XLSX.utils.aoa_to_sheet(dados);
        XLSX.utils.book_append_sheet(wb, ws, "Viagens");
        
        // Planilha de reembolsos
        <?php 
        $temReembolsos = false;
        foreach ($relatorio as $viagem) {
            if (!empty($viagem['detalhes_reembolsos'])) {
                $temReembolsos = true;
                break;
            }
        }
        
        if ($temReembolsos): ?>
            const dadosReembolso = [
                ['Destino', 'Tipo de Despesa', 'Descrição', 'Valor (R$)', 'Status', 'Data da Requisição'],
                <?php foreach ($relatorio as $viagem): ?>
                    <?php foreach ($viagem['detalhes_reembolsos'] as $reembolso): ?>
                        [
                            '<?= addslashes($viagem['destino']) ?>',
                            '<?= ucfirst(addslashes($reembolso['tipo_despesa'])) ?>',
                            '<?= addslashes($reembolso['descricao_despesa']) ?>',
                            <?= $reembolso['valor'] ?>,
                            '<?= ucfirst($reembolso['status']) ?>',
                            '<?= date('d/m/Y', strtotime($reembolso['data_requisicao'])) ?>'
                        ],
                    <?php endforeach; ?>
                <?php endforeach; ?>
            ];
            
            const wsReembolso = XLSX.utils.aoa_to_sheet(dadosReembolso);
            XLSX.utils.book_append_sheet(wb, wsReembolso, "Reembolsos");
        <?php endif; ?>
        
        // Planilha de resumo
        const dadosResumo = [
            ['Métrica', 'Valor'],
            ['Total de Viagens', <?= $total_viagens ?>],
            ['Custo Total (R$)', <?= $custo_total ?>],
            ['Duração Média (dias)', <?= $media_dias ?>],
            ['Custo Médio por Viagem (R$)', <?= $total_viagens > 0 ? $custo_total/$total_viagens : 0 ?>],
            ['Total de Reembolsos', <?= $total_reembolsos ?>],
            ['Valor Reembolsado (R$)', <?= $valor_reembolsos ?>]
        ];
        
        const wsResumo = XLSX.utils.aoa_to_sheet(dadosResumo);
        XLSX.utils.book_append_sheet(wb, wsResumo, "Resumo");
        
    <?php else: ?>
        // Planilha de resumo por departamento
        const dadosDepartamento = [
            ['Departamento', 'Viagens', 'Duração Média (dias)', 'Custo Base (R$)', 'Reembolsos (R$)', 'Custo Total (R$)', 'Última Viagem'],
            <?php foreach ($relatorio['agregados'] as $depto): ?>
                [
                    '<?= addslashes($depto['departamento']) ?>',
                    <?= $depto['total_viagens'] ?>,
                    <?= round($depto['media_dias'], 1) ?>,
                    <?= $depto['custo_base'] ?>,
                    <?= $depto['reembolso_total'] ?>,
                    <?= $depto['custo_total'] ?>,
                    '<?= date('d/m/Y', strtotime($depto['ultima_viagem'])) ?>'
                ],
            <?php endforeach; ?>
        ];
        
        const wsDepartamento = XLSX.utils.aoa_to_sheet(dadosDepartamento);
        XLSX.utils.book_append_sheet(wb, wsDepartamento, "Resumo por Departamento");
        
        // Planilha de detalhes das viagens
        const dadosViagens = [
            ['Funcionário', 'Departamento', 'Destino', 'Data Início', 'Data Fim', 'Duração (dias)', 'Hospedagem (R$)', 'Transporte (R$)', 'Reembolsos (R$)', 'Custo Total (R$)'],
            <?php foreach ($relatorio['detalhes'] as $viagem): ?>
                [
                    '<?= addslashes($viagem['funcionario']) ?>',
                    '<?= addslashes($viagem['departamento']) ?>',
                    '<?= addslashes($viagem['destino']) ?>',
                    '<?= date('d/m/Y', strtotime($viagem['data_inicio'])) ?>',
                    '<?= date('d/m/Y', strtotime($viagem['data_fim'])) ?>',
                    <?= $viagem['dias'] ?>,
                    <?= $viagem['hospedagem_preco'] ?>,
                    <?= $viagem['transporte_preco'] ?>,
                    <?= $viagem['reembolso_aprovado'] ?>,
                    <?= $viagem['custo'] ?>
                ],
            <?php endforeach; ?>
        ];
        
        const wsViagens = XLSX.utils.aoa_to_sheet(dadosViagens);
        XLSX.utils.book_append_sheet(wb, wsViagens, "Detalhes das Viagens");
        
        // Planilha de estatísticas de reembolso
        const dadosReembolsoStats = [
            ['Métrica', 'Valor'],
            ['Total de Reembolsos', <?= $relatorio['reembolso_stats']['total_reembolsos'] ?? 0 ?>],
            ['Reembolsos Aprovados', <?= $relatorio['reembolso_stats']['reembolsos_aprovados'] ?? 0 ?>],
            ['Reembolsos Pendentes', <?= $relatorio['reembolso_stats']['reembolsos_pendentes'] ?? 0 ?>],
            ['Reembolsos Recusados', <?= $relatorio['reembolso_stats']['reembolsos_recusados'] ?? 0 ?>],
            ['Valor Aprovado (R$)', <?= $relatorio['reembolso_stats']['valor_aprovado'] ?? 0 ?>],
            ['Valor Pendente (R$)', <?= $relatorio['reembolso_stats']['valor_pendente'] ?? 0 ?>],
            ['Valor Recusado (R$)', <?= $relatorio['reembolso_stats']['valor_recusado'] ?? 0 ?>],
            ['Média por Reembolso (R$)', <?= $relatorio['reembolso_stats']['media_reembolso'] ?? 0 ?>]
        ];
        
        const wsReembolsoStats = XLSX.utils.aoa_to_sheet(dadosReembolsoStats);
        XLSX.utils.book_append_sheet(wb, wsReembolsoStats, "Estatísticas de Reembolso");
        
        // Planilha de resumo geral
        const dadosResumo = [
            ['Métrica', 'Valor'],
            ['Total de Viagens', <?= $total_viagens ?>],
            ['Custo Total (R$)', <?= $custo_total ?>],
            ['Duração Média (dias)', <?= $media_dias ?>],
            ['Custo Médio por Viagem (R$)', <?= $total_viagens > 0 ? $custo_total/$total_viagens : 0 ?>],
            ['Total de Reembolsos', <?= $total_reembolsos ?>],
            ['Valor Reembolsado (R$)', <?= $valor_reembolsos ?>]
        ];
        
        const wsResumo = XLSX.utils.aoa_to_sheet(dadosResumo);
        XLSX.utils.book_append_sheet(wb, wsResumo, "Resumo Geral");
    <?php endif; ?>
    
    // Exportar o arquivo Excel
    XLSX.writeFile(wb, `relatorio_viagens_<?= $aba ?>_${new Date().toISOString().slice(0,10)}.xlsx`);
}
    </script>
</body>
</html>

