<?php
require 'includes/protecao.php';
require 'includes/conexao.php';

// Verifica se é admin/chefe
if ($_SESSION['usuario_tipo'] !== 'admin' && $_SESSION['usuario_tipo'] !== 'chefe') {
    header('Location: painel.php?erro=Acesso negado');
    exit;
}

// Consulta usuários (excluindo o próprio usuário logado)
$sql = "SELECT id_usuario, nome, email, tipo, departamento, cargo 
        FROM Usuario 
        WHERE id_usuario != ?";
$stmt = $conexao->prepare($sql);
$stmt->bind_param("i", $_SESSION['usuario_id']);
$stmt->execute();
$usuarios = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Consulta contagem de viagens por usuário (opcional)
$viagens_por_usuario = [];
$sql_viagens = "SELECT id_usuario_solicitante, COUNT(*) as total 
                FROM SolicitacaoViagem 
                GROUP BY id_usuario_solicitante";
$result = $conexao->query($sql_viagens);
while ($row = $result->fetch_assoc()) {
    $viagens_por_usuario[$row['id_usuario_solicitante']] = $row['total'];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Administração de Funcionários</title>
  <link rel="stylesheet" href="css/painel.css">
  <link rel="stylesheet" href="css/administracao.css">
</head>
<body>
  <?php include 'includes/header.php'; ?>

  <div class="admin-container">
    <h1>Administração de Funcionários</h1>
    
    <div class="search-bar">
      <input type="text" id="busca-input" placeholder="Pesquisar funcionário por nome ou departamento">
      <button id="buscar-btn">Buscar</button>
    </div>
    
    <div class="employees-list" id="lista-usuarios">
      <?php foreach ($usuarios as $usuario): ?>
        <div class="employee-card" onclick="openModal(<?= $usuario['id_usuario'] ?>)">
          <div class="employee-header">
            <span class="employee-name"><?= htmlspecialchars($usuario['nome']) ?></span>
            <span class="employee-department"><?= htmlspecialchars($usuario['departamento']) ?></span>
          </div>
          <div class="employee-details">
            <div class="detail-item">
              <div class="detail-label">E-mail</div>
              <div><?= htmlspecialchars($usuario['email']) ?></div>
            </div>
            <div class="detail-item">
              <div class="detail-label">Cargo</div>
              <div><?= htmlspecialchars($usuario['cargo']) ?></div>
            </div>
            <div class="detail-item">
              <div class="detail-label">Viagens (12 meses)</div>
              <div><?= $viagens_por_usuario[$usuario['id_usuario']] ?? 0 ?> viagens</div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Modal de Histórico de Viagens -->
  <div class="modal" id="historyModal">
    <div class="modal-content">
      <div class="modal-header">
        <h2 class="modal-title">Histórico de Viagens</h2>
        <button class="close-modal" onclick="closeModal()">&times;</button>
      </div>
      
      <div id="modalEmployeeInfo">
        <!-- Preenchido dinamicamente via JS -->
      </div>
      
      <div class="travel-history">
        <h3>Últimas Viagens</h3>
        <div id="historico-viagens">
          <!-- Preenchido dinamicamente via AJAX -->
        </div>
      </div>
    </div>
  </div>

  <script src="js/administracao.js"></script>
</body>
</html>