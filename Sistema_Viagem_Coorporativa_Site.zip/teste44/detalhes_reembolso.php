<?php
require 'includes/protecao.php';
require 'includes/conexao.php';

// Verifica se o ID foi passado
if (!isset($_GET['id'])) {
    header('Location: reembolso.php?erro=ID não especificado');
    exit;
}

$reembolso_id = intval($_GET['id']);
$usuario_id = $_SESSION['usuario_id'];
$isAdmin = ($_SESSION['usuario_tipo'] === 'admin' || $_SESSION['usuario_tipo'] === 'chefe');

// Consulta para obter detalhes do reembolso
$sql = "
    SELECT r.id_reembolso, r.id_viagem, r.descricao_despesa, r.valor, r.tipo_despesa,
           r.data_requisicao, r.status, r.motivo_recusa, r.id_usuario_aprovador,
           v.destino, v.data_inicio, v.data_fim,
           u.nome as solicitante_nome, u.email as solicitante_email,
           a.nome as aprovador_nome, a.email as aprovador_email,
           r.comprovante_path
    FROM Reembolso r
    JOIN Viagem v ON r.id_viagem = v.id_viagem
    JOIN Usuario u ON v.id_usuario = u.id_usuario
    LEFT JOIN Usuario a ON r.id_usuario_aprovador = a.id_usuario
    WHERE r.id_reembolso = ?
";

// Para não-admins, verifica se o usuário é o solicitante
if (!$isAdmin) {
    $sql .= " AND v.id_usuario = ?";
}

$stmt = $conexao->prepare($sql);

if ($isAdmin) {
    $stmt->bind_param("i", $reembolso_id);
} else {
    $stmt->bind_param("ii", $reembolso_id, $usuario_id);
}

$stmt->execute();
$reembolso = $stmt->get_result()->fetch_assoc();

if (!$reembolso) {
    header('Location: reembolso.php?erro=Reembolso não encontrado');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes do Reembolso - Sistema de Viagens</title>
    <link rel="stylesheet" href="css/painel.css">
    <link rel="stylesheet" href="css/detalhes_reembolso.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="dashboard-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <h1 class="section-title">Detalhes do Reembolso #<?= $reembolso['id_reembolso'] ?></h1>
            
            <?php if (isset($_GET['sucesso'])): ?>
                <div class="mensagem sucesso"><?= htmlspecialchars($_GET['sucesso']) ?></div>
            <?php endif; ?>
            
            <div class="card-detalhes">
                <div class="detalhe-item">
                    <span class="detalhe-label">Status</span>
                    <span class="detalhe-value status-<?= $reembolso['status'] ?>">
                        <?= ucfirst($reembolso['status']) ?>
                        <?php if ($reembolso['status'] === 'recusado' && $reembolso['motivo_recusa']): ?>
                            - <?= htmlspecialchars($reembolso['motivo_recusa']) ?>
                        <?php endif; ?>
                    </span>
                </div>
                
                <div class="detalhe-item">
                    <span class="detalhe-label">Viagem Relacionada</span>
                    <span class="detalhe-value">
                        <?= htmlspecialchars($reembolso['destino']) ?>
                        (<?= date('d/m/Y', strtotime($reembolso['data_inicio'])) ?> - 
                        <?= date('d/m/Y', strtotime($reembolso['data_fim'])) ?>)
                    </span>
                </div>
                
                <div class="detalhe-item">
                    <span class="detalhe-label">Solicitante</span>
                    <span class="detalhe-value">
                        <?= htmlspecialchars($reembolso['solicitante_nome']) ?>
                        (<?= htmlspecialchars($reembolso['solicitante_email']) ?>)
                    </span>
                </div>
                
                <div class="detalhe-item">
                    <span class="detalhe-label">Data da Solicitação</span>
                    <span class="detalhe-value">
                        <?= date('d/m/Y H:i', strtotime($reembolso['data_requisicao'])) ?>
                    </span>
                </div>
                
                <div class="detalhe-item">
                    <span class="detalhe-label">Tipo de Despesa</span>
                    <span class="detalhe-value">
                        <?= match($reembolso['tipo_despesa']) {
                            'alimentacao' => 'Alimentação',
                            'transporte' => 'Transporte Local',
                            'hospedagem' => 'Hospedagem Extra',
                            'material' => 'Material de Trabalho',
                            'outros' => 'Outros',
                            default => $reembolso['tipo_despesa']
                        } ?>
                    </span>
                </div>
                
                <div class="detalhe-item">
                    <span class="detalhe-label">Valor Solicitado</span>
                    <span class="detalhe-value">
                        R$ <?= number_format($reembolso['valor'], 2, ',', '.') ?>
                    </span>
                </div>
                
                <div class="detalhe-item">
                    <span class="detalhe-label">Descrição/Motivo</span>
                    <span class="detalhe-value">
                        <?= nl2br(htmlspecialchars($reembolso['descricao_despesa'])) ?>
                    </span>
                </div>
                
                <?php if ($reembolso['comprovante_path']): ?>
                <div class="detalhe-item comprovante-container">
                    <span class="detalhe-label">Comprovante</span>
                    <?php if (strpos($reembolso['comprovante_path'], '.pdf') !== false): ?>
                        <a href="<?= htmlspecialchars($reembolso['comprovante_path']) ?>" 
                           target="_blank" class="btn-detalhes">
                            Visualizar PDF
                        </a>
                    <?php else: ?>
                        <img src="<?= htmlspecialchars($reembolso['comprovante_path']) ?>" 
                             class="comprovante-img" 
                             alt="Comprovante de reembolso">
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                
                <?php if ($reembolso['status'] === 'aprovado' && $reembolso['aprovador_nome']): ?>
                <div class="detalhe-item">
                    <span class="detalhe-label">Aprovado por</span>
                    <span class="detalhe-value">
                        <?= htmlspecialchars($reembolso['aprovador_nome']) ?>
                        (<?= htmlspecialchars($reembolso['aprovador_email']) ?>) em
                        <?= date('d/m/Y H:i', strtotime($reembolso['data_aprovacao'])) ?>
                    </span>
                </div>
                <?php endif; ?>
                
                <?php if ($isAdmin && $reembolso['status'] === 'pendente'): ?>
                <div class="acoes-admin">
                    <h3>Ações de Administrador</h3>
                    <form id="form-aprovacao" method="POST">
                        <input type="hidden" name="id_reembolso" value="<?= $reembolso['id_reembolso'] ?>">
                        
                        <button type="button" id="btn-aprovar" class="btn-acao btn-aprovar">
                            Aprovar Reembolso
                        </button>
                        
                        <button type="button" id="btn-recusar" class="btn-acao btn-recusar">
                            Recusar Reembolso
                        </button>
                        
                        <div id="motivo-recusa" class="motivo-recusa">
                            <label for="motivo" class="detalhe-label">Motivo da Recusa</label>
                            <textarea id="motivo" name="motivo" class="form-control" rows="3" required></textarea>
                            <button type="submit" id="btn-confirmar-recusa" class="btn-acao btn-recusar">
                                Confirmar Recusa
                            </button>
                        </div>
                    </form>
                </div>
                <?php endif; ?>
            </div>
            
            <a href="reembolso.php" class="btn-detalhes">Voltar para Lista</a>
        </main>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const btnAprovar = document.getElementById('btn-aprovar');
        const btnRecusar = document.getElementById('btn-recusar');
        const motivoDiv = document.getElementById('motivo-recusa');
        const formAprovacao = document.getElementById('form-aprovacao');
        const btnConfirmarRecusa = document.getElementById('btn-confirmar-recusa');

        // Aprovar reembolso
        if (btnAprovar) {
            btnAprovar.addEventListener('click', function() {
                if (confirm('Deseja aprovar este reembolso?')) {
                    fetch('api/aprovar_reembolso.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            id: <?= $reembolso['id_reembolso'] ?>,
                            acao: 'aprovar'
                        })
                    })
                    .then(response => {
                        if (!response.ok) throw new Error('Erro na rede');
                        return response.json();
                    })
                    .then(data => {
                        if (data.success) {
                            window.location.href = 'reembolso.php?sucesso=Reembolso aprovado com sucesso';
                        } else {
                            alert('Erro: ' + data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Erro:', error);
                        alert('Falha ao aprovar. Tente novamente.');
                    });
                }
            });
        }

        // Mostrar/ocultar campo de motivo para recusa
        if (btnRecusar) {
            btnRecusar.addEventListener('click', function() {
                motivoDiv.style.display = motivoDiv.style.display === 'block' ? 'none' : 'block';
            });
        }

        // Enviar recusa com motivo
        if (formAprovacao) {
            formAprovacao.addEventListener('submit', function(e) {
                e.preventDefault();
                const motivo = document.getElementById('motivo').value.trim();
                
                if (!motivo) {
                    alert('Por favor, insira o motivo da recusa');
                    return;
                }

                fetch('api/aprovar_reembolso.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        id: <?= $reembolso['id_reembolso'] ?>,
                        acao: 'recusar',
                        motivo: motivo
                    })
                })
                .then(response => {
                    if (!response.ok) throw new Error('Erro na rede');
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        window.location.href = 'reembolso.php?sucesso=Reembolso recusado com sucesso';
                    } else {
                        alert('Erro: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                    alert('Falha ao recusar. Tente novamente.');
                });
            });
        }
    });
    </script>
</body>
</html>