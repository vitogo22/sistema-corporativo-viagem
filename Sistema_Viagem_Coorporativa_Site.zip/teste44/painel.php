<?php
require 'includes/protecao.php';
require 'includes/conexao.php';

// Obtém dados do usuário
$usuario_id = $_SESSION['usuario_id'];
$stmt = $conexao->prepare("SELECT nome, email, tipo, departamento FROM Usuario WHERE id_usuario = ?");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$usuario = $stmt->get_result()->fetch_assoc();

// Obtém estatísticas reais
$stats = [];
$stmt = $conexao->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN sv.status_aprovacao = 'aprovada' THEN 1 ELSE 0 END) as aprovadas,
        SUM(CASE WHEN sv.status_aprovacao = 'pendente' THEN 1 ELSE 0 END) as pendentes,
        SUM(IFNULL(h.preco_total, 0) + IFNULL(t.preco_total, 0)) as gasto_total
    FROM Viagem v
    JOIN SolicitacaoViagem sv ON v.id_viagem = sv.id_viagem
    LEFT JOIN Hospedagem h ON v.id_hospedagem = h.id_hospedagem
    LEFT JOIN Transporte t ON v.id_transporte = t.id_transporte
    WHERE sv.id_usuario_solicitante = ?
");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();

// Obtém dados para o gráfico de status
$statusData = [];
$stmt = $conexao->prepare("
    SELECT sv.status_aprovacao, COUNT(*) as total 
    FROM SolicitacaoViagem sv
    WHERE sv.id_usuario_solicitante = ?
    GROUP BY sv.status_aprovacao
");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$statusData = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Obtém solicitações de viagem recentes
$solicitacoes = [];
$stmt = $conexao->prepare("
    SELECT v.id_viagem, v.destino, v.data_inicio, v.data_fim, sv.status_aprovacao as status
    FROM Viagem v
    JOIN SolicitacaoViagem sv ON v.id_viagem = sv.id_viagem
    WHERE sv.id_usuario_solicitante = ?
    ORDER BY v.data_inicio DESC
    LIMIT 3
");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$solicitacoes = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Painel do Usuário</title>
  <link rel="stylesheet" href="css/painel.css">
  <style>
    .chart-container {
      background: #2E5C8E;
      border-radius: 8px;
      padding: 20px;
      margin: 30px 0;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2);
    }
    .stats-container {
      display: flex;
      gap: 20px;
      flex-wrap: wrap;
      margin-top: 20px;
    }
    .stat-card {
      background: #2E5C8E;
      padding: 20px;
      border-radius: 8px;
      flex: 1;
      min-width: 200px;
      box-shadow: 0 3px 8px rgba(0,0,0,0.2);
    }
    .stat-card h3 {
      margin-top: 0;
      color: #56A0D3;
      font-size: 1.2em;
      border-bottom: 1px solid #3a6a9e;
      padding-bottom: 10px;
    }
    .stat-card p {
      margin: 8px 0;
      color: #E1E1E1;
    }
    .valor-negativo {
      color:rgb(255, 255, 255);
    }
    .valor-positivo {
      color:rgb(255, 255, 255);
    }
  </style>
</head>
<body>
  <?php include 'includes/header.php'; ?>
  
  <div class="dashboard-container">
    <?php include 'includes/sidebar.php'; ?>
    
    <main class="main-content">
      <h1 class="section-title">Bem-vindo, <?php echo htmlspecialchars($usuario['nome']); ?></h1>
      
      <div class="stats-container">
        <div class="stat-card">
          <h3>Solicitações</h3>
          <p>Total: <?= $stats['total'] ?></p>
          <p>Aprovadas: <?= $stats['aprovadas'] ?></p>
          <p>Pendentes: <?= $stats['pendentes'] ?></p>
        </div>
        <div class="stat-card">
          <h3>Gastos</h3>
          <p>Total: <span class="valor-negativo">R$ <?= number_format($stats['gasto_total'], 2, ',', '.') ?></span></p>
          <p>Média por viagem: <span class="valor-negativo">R$ <?= 
            $stats['total'] ? number_format($stats['gasto_total']/$stats['total'], 2, ',', '.') : '0,00'
          ?></span></p>
        </div>
      </div>
      
      <h2 class="section-title">Minhas Solicitações Recentes</h2>
      
      <?php foreach ($solicitacoes as $solicitacao): ?>
      <div class="request-card">
        <div class="request-info">
          <h3><?php echo htmlspecialchars($solicitacao['destino']); ?></h3>
          <p>
            <?php echo date('d/m/Y', strtotime($solicitacao['data_inicio'])); ?> - 
            <?php echo date('d/m/Y', strtotime($solicitacao['data_fim'])); ?>
          </p>
          <span class="request-status status-<?php echo strtolower($solicitacao['status']); ?>">
            <?php echo htmlspecialchars($solicitacao['status']); ?>
          </span>
        </div>
        <a href="detalhes.php?id=<?= $solicitacao['id_viagem'] ?>" class="action-btn">Ver Detalhes</a>
      </div>
      <?php endforeach; ?>
      
      <div style="text-align: center; margin-top: 30px;">
        <a href="solicitacoes.php" class="action-btn">Ver Todas as Solicitações</a>
        <a href="nova_solicitacao.php" class="action-btn">Nova Solicitação</a>
      </div>
    </main>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      <?php if (!empty($statusData)): ?>
        const statusCtx = document.getElementById('statusChart').getContext('2d');
        const statusLabels = {
          'aprovada': 'Aprovadas',
          'pendente': 'Pendentes',
          'recusada': 'Recusadas'
        };
        
        new Chart(statusCtx, {
          type: 'doughnut',
          data: {
            labels: <?= json_encode(array_map(function($item) use ($statusLabels) {
              return $statusLabels[$item['status_aprovacao']] ?? $item['status_aprovacao'];
            }, $statusData)) ?>,
            datasets: [{
              data: <?= json_encode(array_column($statusData, 'total')) ?>,
              backgroundColor: [
                'rgba(75, 192, 192, 0.7)',
                'rgba(255, 206, 86, 0.7)',
                'rgba(255, 99, 132, 0.7)'
              ],
              borderWidth: 1
            }]
          },
          options: {
            responsive: true,
            plugins: {
              legend: {
                position: 'bottom',
              },
              tooltip: {
                callbacks: {
                  label: function(context) {
                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                    const value = context.raw;
                    const percentage = Math.round((value / total) * 100);
                    return `${context.label}: ${value} (${percentage}%)`;
                  }
                }
              }
            }
          }
        });
      <?php endif; ?>
    });
  </script>
</body>
</html>
