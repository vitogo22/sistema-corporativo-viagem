document.addEventListener('DOMContentLoaded', function() {
    // Filtro de busca
    const buscaInput = document.getElementById('busca-input');
    const buscarBtn = document.getElementById('buscar-btn');
    
    buscarBtn.addEventListener('click', filtrarUsuarios);
    buscaInput.addEventListener('keyup', function(e) {
        if (e.key === 'Enter') filtrarUsuarios();
    });
    
    function filtrarUsuarios() {
        const termo = buscaInput.value.toLowerCase();
        const cards = document.querySelectorAll('.employee-card');
        
        cards.forEach(card => {
            const texto = card.textContent.toLowerCase();
            card.style.display = texto.includes(termo) ? 'block' : 'none';
        });
    }
});

// Funções do Modal
function openModal(userId) {
    const modal = document.getElementById('historyModal');
    modal.style.display = 'block';
    
    // Carrega dados do usuário via AJAX
    fetch(`api/detalhes_usuario.php?id=${userId}`)
        .then(response => response.json())
        .then(data => {
            updateModalContent(data.usuario);
            carregarHistoricoViagens(userId);
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Erro ao carregar dados do usuário');
        });
}

function closeModal() {
    document.getElementById('historyModal').style.display = 'none';
}

function updateModalContent(usuario) {
    const modalContent = `
        <div class="employee-info">
            <p><strong>Nome:</strong> ${usuario.nome}</p>
            <p><strong>Departamento:</strong> ${usuario.departamento}</p>
            <p><strong>Cargo:</strong> ${usuario.cargo}</p>
            <p><strong>E-mail:</strong> ${usuario.email}</p>
            <p><strong>Tipo:</strong> ${formatTipoUsuario(usuario.tipo)}</p>
        </div>
    `;
    document.getElementById('modalEmployeeInfo').innerHTML = modalContent;
}

function carregarHistoricoViagens(userId) {
    fetch(`api/historico_viagens.php?usuario_id=${userId}`)
        .then(response => response.json())
        .then(data => {
            const historicoHTML = data.viagens.map(viagem => `
                <div class="history-item">
                    <div class="history-destination">${viagem.destino}</div>
                    <div class="history-dates">
                        ${formatDate(viagem.data_inicio)} a ${formatDate(viagem.data_fim)} 
                        (${calculateDays(viagem.data_inicio, viagem.data_fim)} dias)
                    </div>
                    <div class="history-details">
                        <span class="history-status status-${viagem.status.toLowerCase()}">
                            ${viagem.status}
                        </span>
                    </div>
                </div>
            `).join('');
            
            document.getElementById('historico-viagens').innerHTML = historicoHTML || 
                '<p>Nenhuma viagem encontrada para este usuário.</p>';
        })
        .catch(error => {
            console.error('Erro:', error);
            document.getElementById('historico-viagens').innerHTML = 
                '<p>Erro ao carregar histórico de viagens.</p>';
        });
}

// Funções auxiliares
function formatTipoUsuario(tipo) {
    const tipos = {
        'funcionario': 'Funcionário',
        'chefe': 'Chefe',
        'admin': 'Administrador'
    };
    return tipos[tipo] || tipo;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}

function calculateDays(start, end) {
    const startDate = new Date(start);
    const endDate = new Date(end);
    return Math.round((endDate - startDate) / (1000 * 60 * 60 * 24)) + 1;
}

// Fechar modal ao clicar fora
window.onclick = function(event) {
    const modal = document.getElementById('historyModal');
    if (event.target === modal) {
        closeModal();
    }
}