document.addEventListener('DOMContentLoaded', function() {
    // Interação com os botões de ação
    document.querySelectorAll('.action-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const card = this.closest('.request-card');
            const status = card.querySelector('.request-status').textContent.toLowerCase();
            
            switch(this.textContent.toLowerCase()) {
                case 'cancelar':
                    if(confirm('Tem certeza que deseja cancelar esta solicitação?')) {
                        // Aqui você adicionaria a chamada AJAX/Fetch para o backend
                        card.querySelector('.request-status').className = 'request-status status-cancelada';
                        card.querySelector('.request-status').textContent = 'Cancelada';
                        this.disabled = true;
                        this.textContent = 'Cancelado';
                        alert('Solicitação cancelada com sucesso!');
                    }
                    break;
                    
                case 'ver detalhes':
                    // Redireciona para página de detalhes com ID da solicitação
                    window.location.href = `detalhes.php?id=${card.dataset.id}`;
                    break;
                    
                case 'justificar':
                    const justificativa = prompt('Digite sua justificativa:');
                    if(justificativa) {
                        // Enviar justificativa para o backend
                        alert('Justificativa enviada!');
                    }
                    break;
            }
        });
    });

    // Aqui você pode adicionar outras interações específicas
}); 