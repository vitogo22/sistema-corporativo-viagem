<?php
require 'includes/protecao.php';
require 'includes/conexao.php';
require '../vendor/autoload.php'; // Requer o Composer (instalar com: composer require tecnickcom/tcpdf)

if (!isset($_GET['id'])) {
    header('Location: reembolso.php');
    exit;
}

$reembolso_id = intval($_GET['id']);
$usuario_id = $_SESSION['usuario_id'];

// Consulta similar à detalhes_reembolso.php
$stmt = $conexao->prepare("..."); // Use a mesma consulta do detalhes_reembolso.php
$stmt->bind_param("i", $reembolso_id);
$stmt->execute();
$reembolso = $stmt->get_result()->fetch_assoc();

if (!$reembolso) {
    header('Location: reembolso.php?erro=Reembolso não encontrado');
    exit;
}

// Criar PDF
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

$pdf->SetCreator('Sistema de Viagens Corporativas');
$pdf->SetAuthor($reembolso['solicitante_nome']);
$pdf->SetTitle('Comprovante de Reembolso #' . $reembolso_id);
$pdf->AddPage();

// Conteúdo do PDF
$html = '
<h1>Comprovante de Reembolso #' . $reembolso_id . '</h1>
<table border="1" cellpadding="5">
    <tr>
        <th width="30%">Campo</th>
        <th width="70%">Valor</th>
    </tr>
    <tr>
        <td><b>Status</b></td>
        <td>' . ucfirst($reembolso['status']) . '</td>
    </tr>
    <tr>
        <td><b>Viagem Relacionada</b></td>
        <td>' . htmlspecialchars($reembolso['destino']) . ' (' . 
        date('d/m/Y', strtotime($reembolso['data_inicio'])) . ' a ' . 
        date('d/m/Y', strtotime($reembolso['data_fim'])) . ')</td>
    </tr>
    <tr>
        <td><b>Solicitante</b></td>
        <td>' . htmlspecialchars($reembolso['solicitante_nome']) . ' (' . 
        htmlspecialchars($reembolso['solicitante_email']) . ')</td>
    </tr>
    <tr>
        <td><b>Data da Solicitação</b></td>
        <td>' . date('d/m/Y H:i', strtotime($reembolso['data_requisicao'])) . '</td>
    </tr>
    <tr>
        <td><b>Tipo de Despesa</b></td>
        <td>' . ucfirst($reembolso['tipo_despesa']) . '</td>
    </tr>
    <tr>
        <td><b>Valor</b></td>
        <td>R$ ' . number_format($reembolso['valor'], 2, ',', '.') . '</td>
    </tr>
    <tr>
        <td><b>Descrição</b></td>
        <td>' . nl2br(htmlspecialchars($reembolso['motivo'])) . '</td>
    </tr>
</table>';

$pdf->writeHTML($html, true, false, true, false, '');
$pdf->Output('reembolso_' . $reembolso_id . '.pdf', 'I'); // 'I' para visualizar no navegador