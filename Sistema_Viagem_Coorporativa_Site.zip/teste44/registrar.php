<?php
// Inclui o arquivo de conexão
require 'includes/conexao.php';

// Variáveis para mensagens e dados do formulário
$erro = '';
$sucesso = '';
$dados = [
    'nome' => '',
    'email' => '',
    'departamento' => '',
    'cargo' => '',
    'tipo' => 'funcionario' // Valor padrão
];

// Processa o formulário quando enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recebe e sanitiza os dados
    $dados = [
        'nome' => filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING),
        'email' => filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL),
        'senha' => $_POST['senha'],
        'departamento' => filter_input(INPUT_POST, 'departamento', FILTER_SANITIZE_STRING),
        'cargo' => filter_input(INPUT_POST, 'cargo', FILTER_SANITIZE_STRING),
        'tipo' => filter_input(INPUT_POST, 'tipo', FILTER_SANITIZE_STRING),
    ];

    // Validações
    if (empty($dados['nome']) || empty($dados['email']) || empty($dados['senha'])) {
        $erro = 'Nome, e-mail e senha são obrigatórios!';
    } elseif (!filter_var($dados['email'], FILTER_VALIDATE_EMAIL)) {
        $erro = 'E-mail inválido!';
    } elseif (strlen($dados['senha']) < 6) {
        $erro = 'A senha deve ter pelo menos 6 caracteres!';
    } elseif (!in_array($dados['tipo'], ['funcionario', 'chefe', 'admin'])) {
        $erro = 'Tipo de usuário inválido!';
    } else {
        // Verifica se o e-mail já existe
        $stmt = $conexao->prepare("SELECT id_usuario FROM Usuario WHERE email = ?");
        $stmt->bind_param("s", $dados['email']);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $erro = 'Este e-mail já está cadastrado!';
        } else {
            // Hash da senha
            $senha_hash = password_hash($dados['senha'], PASSWORD_DEFAULT);

            // Insere no banco de dados
            $stmt = $conexao->prepare("INSERT INTO Usuario 
                (nome, email, senha, tipo, departamento, cargo) 
                VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssss", 
                $dados['nome'], 
                $dados['email'], 
                $senha_hash,
                $dados['tipo'],
                $dados['departamento'],
                $dados['cargo']);

            if ($stmt->execute()) {
                $sucesso = 'Usuário cadastrado com sucesso!';
                // Limpa os dados do formulário
                $dados = [
                    'nome' => '',
                    'email' => '',
                    'departamento' => '',
                    'cargo' => '',
                    'tipo' => 'funcionario'
                ];
            } else {
                $erro = 'Erro ao cadastrar usuário: ' . $conexao->error;
            }
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastro de Usuário</title>
  <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<div class="register-container">
  <h2>Crie sua Conta</h2>

  <?php if ($erro): ?>
    <div class="mensagem erro"><?php echo $erro; ?></div>
  <?php endif; ?>

  <?php if ($sucesso): ?>
    <div class="mensagem sucesso"><?php echo $sucesso; ?></div>
  <?php endif; ?>

  <!-- Formulário de Registro -->
  <form action="registrar.php" method="POST">
    <div class="input-group">
      <input type="text" name="nome" class="input-field" placeholder="Digite seu nome" 
             value="<?php echo htmlspecialchars($dados['nome']); ?>" required>
    </div>
    
    <div class="input-group">
      <input type="email" name="email" class="input-field" placeholder="Digite seu e-mail" 
             value="<?php echo htmlspecialchars($dados['email']); ?>" required>
    </div>
    
    <div class="input-group">
      <input type="password" name="senha" class="input-field" placeholder="Digite sua senha" required>
    </div>
    
    <div class="input-group">
      <input type="text" name="departamento" class="input-field" placeholder="Digite seu Departamento" 
             value="<?php echo htmlspecialchars($dados['departamento']); ?>">
    </div>
    
    <div class="input-group">
      <input type="text" name="cargo" class="input-field" placeholder="Digite seu Cargo" 
             value="<?php echo htmlspecialchars($dados['cargo']); ?>">
    </div>
    
    <!-- Radio buttons estilizados conforme seu CSS -->
    <div class="input-group" style="margin-top: 20px;">
      <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
        <label style="display: flex; align-items: center; cursor: pointer;">
          <input type="radio" name="tipo" value="funcionario" 
                 <?php echo ($dados['tipo'] == 'funcionario') ? 'checked' : ''; ?> required
                 style="margin-right: 8px; accent-color: #56A0D3;">
          Funcionário
        </label>
        
        <label style="display: flex; align-items: center; cursor: pointer;">
          <input type="radio" name="tipo" value="chefe" 
                 <?php echo ($dados['tipo'] == 'chefe') ? 'checked' : ''; ?>
                 style="margin-right: 8px; accent-color: #56A0D3;">
          Chefe
        </label>
        
        <label style="display: flex; align-items: center; cursor: pointer;">
          <input type="radio" name="tipo" value="admin" 
                 <?php echo ($dados['tipo'] == 'admin') ? 'checked' : ''; ?>
                 style="margin-right: 8px; accent-color: #56A0D3;">
          Admin
        </label>
      </div>
    </div>
    
    <button type="submit" class="register-btn">Registrar</button>
  </form>

  <a href="login.php" class="login-link">Já tem uma conta? Faça login aqui!</a>
</div>

</body>
</html>