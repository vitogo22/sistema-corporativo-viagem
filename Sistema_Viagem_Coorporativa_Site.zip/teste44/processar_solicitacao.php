<?php
require 'includes/protecao.php';
require 'includes/conexao.php';

// Verifica se é funcionário e tem dados na sessão
if ($_SESSION['usuario_tipo'] !== 'funcionario' || !isset($_SESSION['dados_viagem'])) {
    header('Location: painel.php?erro=Acesso negado');
    exit;
}

$dados = $_SESSION['dados_viagem'];

try {
    $conexao->begin_transaction();

    // 1. Insere hospedagem (se existir)
    $id_hospedagem = null;
    if (!empty($dados['hospedagem']['nome'])) {
        $stmt = $conexao->prepare("
            INSERT INTO Hospedagem (nome, endereco, cidade, data_checkin, data_checkout, preco_total)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param(
            "sssssd",
            $dados['hospedagem']['nome'],
            $dados['hospedagem']['endereco'],
            $dados['hospedagem']['cidade'],
            $dados['hospedagem']['data_checkin'],
            $dados['hospedagem']['data_checkout'],
            $dados['hospedagem']['preco_total']
        );
        $stmt->execute();
        $id_hospedagem = $conexao->insert_id;
    }

    // 2. Insere transporte
    $stmt = $conexao->prepare("
        INSERT INTO Transporte (tipo, origem, destino, data_saida, data_chegada, preco_total)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param(
        "sssssd",
        $dados['transporte']['tipo'],
        $dados['transporte']['origem'],
        $dados['transporte']['destino'],
        $dados['transporte']['data_saida'],
        $dados['transporte']['data_chegada'],
        $dados['transporte']['preco_total']
    );
    $stmt->execute();
    $id_transporte = $conexao->insert_id;

    // 3. Insere viagem
    $destino = $dados['transporte']['destino']; // Ou outro critério para definir o destino
    $data_inicio = min($dados['transporte']['data_saida'], $dados['hospedagem']['data_checkin'] ?? $dados['transporte']['data_saida']);
    $data_fim = max($dados['transporte']['data_chegada'], $dados['hospedagem']['data_checkout'] ?? $dados['transporte']['data_chegada']);

    $stmt = $conexao->prepare("
        INSERT INTO Viagem (destino, data_inicio, data_fim, id_usuario, id_hospedagem, id_transporte, status)
        VALUES (?, ?, ?, ?, ?, ?, 'solicitada')
    ");
    $stmt->bind_param(
        "sssiii",
        $destino,
        $data_inicio,
        $data_fim,
        $_SESSION['usuario_id'],
        $id_hospedagem,
        $id_transporte
    );
    $stmt->execute();
    $id_viagem = $conexao->insert_id;

    // 4. Insere solicitação
    $stmt = $conexao->prepare("
        INSERT INTO SolicitacaoViagem (id_viagem, id_usuario_solicitante, status_aprovacao, motivo)
        VALUES (?, ?, 'pendente', ?)
    ");
    $stmt->bind_param(
        "iis",
        $id_viagem,
        $_SESSION['usuario_id'],
        $dados['detalhes']['motivo']
    );
    $stmt->execute();

    $conexao->commit();
    
    // Limpa sessão e redireciona
    unset($_SESSION['dados_viagem']);
    header('Location: solicitacoes.php?sucesso=Viagem solicitada com sucesso!');

} catch (Exception $e) {
    $conexao->rollback();
    header('Location: confirmar_solicitacao.php?erro=Erro ao processar: ' . urlencode($e->getMessage()));
}