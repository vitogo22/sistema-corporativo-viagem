<?php
require 'includes/protecao.php';
require 'includes/conexao.php';
/* 
if ($_SESSION['usuario_tipo'] !== 'funcionario') {
    header('Location: painel.php?erro=Acesso restrito');
    exit;
}
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['dados_viagem'] = [
        'transporte' => [
            'tipo' => $_POST['tipo_transporte'],
            'origem' => $_POST['origem'],
            'destino' => $_POST['destino_transporte'],
            'data_saida' => $_POST['data_saida'],
            'data_chegada' => $_POST['data_chegada'],
            'preco_total' => $_POST['preco_transporte']
        ],
        'hospedagem' => [
            'nome' => $_POST['nome_hospedagem'],
            'endereco' => $_POST['endereco'],
            'cidade' => $_POST['cidade'],
            'data_checkin' => $_POST['data_checkin'],
            'data_checkout' => $_POST['data_checkout'],
            'preco_total' => $_POST['preco_hospedagem']
        ],
        'detalhes' => [
            'motivo' => $_POST['motivo']
        ]
    ];
    header('Location: confirmar_solicitacao.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Nova Solicitação de Viagem</title>
  <link rel="stylesheet" href="css/painel.css">
  <link rel="stylesheet" href="css/nova_solicitacao.css">
</head>
<body>
  <?php include 'includes/header.php'; ?>
  
  <div class="dashboard-container">
    <?php include 'includes/sidebar.php'; ?>
    
    <main class="main-content">
      <h1 class="section-title">Nova Solicitação de Viagem</h1>
      
      <form method="POST">
        <!-- Seção de Transporte -->
        <div class="form-section">
          <h2>Transporte</h2>
          
          <div class="form-row">
            <div class="form-group">
              <label for="tipo_transporte">Tipo de Transporte</label>
              <select class="form-control" id="tipo_transporte" name="tipo_transporte" required>
                <option value="">Selecione...</option>
                <option value="aviao">Avião</option>
                <option value="onibus">Ônibus</option>
                <option value="carro">Carro</option>
                <option value="outro">Outro</option>
              </select>
            </div>
            
            <div class="form-group">
              <label for="origem">Origem</label>
              <input type="text" class="form-control" id="origem" name="origem" required
                     placeholder="Ex: Aeroporto de Congonhas, São Paulo">
            </div>
          </div>
          
          <div class="form-row">
            <div class="form-group">
              <label for="destino_transporte">Destino</label>
              <input type="text" class="form-control" id="destino_transporte" name="destino_transporte" required
                     placeholder="Ex: Aeroporto Internacional de Miami">
            </div>
            
            <div class="form-group">
              <label for="data_saida">Data/Hora Saída</label>
              <input type="datetime-local" class="form-control" id="data_saida" name="data_saida" required>
            </div>
          </div>
          
          <div class="form-row">
            <div class="form-group">
              <label for="data_chegada">Data/Hora Chegada</label>
              <input type="datetime-local" class="form-control" id="data_chegada" name="data_chegada" required>
            </div>
            
            <div class="form-group">
              <label for="preco_transporte">Valor Estimado (R$)</label>
              <input type="number" step="0.01" class="form-control" id="preco_transporte" name="preco_transporte" required
                     placeholder="Ex: 1200.50">
            </div>
          </div>
        </div>
        
        <!-- Seção de Hospedagem -->
        <div class="form-section">
          <h2>Hospedagem</h2>
          
          <div class="form-row">
            <div class="form-group">
              <label for="nome_hospedagem">Nome do Local</label>
              <input type="text" class="form-control" id="nome_hospedagem" name="nome_hospedagem" required
                     placeholder="Ex: Hotel Marriott Miami">
            </div>
            
            <div class="form-group">
              <label for="endereco">Endereço Completo</label>
              <input type="text" class="form-control" id="endereco" name="endereco"
                     placeholder="Ex: 255 NE 14th St, Miami, FL 33132, EUA">
            </div>
          </div>
          
          <div class="form-row">
            <div class="form-group">
              <label for="cidade">Cidade</label>
              <input type="text" class="form-control" id="cidade" name="cidade" required
                     placeholder="Ex: Miami Beach">
            </div>
            
            <div class="form-group">
              <label for="data_checkin">Data de Check-in</label>
              <input type="date" class="form-control" id="data_checkin" name="data_checkin" required>
            </div>
          </div>
          
          <div class="form-row">
            <div class="form-group">
              <label for="data_checkout">Data de Check-out</label>
              <input type="date" class="form-control" id="data_checkout" name="data_checkout" required>
            </div>
            
            <div class="form-group">
              <label for="preco_hospedagem">Valor Estimado(R$)</label>
              <input type="number" step="0.01" class="form-control" id="preco_hospedagem" name="preco_hospedagem" required
                     placeholder="Ex: 2500.00">
            </div>
          </div>
        </div>
        
        <!-- Motivo da Viagem -->
        <div class="form-section">
          <h2>Detalhes da Viagem</h2>
          <div class="form-group">
            <label for="motivo">Motivo da Viagem</label>
            <textarea class="form-control" id="motivo" name="motivo" rows="5" required
                      placeholder="Descreva detalhadamente o propósito da viagem (reunião, evento, treinamento, etc.)&#10;Ex: Participação na Conferência Anual de Tecnologia como representante da empresa, com objetivo de estabelecer parcerias com fornecedores internacionais."></textarea>
          </div>
        </div>
        
        <button type="submit" class="btn-submit">Solicitar Viagem</button>
      </form>
    </main>
  </div>
</body>
</html>