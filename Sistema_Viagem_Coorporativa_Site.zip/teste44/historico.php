<?php
require 'includes/protecao.php';
require 'includes/conexao.php';

$usuario_id = $_SESSION['usuario_id'];
$isChefe = ($_SESSION['usuario_tipo'] === 'chefe' || $_SESSION['usuario_tipo'] === 'admin');

// Filtros do formulário
$filtro_destino = $_GET['destino'] ?? '';
$filtro_data_inicio = $_GET['data_inicio'] ?? '';
$filtro_data_fim = $_GET['data_fim'] ?? '';

// Consulta base com filtros
$sql = "SELECT v.id_viagem, v.destino, v.data_inicio, v.data_fim, 
               sv.data_solicitacao, sv.data_aprovacao,
               u_sol.nome as solicitante_nome,
               u_apr.nome as aprovador_nome
        FROM Viagem v
        JOIN SolicitacaoViagem sv ON v.id_viagem = sv.id_viagem
        JOIN Usuario u_sol ON sv.id_usuario_solicitante = u_sol.id_usuario
        LEFT JOIN Usuario u_apr ON sv.id_usuario_aprovador = u_apr.id_usuario
        WHERE sv.status_aprovacao = 'aprovada' 
        AND v.data_fim < CURDATE()";

// Aplica filtros
$params = [];
$types = '';

if (!$isChefe) {
    $sql .= " AND sv.id_usuario_solicitante = ?";
    $params[] = $usuario_id;
    $types .= 'i';
}

if (!empty($filtro_destino)) {
    $sql .= " AND v.destino LIKE ?";
    $params[] = "%$filtro_destino%";
    $types .= 's';
}

if (!empty($filtro_data_inicio)) {
    $sql .= " AND v.data_fim >= ?";
    $params[] = $filtro_data_inicio;
    $types .= 's';
}

if (!empty($filtro_data_fim)) {
    $sql .= " AND v.data_fim <= ?";
    $params[] = $filtro_data_fim;
    $types .= 's';
}

// Ordenação
$sql .= " ORDER BY v.data_fim DESC";

// Prepara e executa
$stmt = $conexao->prepare($sql);

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$viagens = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico de Viagens</title>
    <link rel="stylesheet" href="css/painel.css">
    <link rel="stylesheet" href="css/historico.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="dashboard-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <h1 class="section-title">Histórico de Viagens</h1>
            
            <div class="filtros-container">
                <form method="get" class="filtros-form">
                    <div class="filtro-group">
                        <label for="destino">Destino</label>
                        <input type="text" id="destino" name="destino" value="<?= htmlspecialchars($filtro_destino) ?>" placeholder="Qual destino?">
                    </div>
                    
                    <div class="filtro-group">
                        <label for="data_inicio">De</label>
                        <input type="date" id="data_inicio" name="data_inicio" value="<?= htmlspecialchars($filtro_data_inicio) ?>">
                    </div>
                    
                    <div class="filtro-group">
                        <label for="data_fim">Até</label>
                        <input type="date" id="data_fim" name="data_fim" value="<?= htmlspecialchars($filtro_data_fim) ?>">
                    </div>
                    
                    <div class="filtro-group">
                        <button type="submit" class="btn-filtrar">Filtrar</button>
                    </div>
                </form>
            </div>
            
            <?php if (empty($viagens)): ?>
                <div class="sem-resultados">
                    Nenhuma viagem encontrada no histórico.
                    <?php if (!$isChefe): ?>
                        <p><a href="nova_solicitacao.php" style="color: #56A0D3;">Solicitar nova viagem</a></p>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <?php foreach ($viagens as $viagem): ?>
                    <div class="viagem-card">
                        <div class="viagem-header">
                            <h2 class="viagem-destino"><?= htmlspecialchars($viagem['destino']) ?></h2>
                            <div class="viagem-periodo">
                                <?= date('d/m/Y', strtotime($viagem['data_inicio'])) ?> - 
                                <?= date('d/m/Y', strtotime($viagem['data_fim'])) ?>
                            </div>
                        </div>
                        
                        <div class="viagem-detalhes">
                            <div class="detalhe-item">
                                <span class="detalhe-label">Solicitante</span>
                                <span class="detalhe-value"><?= htmlspecialchars($viagem['solicitante_nome']) ?></span>
                            </div>
                            
                            <div class="detalhe-item">
                                <span class="detalhe-label">Data da Solicitação</span>
                                <span class="detalhe-value">
                                    <?= date('d/m/Y H:i', strtotime($viagem['data_solicitacao'])) ?>
                                </span>
                            </div>
                            
                            <?php if ($viagem['aprovador_nome']): ?>
                            <div class="detalhe-item">
                                <span class="detalhe-label">Aprovador</span>
                                <span class="detalhe-value"><?= htmlspecialchars($viagem['aprovador_nome']) ?></span>
                            </div>
                            
                            <div class="detalhe-item">
                                <span class="detalhe-label">Data de Aprovação</span>
                                <span class="detalhe-value">
                                    <?= date('d/m/Y H:i', strtotime($viagem['data_aprovacao'])) ?>
                                </span>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <a href="detalhes.php?id=<?= $viagem['id_viagem'] ?>" class="btn-detalhes">
                            Ver Detalhes Completos
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>