<?php
require 'includes/protecao.php';
require 'includes/conexao.php';

$usuario_id = $_SESSION['usuario_id'];
$mensagem = '';
$erro = '';

// Processar formulário de reembolso
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conexao->begin_transaction();
        
        $viagem_id = intval($_POST['viagem_id']);
        $descricao_despesa = trim($_POST['descricao_despesa']);
        $valor = floatval(str_replace(',', '.', $_POST['valor']));
        $tipo_despesa = $_POST['tipo_despesa'];
        
        // Verificar se a viagem pertence ao usuário (exceto para admin)
        if ($_SESSION['usuario_tipo'] !== 'admin') {
            $stmt = $conexao->prepare("
                SELECT 1 FROM Viagem v
                JOIN SolicitacaoViagem sv ON v.id_viagem = sv.id_viagem
                WHERE v.id_viagem = ? AND sv.id_usuario_solicitante = ?
                AND sv.status_aprovacao = 'aprovada'
            ");
            $stmt->bind_param("ii", $viagem_id, $usuario_id);
            $stmt->execute();
            
            if ($stmt->get_result()->num_rows === 0) {
                throw new Exception("Viagem não encontrada ou não aprovada");
            }
        }
        
        // Inserir reembolso
        $stmt = $conexao->prepare("
            INSERT INTO Reembolso 
            (id_viagem, descricao_despesa, valor, tipo_despesa, data_requisicao, status)
            VALUES (?, ?, ?, ?, NOW(), 'pendente')
        ");
        $stmt->bind_param("isds", $viagem_id, $descricao_despesa, $valor, $tipo_despesa);
        $stmt->execute();
        
        $conexao->commit();
        $mensagem = "Solicitação de reembolso enviada com sucesso!";
    } catch (Exception $e) {
        $conexao->rollback();
        $erro = "Erro ao solicitar reembolso: " . $e->getMessage();
    }
}

// Obter viagens elegíveis para reembolso
$sql_viagens = "
    SELECT v.id_viagem, v.destino, v.data_inicio, v.data_fim
    FROM Viagem v
    JOIN SolicitacaoViagem sv ON v.id_viagem = sv.id_viagem
    LEFT JOIN Reembolso r ON v.id_viagem = r.id_viagem
    WHERE sv.id_usuario_solicitante = ?
    AND sv.status_aprovacao = 'aprovada'
    AND v.data_fim BETWEEN DATE_SUB(CURDATE(), INTERVAL 3 MONTH) AND CURDATE()
    AND (r.id_viagem IS NULL OR r.status = 'recusado')
    ORDER BY v.data_fim DESC
";
$stmt = $conexao->prepare($sql_viagens);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$viagens = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Obter reembolsos do usuário
$sql_reembolsos = "
    SELECT r.id_reembolso, r.id_viagem, 
           r.descricao_despesa as motivo,  /* usando o alias para compatibilidade */
           r.valor, r.tipo_despesa, r.data_requisicao, 
           r.status, r.motivo_recusa,
           v.destino,
           CASE 
               WHEN r.status = 'aprovado' THEN 'Aprovado'
               WHEN r.status = 'recusado' THEN 'Recusado'
               ELSE 'Pendente'
           END as status_formatado
    FROM Reembolso r
    JOIN Viagem v ON r.id_viagem = v.id_viagem
    JOIN SolicitacaoViagem sv ON v.id_viagem = sv.id_viagem
    WHERE sv.id_usuario_solicitante = ?
    ORDER BY r.data_requisicao DESC
";
$stmt = $conexao->prepare($sql_reembolsos);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$reembolsos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitação de Reembolso</title>
    <link rel="stylesheet" href="css/painel.css">
    <link rel="stylesheet" href="css/reembolso.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="dashboard-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <h1 class="section-title">Solicitação de Reembolso</h1>
            
            <?php if ($mensagem): ?>
                <div class="mensagem sucesso"><?= htmlspecialchars($mensagem) ?></div>
            <?php endif; ?>
            
            <?php if ($erro): ?>
                <div class="mensagem erro"><?= htmlspecialchars($erro) ?></div>
            <?php endif; ?>
            
            <div class="reembolso-container">
                <div class="card">
                    <h2 class="section-title">Nova Solicitação</h2>
                    <form method="POST" enctype="multipart/form-data">
                        <div class="form-group">
    <label for="viagem_id">Viagem Relacionada</label>
    <select class="form-control" id="viagem_id" name="viagem_id" required <?= empty($viagens) ? 'disabled' : '' ?>>
        <?php if (empty($viagens)): ?>
            <option value="">Nenhuma viagem elegível encontrada</option>
        <?php else: ?>
            <option value="">Selecione uma viagem...</option>
            <?php foreach ($viagens as $viagem): ?>
                <option value="<?= $viagem['id_viagem'] ?>">
                    <?= htmlspecialchars($viagem['destino']) ?> 
                    (<?= date('d/m/Y', strtotime($viagem['data_inicio'])) ?> - 
                    <?= date('d/m/Y', strtotime($viagem['data_fim'])) ?>)
                </option>
            <?php endforeach; ?>
        <?php endif; ?>
    </select>
    <?php if (empty($viagens)): ?>
        <small class="text-warning">Você não tem viagens aprovadas recentemente ou já solicitou reembolso para todas</small>
    <?php endif; ?>
</div>
                        
                        <div class="form-group">
                            <label for="tipo_despesa">Tipo de Despesa</label>
                            <select class="form-control" id="tipo_despesa" name="tipo_despesa" required>
                                <option value="">Selecione...</option>
                                <option value="alimentacao">Alimentação</option>
                                <option value="transporte">Transporte Local</option>
                                <option value="hospedagem">Hospedagem Extra</option>
                                <option value="material">Material de Trabalho</option>
                                <option value="outros">Outros</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="valor">Valor (R$)</label>
                            <input type="text" class="form-control" id="valor" name="valor" 
                                   placeholder="0,00" pattern="\d+,\d{2}" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="descricao_despesa">Descrição/Motivo</label>
                            <textarea class="form-control" id="descricao_despesa" name="descricao_despesa" rows="4" required
                                      placeholder="Descreva os detalhes da despesa..."></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="comprovante">Comprovante (Opcional)</label>
                            <input type="file" class="form-control" id="comprovante" name="comprovante"
                                   accept=".pdf,.jpg,.jpeg,.png">
                            <small>Formatos aceitos: PDF, JPG, PNG (até 2MB)</small>
                        </div>
                        
                        <button type="submit" class="btn-submit">Enviar Solicitação</button>
                    </form>
                </div>
                
                <div class="card">
                    <h2 class="section-title">Meus Reembolsos</h2>
                    
                    <?php if (empty($reembolsos)): ?>
                        <p>Nenhuma solicitação de reembolso encontrada.</p>
                    <?php else: ?>
                        <table class="table-reembolsos">
                            <thead>
                                <tr>
                                    <th>Viagem</th>
                                    <th>Data</th>
                                    <th>Tipo</th>
                                    <th>Valor</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($reembolsos as $reembolso): ?>
                                    <tr onclick="window.location='detalhes_reembolso.php?id=<?= $reembolso['id_reembolso'] ?>'" 
                                        style="cursor: pointer;">
                                        <td><?= htmlspecialchars($reembolso['destino']) ?></td>
                                        <td><?= date('d/m/Y', strtotime($reembolso['data_requisicao'])) ?></td>
                                        <td><?= ucfirst(htmlspecialchars($reembolso['tipo_despesa'])) ?></td>
                                        <td>R$ <?= number_format($reembolso['valor'], 2, ',', '.') ?></td>
                                        <td class="status-<?= htmlspecialchars($reembolso['status']) ?>">
                                            <?= htmlspecialchars($reembolso['status_formatado']) ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>  
                    <?php endif; ?>
                </div>
                <?php if ($_SESSION['usuario_tipo'] === 'chefe' || $_SESSION['usuario_tipo'] === 'admin'): ?>
    <div class="card" style="margin-top: 30px;">
        <h2 class="section-title">Reembolsos Pendentes da Equipe</h2>
        <?php
        $stmt = $conexao->prepare("
            SELECT r.id_reembolso, r.valor, r.tipo_despesa, r.data_requisicao,
                   v.destino, u.nome as solicitante_nome
            FROM Reembolso r
            JOIN Viagem v ON r.id_viagem = v.id_viagem
            JOIN SolicitacaoViagem sv ON v.id_viagem = sv.id_viagem
            JOIN Usuario u ON sv.id_usuario_solicitante = u.id_usuario
            WHERE r.status = 'pendente'
            AND sv.id_usuario_solicitante IN (
                SELECT id_usuario FROM Usuario 
                WHERE departamento = (
                    SELECT departamento FROM Usuario WHERE id_usuario = ?
                )
            )
            ORDER BY r.data_requisicao DESC
        ");
        $stmt->bind_param("i", $usuario_id);
        $stmt->execute();
        $pendentes_equipe = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        ?>
        
        <?php if (empty($pendentes_equipe)): ?>
            <p>Nenhum reembolso pendente na equipe.</p>
        <?php else: ?>
            <table class="table-reembolsos">
                <thead>
                    <tr>
                        <th>Solicitante</th>
                        <th>Viagem</th>
                        <th>Tipo</th>
                        <th>Valor</th>
                        <th>Data</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pendentes_equipe as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['solicitante_nome']) ?></td>
                            <td><?= htmlspecialchars($item['destino']) ?></td>
                            <td><?= ucfirst($item['tipo_despesa']) ?></td>
                            <td>R$ <?= number_format($item['valor'], 2, ',', '.') ?></td>
                            <td><?= date('d/m/Y', strtotime($item['data_requisicao'])) ?></td>
                            <td>
                                <a href="detalhes_reembolso.php?id=<?= $item['id_reembolso'] ?>" 
                                   class="btn-detalhes" style="padding:5px 10px;">
                                   Analisar
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
<?php endif; ?>
            </div>
        </main>
    </div>
    
    <script>
        // Máscara para o campo de valor
        document.getElementById('valor').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            value = (value/100).toFixed(2) + '';
            value = value.replace(".", ",");
            value = value.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
            e.target.value = value;
        });
        
        // Validação do formulário
        document.querySelector('form').addEventListener('submit', function(e) {
            const valor = document.getElementById('valor').value;
            if (!valor.match(/^\d{1,3}(\.\d{3})*,\d{2}$/)) {
                alert('Por favor, insira um valor válido (ex: 1.234,56)');
                e.preventDefault();
            }
        });
    </script>
</body>
</html>