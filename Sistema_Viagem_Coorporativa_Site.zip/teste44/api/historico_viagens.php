<?php
require '../includes/protecao.php';
require '../includes/conexao.php';

header('Content-Type: application/json');

if (!isset($_GET['usuario_id'])) {
    echo json_encode(['error' => 'ID do usuário não especificado']);
    exit;
}

$userId = intval($_GET['usuario_id']);

$sql = "SELECT v.destino, v.data_inicio, v.data_fim, sv.status_aprovacao as status
        FROM Viagem v
        JOIN SolicitacaoViagem sv ON v.id_viagem = sv.id_viagem
        WHERE sv.id_usuario_solicitante = ?
        ORDER BY v.data_inicio DESC
        LIMIT 5";

$stmt = $conexao->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$viagens = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

echo json_encode(['viagens' => $viagens]);
?>