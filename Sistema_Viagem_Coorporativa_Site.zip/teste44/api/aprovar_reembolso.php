<?php
require '../includes/protecao.php';
require '../includes/conexao.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

try {
    // Verifica permissões
    if ($_SESSION['usuario_tipo'] !== 'admin' && $_SESSION['usuario_tipo'] !== 'chefe') {
        throw new Exception('Acesso não autorizado');
    }

    // Validação do ID
    if (!isset($data['id']) || !is_numeric($data['id'])) {
        throw new Exception('ID inválido');
    }

    $conexao->begin_transaction();

    // Atualiza o reembolso (versão corrigida)
    $stmt = $conexao->prepare("
        UPDATE Reembolso 
        SET status = ?,
            motivo_recusa = ?,
            id_usuario_aprovador = ?,
            data_aprovacao = IF(? = 'aprovar', NOW(), NULL)
        WHERE id_reembolso = ?
    ");

    $status = ($data['acao'] === 'aprovar') ? 'aprovado' : 'recusado';
    $motivo = ($data['acao'] === 'recusar') ? $data['motivo'] : null;
    $id_aprovador = $_SESSION['usuario_id'];

    $stmt->bind_param("ssiis", $status, $motivo, $id_aprovador, $data['acao'], $data['id']);
    $stmt->execute();

    $conexao->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    $conexao->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>