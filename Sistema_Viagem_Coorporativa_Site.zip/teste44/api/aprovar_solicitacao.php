<?php
require '../includes/protecao.php';
require '../includes/conexao.php';

header('Content-Type: application/json');

// Verifica se é chefe/admin para ações de aprovação/recusa
if (in_array($_POST['acao'], ['aprovar', 'recusar']) && 
    ($_SESSION['usuario_tipo'] !== 'chefe' && $_SESSION['usuario_tipo'] !== 'admin')) {
    echo json_encode(['success' => false, 'message' => 'Acesso não autorizado']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

try {
    $conexao->begin_transaction();
    
    // Atualiza status da solicitação
    $status = '';
    switch ($data['acao']) {
        case 'aprovar':
            $status = 'aprovada';
            break;
        case 'recusar':
            $status = 'recusada';
            break;
        case 'cancelar':
            $status = 'cancelada';
            break;
        default:
            throw new Exception('Ação inválida');
    }
    
    $stmt = $conexao->prepare("
        UPDATE SolicitacaoViagem 
        SET status_aprovacao = ?, 
            id_usuario_aprovador = ?,
            data_aprovacao = NOW(),
            motivo_recusa = ?
        WHERE id_solicitacao = ?
    ");
    
    $id_aprovador = ($status === 'cancelada') ? null : $_SESSION['usuario_id'];
    $motivo = ($data['acao'] === 'recusar') ? ($data['motivo'] ?? null) : null;
    
    $stmt->bind_param("sisi", $status, $id_aprovador, $motivo, $data['id']);
    $stmt->execute();
    
    // Atualiza status da viagem se necessário
    if ($status === 'aprovada') {
        $conexao->query("
            UPDATE Viagem v
            JOIN SolicitacaoViagem sv ON v.id_viagem = sv.id_viagem
            SET v.status = 'aprovada'
            WHERE sv.id_solicitacao = {$data['id']}
        ");
    } elseif ($status === 'cancelada') {
        $conexao->query("
            UPDATE Viagem v
            JOIN SolicitacaoViagem sv ON v.id_viagem = sv.id_viagem
            SET v.status = 'cancelada'
            WHERE sv.id_solicitacao = {$data['id']}
        ");
    }
    
    $conexao->commit();
    echo json_encode(['success' => true, 'message' => 'Operação realizada']);
} catch (Exception $e) {
    $conexao->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>