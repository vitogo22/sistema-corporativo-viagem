<?php
require '../includes/protecao.php';
require '../includes/conexao.php';

header('Content-Type: application/json');

if (!isset($_GET['id'])) {
    echo json_encode(['error' => 'ID não especificado']);
    exit;
}

$userId = intval($_GET['id']);

$sql = "SELECT * FROM Usuario WHERE id_usuario = ?";
$stmt = $conexao->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$usuario = $stmt->get_result()->fetch_assoc();

echo json_encode(['usuario' => $usuario]);
?>