-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 29/05/2025 às 01:00
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `sistemaviagemcorporativa`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `hospedagem`
--

CREATE TABLE `hospedagem` (
  `id_hospedagem` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `endereco` varchar(200) DEFAULT NULL,
  `cidade` varchar(100) DEFAULT NULL,
  `preco_total` decimal(10,2) NOT NULL,
  `data_checkin` date DEFAULT NULL,
  `data_checkout` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `hospedagem`
--

INSERT INTO `hospedagem` (`id_hospedagem`, `nome`, `endereco`, `cidade`, `preco_total`, `data_checkin`, `data_checkout`) VALUES
(1, 'Hotel Premium', 'Av. Paulista, 1000', 'São Paulo', 1200.50, '2023-11-15', '2023-11-18'),
(2, 'Pousada Mar Azul', 'Rua das Flores, 200', 'Florianópolis', 850.00, '2023-12-01', '2023-12-05'),
(3, 'Resort Montanha Verde', 'Estrada da Serra, 3000', 'Gramado', 2100.00, '2024-01-10', '2024-01-15'),
(14, 'Local Teste Solicitação', 'Rua. tal tal - 667', 'São Paulo', 1400.00, '2025-05-27', '2025-05-29'),
(15, 'Local Teste Solicitação 2', 'Rua. tal tal - 645', 'São Paulo', 1245.00, '2025-05-30', '2025-05-31'),
(16, 'Hotel teste 1', 'Rua. tal tal - 333', 'Rio de Janeiro', 1800.00, '2025-05-30', '2025-06-02'),
(17, 'Hotel teste 1', 'Rua. tal tal - 333', 'Rio de Janeiro', 1800.00, '2025-05-30', '2025-06-02');

-- --------------------------------------------------------

--
-- Estrutura para tabela `reembolso`
--

CREATE TABLE `reembolso` (
  `id_reembolso` int(11) NOT NULL,
  `id_viagem` int(11) NOT NULL,
  `descricao_despesa` text DEFAULT NULL,
  `comprovante_path` varchar(255) DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `tipo_despesa` enum('alimentacao','transporte','hospedagem','material','outros') DEFAULT NULL,
  `data_requisicao` datetime DEFAULT current_timestamp(),
  `status` enum('pendente','aprovado','recusado') DEFAULT 'pendente',
  `data_aprovacao` datetime DEFAULT NULL,
  `motivo_recusa` text DEFAULT NULL,
  `id_usuario_aprovador` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `reembolso`
--

INSERT INTO `reembolso` (`id_reembolso`, `id_viagem`, `descricao_despesa`, `comprovante_path`, `valor`, `tipo_despesa`, `data_requisicao`, `status`, `data_aprovacao`, `motivo_recusa`, `id_usuario_aprovador`) VALUES
(2, 20, '', NULL, 150.00, 'alimentacao', '2025-05-22 21:07:44', 'recusado', '2025-05-26 17:17:45', 'teste 44', 10),
(7, 25, 'vihvkihil', NULL, 55.50, 'transporte', '2025-05-26 15:44:00', 'aprovado', '2025-05-26 17:17:17', NULL, 10),
(8, 20, 'msfsdgnsg', NULL, 150.00, 'alimentacao', '2025-05-26 20:40:18', 'aprovado', '2025-05-26 20:40:49', NULL, 10),
(9, 20, 'um dia a menos hospedado', NULL, 130.00, 'hospedagem', '2025-05-28 19:47:37', 'aprovado', '2025-05-28 19:48:49', NULL, 10);

-- --------------------------------------------------------

--
-- Estrutura para tabela `relatoriofinanceiro`
--

CREATE TABLE `relatoriofinanceiro` (
  `id_relatorio` int(11) NOT NULL,
  `id_viagem` int(11) NOT NULL,
  `custo_total` decimal(10,2) DEFAULT NULL,
  `data_geracao` datetime DEFAULT current_timestamp(),
  `observacoes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `solicitacaoviagem`
--

CREATE TABLE `solicitacaoviagem` (
  `id_solicitacao` int(11) NOT NULL,
  `id_viagem` int(11) NOT NULL,
  `data_solicitacao` datetime DEFAULT current_timestamp(),
  `id_usuario_solicitante` int(11) NOT NULL,
  `id_usuario_aprovador` int(11) DEFAULT NULL,
  `status_aprovacao` enum('pendente','aprovada','recusada') DEFAULT 'pendente',
  `data_aprovacao` datetime DEFAULT NULL,
  `motivo_recusa` text DEFAULT NULL,
  `motivo` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `solicitacaoviagem`
--

INSERT INTO `solicitacaoviagem` (`id_solicitacao`, `id_viagem`, `data_solicitacao`, `id_usuario_solicitante`, `id_usuario_aprovador`, `status_aprovacao`, `data_aprovacao`, `motivo_recusa`, `motivo`) VALUES
(17, 16, '2023-10-01 14:30:00', 9, 10, 'aprovada', '2023-10-02 10:15:00', NULL, NULL),
(18, 17, '2023-11-10 09:45:00', 9, 10, 'aprovada', '2025-05-22 16:05:07', NULL, NULL),
(19, 18, '2023-11-15 16:20:00', 11, 10, 'aprovada', '2025-05-22 16:04:59', NULL, NULL),
(20, 19, '2023-10-05 11:10:00', 9, 10, 'recusada', '2023-10-06 08:30:00', 'Orçamento excede o limite', NULL),
(21, 20, '2025-05-22 17:31:44', 9, NULL, 'aprovada', NULL, NULL, NULL),
(22, 21, '2025-05-26 14:13:56', 10, 10, 'recusada', '2025-05-26 14:14:50', 'cancelamento da reunião', NULL),
(23, 22, '2025-05-26 14:17:37', 10, 10, 'aprovada', '2025-05-26 14:17:51', NULL, NULL),
(24, 23, '2025-05-26 14:19:20', 10, 10, 'recusada', '2025-05-26 14:20:16', 'tesre recusar', NULL),
(26, 25, '2025-05-26 15:11:56', 9, 10, 'aprovada', '2025-05-26 15:13:02', NULL, NULL),
(27, 26, '2025-05-26 15:14:25', 10, 10, 'recusada', '2025-05-26 15:15:49', 'teste 3', NULL),
(28, 27, '2025-05-26 15:25:18', 10, 10, 'recusada', '2025-05-26 15:25:30', 'teste 4', NULL),
(29, 35, '2025-05-26 20:33:04', 9, 10, 'aprovada', '2025-05-26 20:36:49', NULL, 'Teste 44 BD Motivo'),
(30, 36, '2025-05-28 15:34:38', 9, 13, 'aprovada', '2025-05-28 15:36:08', NULL, 'shehhaehrhah'),
(31, 37, '2025-05-28 19:18:47', 11, NULL, '', '2025-05-28 19:19:09', NULL, 'Apareça na hora de aprovar'),
(32, 38, '2025-05-28 19:20:38', 11, 13, 'recusada', '2025-05-28 19:32:50', 'teste recusa 1', 'Apareça na hora de aprovar');

-- --------------------------------------------------------

--
-- Estrutura para tabela `transporte`
--

CREATE TABLE `transporte` (
  `id_transporte` int(11) NOT NULL,
  `tipo` enum('aviao','onibus','carro','outro') NOT NULL,
  `origem` varchar(100) DEFAULT NULL,
  `destino` varchar(100) DEFAULT NULL,
  `data_saida` datetime DEFAULT NULL,
  `data_chegada` datetime DEFAULT NULL,
  `preco_total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `transporte`
--

INSERT INTO `transporte` (`id_transporte`, `tipo`, `origem`, `destino`, `data_saida`, `data_chegada`, `preco_total`) VALUES
(1, 'aviao', 'São Paulo', 'Rio de Janeiro', '2023-11-15 08:00:00', '2023-11-15 09:15:00', 450.00),
(2, 'onibus', 'Belo Horizonte', 'Vitória', '2023-12-01 22:00:00', '2023-12-02 06:30:00', 120.50),
(3, 'carro', 'Porto Alegre', 'Gramado', '2024-01-10 09:00:00', '2024-01-10 11:30:00', 0.00),
(11, 'aviao', 'Curitiba', 'São Paulo', '2025-05-27 20:31:00', '2025-05-27 21:32:00', 800.00),
(12, 'onibus', 'Curitiba', 'São Paulo', '2025-05-21 15:33:00', '2025-05-30 15:34:00', 550.00),
(13, 'aviao', 'Miami', 'Rio de Janeiro', '2025-05-29 19:15:00', '2025-05-30 08:16:00', 1200.00),
(14, 'aviao', 'Miami', 'Rio de Janeiro', '2025-05-29 19:19:00', '2025-05-30 08:19:00', 1200.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo` enum('funcionario','chefe','admin') NOT NULL,
  `departamento` varchar(100) DEFAULT NULL,
  `cargo` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nome`, `email`, `senha`, `tipo`, `departamento`, `cargo`) VALUES
(1, 'Vitor Hugo', 'teste1@gmail.com', '$2y$10$rWsdHqPGpRpKdcG6YrQOVOOxnVSaZO71ncoZambAFNbYyqZijES/O', 'funcionario', 'finanças', 'chefe'),
(9, 'João Silva', 'joao.silva@empresa.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'funcionario', 'Vendas', 'Representante'),
(10, 'Maria Souza', 'maria.souza@empresa.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'chefe', 'Vendas', 'Gerente'),
(11, 'Carlos Oliveira', 'carlos.oliveira@empresa.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'funcionario', 'TI', 'Desenvolvedor'),
(12, 'Ana Costa', 'ana.costa@empresa.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'Diretoria', 'Diretora'),
(13, 'Julia', 'teste2@gmail.com', '$2y$10$LJ8ixa2SBLW2jEB25cm3P.PN0tQ1U38W.KgM8rym2eYx5egmzTcMO', 'chefe', 'finanças', 'Diretor');

-- --------------------------------------------------------

--
-- Estrutura para tabela `viagem`
--

CREATE TABLE `viagem` (
  `id_viagem` int(11) NOT NULL,
  `destino` varchar(100) DEFAULT NULL,
  `data_inicio` date DEFAULT NULL,
  `data_fim` date DEFAULT NULL,
  `status` enum('planejada','solicitada','aprovada','reprovada','cancelada') DEFAULT 'planejada',
  `id_usuario` int(11) NOT NULL,
  `id_hospedagem` int(11) DEFAULT NULL,
  `id_transporte` int(11) DEFAULT NULL,
  `custo_total` decimal(10,2) DEFAULT NULL,
  `motivo` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `viagem`
--

INSERT INTO `viagem` (`id_viagem`, `destino`, `data_inicio`, `data_fim`, `status`, `id_usuario`, `id_hospedagem`, `id_transporte`, `custo_total`, `motivo`) VALUES
(16, 'Rio de Janeiro', '2023-11-15', '2023-11-18', 'aprovada', 9, 1, 1, NULL, NULL),
(17, 'Florianópolis', '2023-12-01', '2023-12-05', 'aprovada', 9, 2, 2, NULL, NULL),
(18, 'Gramado', '2024-01-10', '2024-01-15', 'aprovada', 11, 3, 3, NULL, NULL),
(19, 'São Paulo', '2023-11-20', '2023-11-22', '', 9, NULL, NULL, NULL, NULL),
(20, 'São Paulo', '2025-05-17', '2025-05-20', 'aprovada', 9, NULL, NULL, NULL, NULL),
(21, 'São Paulo', '2025-05-19', '2025-05-28', 'aprovada', 10, NULL, NULL, NULL, NULL),
(22, 'Curitiba', '2025-05-21', '2025-05-23', 'aprovada', 10, NULL, NULL, NULL, NULL),
(23, 'Cascavel', '2025-05-07', '2025-05-10', 'solicitada', 10, NULL, NULL, NULL, NULL),
(24, 'Curitiba', '2025-05-20', '2025-05-26', 'cancelada', 9, NULL, NULL, NULL, NULL),
(25, 'São Paulo', '2025-05-19', '2025-05-22', 'aprovada', 9, NULL, NULL, NULL, NULL),
(26, 'São Paulo', '2025-05-21', '2025-05-24', 'cancelada', 10, NULL, NULL, NULL, NULL),
(27, 'Curitiba', '2025-05-14', '2025-05-12', 'cancelada', 10, NULL, NULL, NULL, NULL),
(35, 'São Paulo', '2025-05-27', '2025-05-29', 'aprovada', 9, 14, 11, NULL, NULL),
(36, 'São Paulo', '2025-05-21', '2025-05-31', 'aprovada', 9, 15, 12, NULL, NULL),
(37, 'Rio de Janeiro', '2025-05-29', '2025-06-02', 'cancelada', 11, 16, 13, NULL, NULL),
(38, 'Rio de Janeiro', '2025-05-29', '2025-06-02', 'solicitada', 11, 17, 14, NULL, NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `hospedagem`
--
ALTER TABLE `hospedagem`
  ADD PRIMARY KEY (`id_hospedagem`);

--
-- Índices de tabela `reembolso`
--
ALTER TABLE `reembolso`
  ADD PRIMARY KEY (`id_reembolso`),
  ADD KEY `id_viagem` (`id_viagem`),
  ADD KEY `fk_reembolso_aprovador` (`id_usuario_aprovador`);

--
-- Índices de tabela `relatoriofinanceiro`
--
ALTER TABLE `relatoriofinanceiro`
  ADD PRIMARY KEY (`id_relatorio`),
  ADD KEY `id_viagem` (`id_viagem`);

--
-- Índices de tabela `solicitacaoviagem`
--
ALTER TABLE `solicitacaoviagem`
  ADD PRIMARY KEY (`id_solicitacao`),
  ADD KEY `id_viagem` (`id_viagem`),
  ADD KEY `id_usuario_solicitante` (`id_usuario_solicitante`),
  ADD KEY `id_usuario_aprovador` (`id_usuario_aprovador`);

--
-- Índices de tabela `transporte`
--
ALTER TABLE `transporte`
  ADD PRIMARY KEY (`id_transporte`);

--
-- Índices de tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices de tabela `viagem`
--
ALTER TABLE `viagem`
  ADD PRIMARY KEY (`id_viagem`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_hospedagem` (`id_hospedagem`),
  ADD KEY `id_transporte` (`id_transporte`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `hospedagem`
--
ALTER TABLE `hospedagem`
  MODIFY `id_hospedagem` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de tabela `reembolso`
--
ALTER TABLE `reembolso`
  MODIFY `id_reembolso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `relatoriofinanceiro`
--
ALTER TABLE `relatoriofinanceiro`
  MODIFY `id_relatorio` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `solicitacaoviagem`
--
ALTER TABLE `solicitacaoviagem`
  MODIFY `id_solicitacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de tabela `transporte`
--
ALTER TABLE `transporte`
  MODIFY `id_transporte` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `viagem`
--
ALTER TABLE `viagem`
  MODIFY `id_viagem` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `reembolso`
--
ALTER TABLE `reembolso`
  ADD CONSTRAINT `fk_reembolso_aprovador` FOREIGN KEY (`id_usuario_aprovador`) REFERENCES `usuario` (`id_usuario`),
  ADD CONSTRAINT `reembolso_ibfk_1` FOREIGN KEY (`id_viagem`) REFERENCES `viagem` (`id_viagem`);

--
-- Restrições para tabelas `relatoriofinanceiro`
--
ALTER TABLE `relatoriofinanceiro`
  ADD CONSTRAINT `relatoriofinanceiro_ibfk_1` FOREIGN KEY (`id_viagem`) REFERENCES `viagem` (`id_viagem`);

--
-- Restrições para tabelas `solicitacaoviagem`
--
ALTER TABLE `solicitacaoviagem`
  ADD CONSTRAINT `solicitacaoviagem_ibfk_1` FOREIGN KEY (`id_viagem`) REFERENCES `viagem` (`id_viagem`),
  ADD CONSTRAINT `solicitacaoviagem_ibfk_2` FOREIGN KEY (`id_usuario_solicitante`) REFERENCES `usuario` (`id_usuario`),
  ADD CONSTRAINT `solicitacaoviagem_ibfk_3` FOREIGN KEY (`id_usuario_aprovador`) REFERENCES `usuario` (`id_usuario`);

--
-- Restrições para tabelas `viagem`
--
ALTER TABLE `viagem`
  ADD CONSTRAINT `viagem_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`),
  ADD CONSTRAINT `viagem_ibfk_2` FOREIGN KEY (`id_hospedagem`) REFERENCES `hospedagem` (`id_hospedagem`),
  ADD CONSTRAINT `viagem_ibfk_3` FOREIGN KEY (`id_transporte`) REFERENCES `transporte` (`id_transporte`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
